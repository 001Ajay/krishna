/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.remove.lisa', [
        'pAccountHoldersBase.remove.generic',
        'pAccountHoldersBase.generic.lisa',
        'ingGlobal'
    ]);

}());