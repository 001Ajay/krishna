/* globals angular: false */
(function () {
    'use strict';
    angular.module('pAccountHoldersBase.remove.lisa')
        .component('finished', {
            bindings: {
                encryptedIban: '<?',
                encryptedLeavingCustomerId: '<?',
                onError: '&?',
                templateUrl: '&?'
            },
            templateUrl: RemoveFinishedTemplateUrl,
            controller: RemoveFinishedController
        });

    function RemoveFinishedTemplateUrl(/* jshint unused: false */ $element, $attrs) {
        return $attrs.templateUrl ? $attrs.templateUrl : 'app/remove/lisa/finished/finished.html';
    }

    RemoveFinishedTemplateUrl.$inject = ['$element', '$attrs'];


    function RemoveFinishedController(CustomerService, propertyService) {
        var _this = this;

        this.getCustomer = function () {
            if (_this.encryptedIban && _this.encryptedLeavingCustomerId) {
                _this.isLoading = true;
                CustomerService.getOtherCustomerByCustomerId(_this.encryptedIban, _this.encryptedLeavingCustomerId).then(function (customer) {
                    _this.customer = customer;
                }).finally(function () {
                    _this.isLoading = false;
                });
                CustomerService.getCustomerByCustomerId(_this.encryptedIban, _this.encryptedLeavingCustomerId).then(function (customer) {
                    _this.removedCustomer = customer;
                }).finally(function () {
                    _this.isLoading = false;
                });
            } else {
                _this.customer = null;
                _this.removedCustomer = null;
            }
        };

        this.$onChanges = function (/* jshint unused: false */ changesObj) {
            _this.getCustomer();
        };

        this.$onInit = function () {
            _this.getCustomer();
            _this.properties = propertyService.properties('pAccountHoldersBase.remove.generic');
        };

    }
}());
