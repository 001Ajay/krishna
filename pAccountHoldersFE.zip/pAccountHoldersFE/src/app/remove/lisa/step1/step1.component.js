/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.remove.lisa')
        .component('step1', {
            bindings: {
                encryptedIban: '=?',
                encryptedLeavingCustomerId: '=?',
                hasCheckErrors: '=?',
                onComplete: '&?', // Function called when all data is satisfied and we can continue the process
                onNavigationController: '&?'
            },
            templateUrl: 'app/remove/lisa/step1/step1.html',
            controller: Step1Controller
        });

    function Step1Controller($scope, navigatorService, /* jshint unused: false */ richSelectOrderService) {
        var _this = this;

        this.onSelectedCustomer = function(customer) {
            if (angular.isDefined(_this.onComplete)) {
                _this.onComplete(angular.isDefined(customer) && customer.name ? {isComplete:true} : {isComplete:false});
            }
        };

        this.onIbanSelected = function ( /* jshint unused: false */ account) {
            _this.encryptedLeavingCustomerId = null;
            if (angular.isDefined(_this.onComplete)) {
                _this.onComplete({isComplete: false});
            }
        };

        this.$onInit = function () {
            _this.navigationController = navigatorService.get('pAccountHoldersNavCtrl');
            if (angular.isDefined(_this.onNavigationController)) {
                _this.onNavigationController({controller: _this.navigationController});
            }

            _this.navigationController.addCallback('step1', _this.nextCallback);
        };

        this.onError = function (/* jshint unused: false */ component, error) {
            //_this.navigationController.restrict('step1', 'step2');
        };

        this.nextCallback = function () {
            if (_this.encryptedIban && _this.encryptedLeavingCustomerId && _this.step1Form.$valid) {
                return true;
            } else {
                $scope.$broadcast('checkValidity');
                return false;
            }
        };
    }
}());
