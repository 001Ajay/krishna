/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.remove.lisa')
        .component('step3', {
            bindings: {
                encryptedIban: '<?',
                encryptedLeavingCustomerId: '<?',
                onComplete: '&?',
                onCanceled: '&?'
            },
            templateUrl: 'app/remove/lisa/step3/step3.html',
            controller: RemoveStep3Controller
        });

    function RemoveStep3Controller(propertyService, navigatorService) {
        var _this = this;

        this.cramRequestCanceled = function () {
            _this.navigationController.next();
            if (angular.isDefined(_this.onCanceled)) {
                _this.onCanceled(_this);
            }
        };

        this.cramRequestCompleted = function() {
            _this.navigationController.next();
            if (angular.isDefined(_this.onComplete)) {
                _this.onComplete(_this);
            }
        };

        this.$onInit = function() {
            _this.properties = propertyService.properties('pAccountHoldersBase.remove.generic');
            _this.navigationController = navigatorService.get('pAccountHoldersNavCtrl');
        };

    }
}());
