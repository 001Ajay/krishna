/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.remove.lisa')
        .component('step2', {
            bindings: {
                encryptedIban: '<?',
                encryptedLeavingCustomerId: '<?'
            },
            templateUrl: 'app/remove/lisa/step2/step2.html',
            controller: RemoveStep2Controller
        });

    function RemoveStep2Controller(CustomerService, EligibleAccountsRemove, propertyService) {
        var _this = this;

        this.getCustomer = function () {
            if (_this.encryptedIban && _this.encryptedLeavingCustomerId) {
                _this.isLoading = true;
                EligibleAccountsRemove.getAccountByEncryptedIban(_this.encryptedIban).then(function (eligibleCustomer) {
                    _this.eligibleCustomerByIban = eligibleCustomer;
                    _this.eligibleCustomerByIban.name = _this.eligibleCustomerByIban.name.replace('\u00AC', _this.properties.MSG_EnOf);
                    _this.selectedIban = _this.eligibleCustomerByIban.iban;
                }).finally(function () {
                    _this.isLoading = false;
                });
                CustomerService.getOtherCustomerByCustomerId(_this.encryptedIban, _this.encryptedLeavingCustomerId).then(function (customer) {
                    _this.customer = customer;
                }).finally(function () {
                    _this.isLoading = false;
                });
            } else {
                _this.customer = null;
                _this.selectedIban = null;
                _this.eligibleCustomerByIban = null;
            }
        };

        this.$onChanges = function (/* jshint unused: false */ changeObj) {
            _this.getCustomer();
        };

        this.$onInit = function() {
            _this.getCustomer();
            _this.properties = propertyService.properties('pAccountHoldersBase.remove.generic');
        };

    }
}());
