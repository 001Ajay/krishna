/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.remove.lisa')
        .component('appRemoveLisa', {
            templateUrl: 'app/remove/lisa/app-remove-lisa.html',
            controller: AppRemoveLisaController
        });

    function AppRemoveLisaController(/* jshint unused: false */ navigatorService) {
        var _this = this;

        this.state = {};
        this.onNavigationController = function (controller) {
            _this.navigationController = controller;
        };

        this.step1Complete = function (isComplete) {
            /* intentionally left empty */
        };

        this.step2Complete = function () {
            /* intentionally left empty */
        };

        this.step3Canceled = function () {
            _this.canceled = true;
        };
        this.step3Complete = function () {
            _this.canceled = false;
        };

        this.$onInit = function() {
            _this.canceled = false;
        };
    }
}());
