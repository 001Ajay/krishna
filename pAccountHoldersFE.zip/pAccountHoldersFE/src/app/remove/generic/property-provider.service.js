/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.remove.generic')
        .config(['propertyServiceProvider',
            function (propertyServiceProvider) {

                var mappings = {
                    // Error messages
                    MSG_EligibleAccounts_001: 'Onjuist aantal klanten in focus, er dienen 2 klanten opgevoerd te zijn in LISA',

                        MSG_CheckVerify_Prefix : 'U kunt uw gezamenlijke rekening niet direct omzetten.',
                    MSG_CheckVerify_0000: 'De geselecteerde rekening is in opheffing of reeds opgeheven.',
                    MSG_CheckVerify_0002: 'De geselecteerde rekening is geen Betaalrekening.',
                    MSG_CheckVerify_0003: 'De geselecteerde klant heeft het maximum aantal toegestane rekeningen.',
                    MSG_CheckVerify_0004: 'De geselecteerde rekening is geen En/Of Betaalrekening.',
                    MSG_CheckVerify_0006: 'De geselecteerde klant heeft een lening en/of hypotheek.',
                    MSG_CheckVerify_0007: 'Het saldo op de rekening is negatief.',
                    MSG_CheckVerify_0008: 'U heeft nog een Persoonlijke Lening bij deze rekening. Nadat u de lening in Mijn ING heeft afgelost, kunt u opnieuw een verzoek doen.',
                    MSG_CheckVerify_0009: 'U heeft nog een Doorlopend Krediet bij deze rekening. Nadat u in Mijn ING het krediet heeft afgelost en vervolgens heeft beëindigd, kunt u opnieuw een verzoek doen.',
                    MSG_CheckVerify_1009: 'U heeft nog een Doorlopend Krediet bij deze rekening. Nadat u het Doorlopend Krediet heeft beëindigd, kunt u opnieuw een verzoek doen.',
                    MSG_CheckVerify_0010: 'U heeft nog een Kwartaallimiet bij deze rekening, waarop u rood staat. Nadat u het tekort heeft aangevuld en de Kwartaallimiet heeft beëindigd, kunt u opnieuw een verzoek doen.',
                    MSG_CheckVerify_1010: 'U heeft nog een Kwartaallimiet bij deze rekening. Nadat u de Kwartaallimiet heeft beëindigd, kunt u opnieuw een verzoek doen.',
                    MSG_CheckVerify_0011: 'U heeft nog een Continuelimiet bij deze rekening. Nadat u in Mijn ING het krediet heeft afgelost en vervolgens heeft beëindigd, kunt u opnieuw een verzoek doen.',
                    MSG_CheckVerify_1011: 'U heeft nog een Continuelimiet bij deze rekening. Nadat u het Continuelimiet heeft beëindigd, kunt u opnieuw een verzoek doen.',
                    MSG_CheckVerify_0012: 'U heeft nog een gezamenlijke beleggershypotheek. Hierbij moet de Betaalrekening waarvan wordt ingelegd op de Beleggingsrekening, op dezelfde naam staan als de hypotheek. Wilt u uw inleg voor uw Beleggershypotheek van een andere Betaalrekening laten afschrijven? Dat kan met het formulier <a href="https://www.ing.nl/particulier/hypotheken/uw-situatie/uw-ing-hypotheek/wijziging-incassonummer-doorgeven/index.html" target="_blank">https://www.ing.nl/particulier/hypotheken/uw-situatie/uw-ing-hypotheek/wijziging-incassonummer-doorgeven/index.html.</a>',
                    MSG_CheckVerify_0015: 'Er is sprake van komende overstapservice',
                    MSG_CheckVerify_0016: 'Er is een hypotheek gekoppeld aan de rekening',

                    // If more explanations are needed based on number (eg ECO1) add them but leave the base explanation as is
                    MSG_CheckVerify_ECO: 'Heeft compliance kenmerk.',
                    MSG_CheckVerify_EAR: 'In behandeling bij achterstanden.',
                    MSG_CheckVerify_EFR: 'Heeft fraude kenmerk(en).',
                    MSG_CheckVerify_EAU: 'Geen bevoegdheid tot de rekening.',
                    MSG_CheckVerify_EAA: 'Is geen eigenaar van de rekening.',
                    MSG_CheckVerify_UNK: 'Geen reden bekend.',
                    MSG_CheckVerify_Suffix : ' Neem daarom eerst contact met ons op via 058 295 2820 om de mogelijkheden te ' +
                'bespreken. U kunt ons\n' +
                '                    bereiken op werkdagen van 8.00 tot 21.00 uur en op zaterdag van 9.00 tot 17.00 uur.',
                    MSG_TechError_1: 'Er is een fout opgetreden bij het ophalen van de gegevens.',
                    MSG_TechErrorAccount: 'Er is een fout opgetreden bij het ophalen van de rekeningen.',
                    MSG_TechError: 'Er is een fout opgetreden bij het ophalen van de gegevens.',
                    MSG_EnOf: ' en/of ',
                    MSG_Assisted_Auth_Canceled :'Assisted Auth Canceled',
                    MSG_Assisted_Auth_Incomplete : 'CRAM verzoek is nog niet ontvangen en u kunt nog niet doorgaan.',
                    MSG_unexpected_cram_error: 'CRAM verzoek kon niet worden gestart.',
                    MSG_Opnieuw_Proberen: 'Opnieuw proberen',
                    MSG_GeenKeuze: 'Er is nog geen keuze gemaakt',
                    MSG_GeenGeschikteRekeningen: 'Er zijn geen rekeningen gevonden die geschikt zijn om een rekeninghouder af te melden',
                    MSG_Afgebroken: 'Opdracht afgebroken',
                    MSG_NietUitgevoerd: 'Opdracht is niet uitgevoerd.',
                    MSG_OmzettenNaar: 'Omzetten naar'
                };

                propertyServiceProvider.add('pAccountHoldersBase.remove.generic', mappings);
            }
        ]);

}());



