/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.remove.generic')
        .component('removingAccountHolderInfo', {
            bindings: {
                encryptedIban: '<',
                encryptedLeavingCustomerId: '=?',
                onSelectedCustomer: '&?',
                onError: '&?'
            },
            templateUrl: 'app/remove/generic/removing-account-holder-info/removing-account-holder-info.html',
            controller: RemovingAccountHolderInfoController
        });


    function RemovingAccountHolderInfoController(CustomerService, propertyService) {
        var _this = this;
        this.customerSelected = function (customer) {
            if (_this.encryptedLeavingCustomerId !== customer.encryptedCustomerId){
                _this.encryptedLeavingCustomerId = customer.encryptedCustomerId;
                if (angular.isDefined(_this.onSelectedCustomer)) {
                    _this.onSelectedCustomer({customer: customer});
                }
            }
        };

        this.fetchData = function(encryptedIban) {
            if (encryptedIban) {
                _this.isLoading = true;
                CustomerService.getByIban(encryptedIban)
                    .then(function (customers) {
                        _this.customers = customers;
                        angular.forEach(_this.customers, function (obj) {
                            if ( _this.encryptedLeavingCustomerId === obj.encryptedCustomerId) {
                                obj.selected = true;
                            }
                        });
                    })
                    .catch(function (error) {
                        if (angular.isDefined(_this.onError)) {
                            _this.onError(_this, error);
                        }
                        _this.customers = null;
                        _this.error = error.data;
                    })
                    .finally(function () {
                        _this.isLoading = false;
                    });

            } else {
                _this.customers = null;
            }
        };

        this.$onChanges = function (changesObj) {
            if (changesObj.encryptedIban && changesObj.encryptedIban.currentValue) {
                _this.fetchData(changesObj.encryptedIban.currentValue);
            } else {
                _this.fetchData(null);
            }
        };

        this.$onInit = function () {
            _this.properties = propertyService.properties('pAccountHoldersBase.remove.generic');
        };
    }
}());
