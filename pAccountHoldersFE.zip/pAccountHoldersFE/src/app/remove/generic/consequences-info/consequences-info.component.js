/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.remove.generic')
        .component('consequencesInfo', {
            bindings: {
                encryptedIban: '<?',
                encryptedLeavingCustomerId: '<?',
                onUpdate: '&?',
                onError: '&?'
            },
            templateUrl: 'app/remove/generic/consequences-info/consequences-info.html',
            controller: ConsequencesInfoController
        });

    function ConsequencesInfoController(CustomerService, propertyService) {
        var _this = this;

        this.getCustomer = function () {
            if (_this.encryptedIban && _this.encryptedLeavingCustomerId) {
                delete _this.error;
                CustomerService.getCustomerByCustomerId(_this.encryptedIban, _this.encryptedLeavingCustomerId).then(function (customer) {
                    _this.removedCustomer = customer;
                }).catch(function (err) {
                    var errData = err.data;
                    if (angular.isDefined(_this.onError)) {
                        _this.onError(_this, errData);
                    }
                    _this.error = err.data;
                }).finally(function () {
                    _this.firstCall = true;
                });
            } else {
                _this.removedCustomer = null;
            }
        };

        this.getOtherCustomer = function () {
            if (_this.encryptedIban && _this.encryptedLeavingCustomerId) {
                delete _this.error;
                CustomerService.getOtherCustomerByCustomerId(_this.encryptedIban, _this.encryptedLeavingCustomerId).then(function (customer) {
                    _this.customer = customer;
                }).catch(function (err) {
                    var errData = err.data;
                    if (angular.isDefined(_this.onError)) {
                        _this.onError(_this, errData);
                    }
                    _this.error = err.data;
                }).finally(function () {
                    _this.firstCall = true;
                });
            } else {
                _this.customer = null;
            }
        };

        this.$onChanges = function () {
            _this.isLoading = true;
            _this.getCustomer();
            _this.getOtherCustomer();
        };

        this.$onInit = function () {
            _this.properties = propertyService.properties('pAccountHoldersBase.remove.generic');
            _this.getCustomer();
            _this.getOtherCustomer();
        };
    }
}());
