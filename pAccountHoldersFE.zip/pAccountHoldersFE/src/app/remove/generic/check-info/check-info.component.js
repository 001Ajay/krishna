/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.remove.generic')
        .component('removeCheckInfo', {
            bindings: {
                encryptedIban: '<?',
                encryptedLeavingCustomerId: '<?',
                hasCheckErrors: '=?',     // Indicates when check has any errors, eg, when we cannot continue in  the process
                hasComponentError: '=?', // Indicates when a error occurent when retreiving data
                onError: '&?'
            },
            templateUrl: 'app/remove/generic/check-info/check-info.html',
            controller: CheckInfoController
        });

    function CheckInfoController(CheckAccountRemove, propertyService) {
        var _this = this;

        this.getCheck = function () {

            _this.canContinue = false;
            if (_this.encryptedIban && _this.encryptedLeavingCustomerId) {
                _this.hasValidData = false;
                CheckAccountRemove.getAccountCheck(_this.encryptedIban, _this.encryptedLeavingCustomerId)
                    .then(function (checkAccountData) {
                        _this.hasValidData = true;
                        _this.error = null;
                        _this.hasComponentError = false;
                        if (checkAccountData.status !== 'OK') {
                            _this.checkOrVerifyErrors = checkAccountData.errors;
                            _this.hasCheckErrors = true;
                        } else {
                            _this.canContinue = true;
                            _this.checkOrVerifyErrors = null;
                            _this.hasCheckErrors = false;
                        }
                    })
                    .catch(function (err) {
                        if (angular.isDefined(_this.onError)) {
                            _this.onError(_this, err);
                        }
                        _this.error = err.data;
                        _this.hasComponentError = true;
                    })
                    .finally(function () {
                    });
            } else {
                _this.hasCheckErrors = false;
                _this.checkOrVerifyErrors = null;
                _this.hasComponentError = true;
            }
        };

        this.getVerifyMsg = function (errObj) {
            var noNum = errObj.code.replace(/[0-9]/g, '');
            return _this.properties['MSG_CheckVerify_' + errObj.code] ? // then
                _this.properties['MSG_CheckVerify_' + errObj.code] : // else
                _this.properties['MSG_CheckVerify_' + noNum]+ ' ('+errObj.code+')';
        };

        this.$onChanges = function (/* jshint unused: false */ changeObj) {
            _this.getCheck();
        };

        this.reCheck = function () {
            _this.getCheck();
        };

        this.$onInit = function () {
            _this.canContinue = false;
            _this.hasCheckErrors = false;
            _this.checkOrVerifyErrors = null;
            _this.hasComponentError = true;
            _this.hasValidData = false;
            _this.properties = propertyService.properties('pAccountHoldersBase.remove.generic');
            _this.getCheck();
        };
    }
}());
