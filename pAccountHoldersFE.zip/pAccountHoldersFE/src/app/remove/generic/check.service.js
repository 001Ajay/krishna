/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.remove.generic')
        .service('CheckAccountRemove', CheckAccountRemove);

    function CheckAccountRemove($http) {
        var checkAccount = function (encryptedIban, encryptedLeavingCustomerId) {
            return $http({
                params: {
                    encryptedIban:  encryptedIban,
                    encryptedLeavingCustomerId:  encryptedLeavingCustomerId
                },
                method: 'GET',
                url: '/api/current-accounts/requests/account-holders/check/remove',
            });
        };

        this.getAccountCheck = function (encryptedIban, encryptedLeavingCustomerId) {
            return checkAccount(encryptedIban, encryptedLeavingCustomerId).then(function (resp) {
                return resp.data;
            });
        };
    }

    CheckAccountRemove.$inject = ['$http'];

}());
