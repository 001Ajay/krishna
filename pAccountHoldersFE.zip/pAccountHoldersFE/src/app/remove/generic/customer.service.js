/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.remove.generic')
        .service('CustomerService', CustomerService);

    function CustomerService($http, $cacheFactory) {
        $cacheFactory('CustomerServiceCache', {
                maxAge: 60 * 5 * 1000,
                deleteOnExpire: 'aggressive'
            }
        );

        var customersResource = function (encryptedIban) {
            return $http({
                params: {
                  encryptedIban:  encryptedIban
                },
                method: 'GET',
                url: '/api/current-accounts/requests/account-holders/customers/byIban',
                cache: $cacheFactory.get('CustomerServiceCache')
            });
        };

        this.getByIban = function (encryptedIban) {
            return customersResource(encryptedIban).then(function (response) {
                return response.data;
            });
        };

        this.getCustomerByCustomerId = function (encryptedIban, encryptedCustomerId) {
            return customersResource(encryptedIban).then(function (response) {
                for (var i=0;i<response.data.length;i++) {
                    if (response.data[i].encryptedCustomerId === encryptedCustomerId) {
                        return response.data[i];
                    }
                }
                return null;
            });
        };

        this.getOtherCustomerByCustomerId = function (encryptedIban, encryptedCustomerId) {
            return customersResource(encryptedIban).then(function (response) {
                for (var i=0;i<response.data.length;i++) {
                    if (response.data[i].encryptedCustomerId !== encryptedCustomerId) {
                        return response.data[i];
                    }
                }
                return null;
            });
        };
    }

    CustomerService.$inject = ['$http', '$cacheFactory'];

}());
