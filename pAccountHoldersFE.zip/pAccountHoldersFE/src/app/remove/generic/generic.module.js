/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.remove.generic', [
        'ingGlobal', 'ngSanitize'
    ]);

}());