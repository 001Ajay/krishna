/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.remove.generic')
        .service('EligibleAccountsRemove', EligibleAccountsRemove);

    function EligibleAccountsRemove($http, $cacheFactory) {
        var _this = this;
        $cacheFactory('EligibleAccountsRemoveCache', {
                maxAge: 60 * 5 * 1000,
                deleteOnExpire: 'aggressive'
            }
        );

        var getEligibleAccounts = function () {
            return $http({
                method: 'GET',
                url: '/api/current-accounts/requests/account-holders/eligible-accounts/remove',
                cache: $cacheFactory.get('EligibleAccountsRemoveCache')
            });
        };

        this.getCustomers = function () {
            return getEligibleAccounts().then(function (resp) {
                return resp.data;
            });
        };

        this.getAllAccounts = function () {
            return getEligibleAccounts()
                .then(function (resp) {
                    var accounts = resp.data
                        .map(function (customer) {
                            return customer.accounts;
                        });
                    // Flatten accounts
                    accounts = [].concat.apply([], accounts);

                    // Remove duplicates
                    return accounts.filter(function (account, i) {
                        return accounts.map(function (e) {
                            return e.iban;
                        }).indexOf(account.iban) === i;
                    });
                });
        };

        this.getOtherCustomer = function (iban) {
            return getEligibleAccounts()
                .then(function (resp) {
                    return resp.data
                        .filter(function (customer) {
                            return customer.accounts
                                .map(function (account) {
                                    return account.iban;
                                })
                                .indexOf(iban) === -1;
                        })[0];
                });
        };

        this.getAccountByEncryptedIban = function (encryptedIban) {
            return _this.getAllAccounts()
                .then(function (accounts) {
                    return accounts.filter(function (account) {
                        return account.encryptedIban === encryptedIban;
                    })[0];
                });
        };
    }

    EligibleAccountsRemove.$inject = ['$http', '$cacheFactory'];

}());
