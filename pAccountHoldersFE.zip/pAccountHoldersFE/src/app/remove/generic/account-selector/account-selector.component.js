/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.remove.generic')
        .component('removeAccountSelector', {
            bindings: {
                encryptedIban: '=?',
                onUpdate: '&?',
                onError: '&?'
            },
            templateUrl: 'app/remove/generic/account-selector/account-selector.html',
            controller: AccountSelectorController
        });

    function AccountSelectorController($scope, EligibleAccountsRemove, propertyService, $rootScope) {
        var _this = this;
        _this.items = null;
        _this.checkOrVerifyErrors = null;
        _this.firstCallDone = false;

        _this.$onDestroy = function() {
            _this.ingRichSelectChangeAccount();
        };

        _this.ingRichSelectChangeAccount = $scope.$on('ing-rich-select-change-account', function (e, data) {
            if (_this.encryptedIban !== data.encryptedIban) {
                _this.encryptedIban = data.encryptedIban;

                if (angular.isDefined(_this.onUpdate)) {
                    var account = null;
                    _this.accounts.some(function (obj) {
                        return obj.iban === data.prop4 ? account = obj : false;
                    });
                    _this.onUpdate({account: account});
                }
            }
        });

        this.$onInit = function () {
            _this.error = null;
            _this.isLoading = true;
            _this.properties = propertyService.properties('pAccountHoldersBase.remove.generic');

            EligibleAccountsRemove.getAllAccounts()
                .then(function (accounts) {
                    _this.accounts = accounts;

                    // set rich-select items
                    _this.items = _this.accounts.map(function (account) {
                        return {
                            prop1: (angular.isDefined(account.name) && account.name.trim().length !== 0)?account.name.replace('\u00AC', _this.properties.MSG_EnOf):'-',
                            prop4: account.iban,
                            encryptedIban: account.encryptedIban
                        };
                    });

                    if (angular.isDefined(_this.encryptedIban) && _this.encryptedIban) {
                        var index = -1;
                        _this.items.some(function (obj, i) {
                            return obj.encryptedIban === _this.encryptedIban ? index = i : false;
                        });
                        if (index >= 0) {
                            _this.items[index].selected = true;
                        }
                    }

                    if (_this.items.length === 1) {
                        _this.items[0].selected = true;
                        $rootScope.$broadcast('ing-rich-select-change-account', _this.items[0]);
                    }
                })
                .catch(function (err) {
                    var errData = err.data;
                    if (angular.isDefined(_this.onError)) {
                        _this.onError(_this, errData);
                    }
                    _this.error = err.data;
                })
                .finally(function () {
                    _this.isLoading = false;
                });
        };
    }
}());
