/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.add.generic')
        .component('newAccountHolderInfo', {
            bindings: {
                selectedIban: '<',
                onError: '&?'
            },
            templateUrl: 'app/add/generic/new-account-holder-info/new-account-holder-info.html',
            controller: NewAccountHolderInfoController
        });

    function NewAccountHolderInfoController(EligibleAccountsAdd) {
        var _this = this;

        this.$onChanges = function (changesObj) {
            _this.isLoading = true;
            if (changesObj.selectedIban && changesObj.selectedIban.currentValue) {
                var selectedIban = changesObj.selectedIban.currentValue;
                EligibleAccountsAdd.getOtherCustomer(selectedIban)
                    .then(function (customer) {
                        _this.customer = customer;
                    })
                    .catch(function (error) {
                        _this.error = error;
                        if (angular.isDefined(_this.onError)) {
                            _this.onError(_this, error);
                        }
                    })
                    .finally(function () {
                        _this.isLoading = false;
                    });
            } else {
                _this.customer = null;
            }
        };
    }
}());