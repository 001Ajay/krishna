/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.add.generic')
        .service('CheckAccountAdd', CheckAccountAdd);

    function CheckAccountAdd($http) {
        var checkAccount = function (encryptedIban) {
            return $http({
                params: {
                  encryptedIban:  encryptedIban
                },
                method: 'GET',
                url: '/api/current-accounts/requests/account-holders/check/add',
            });
        };

        this.getAccountCheck = function (encryptedIban) {
            return checkAccount(encryptedIban).then(function (resp) {
                return resp.data;
            });
        };
    }

    CheckAccountAdd.$inject = ['$http'];

}());
