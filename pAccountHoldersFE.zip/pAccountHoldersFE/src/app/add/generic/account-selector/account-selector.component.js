/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.add.generic')
        .component('addAccountSelector', {
            bindings: {
                selectedIban: '=?',
                onUpdate: '&?',
                onError: '&?'
            },
            templateUrl: 'app/add/generic/account-selector/account-selector.html',
            controller: AccountSelectorController
        });

    function AccountSelectorController($scope, EligibleAccountsAdd, CheckAccountAdd, propertyService, $rootScope) {
        var _this = this;
        _this.items = null;
        _this.checkOrVerifyErrors = null;
        _this.firstCallDone = false;

        $scope.$on('ing-rich-select-change-account', function (e, data) {
            _this.isLoading = true;
            _this.firstCallDone = true; // This is needed to prevent a flash of 'graag invullen'

            CheckAccountAdd.getAccountCheck(data.encryptedIban)
                .then(function (checkAccountData) {
                    if (checkAccountData.status === 'OK') {
                        _this.checkOrVerifyErrors = null;
                        _this.selectedIban = data.prop4;

                        if (angular.isDefined(_this.onUpdate)) {
                            var account = null;

                            _this.accounts.some(function (obj, /* jshint unused: false */ i) {
                                return obj.iban === _this.selectedIban ? account = obj : false;
                            });
                            _this.onUpdate({account: account});
                        }
                    } else {
                        _this.checkOrVerifyErrors = checkAccountData.details;
                        _this.selectedIban = null;
                        if (angular.isDefined(_this.onError)) {
                            _this.onError(_this, null);
                        }
                    }
                })
                .catch(function (error) {
                    if (angular.isDefined(_this.onError)) {
                        _this.onError(_this, error);
                    }
                    _this.error = error;
                })
                .finally(function () {
                    _this.isLoading = false;
                });
        });

        this.$onInit = function () {
            _this.error = null;
            _this.isLoading = true;
            _this.properties = propertyService.properties('pAccountHoldersBase.add.generic');

            EligibleAccountsAdd.getAllAccounts()
                .then(function (accounts) {
                    _this.accounts = accounts;

                    // set rich-select items
                    _this.items = _this.accounts.map(function (account) {
                        return {
                            prop1: account.productType,
                            prop4: account.iban,
                            prop5: account.name,
                            encryptedIban: account.encryptedIban
                        };
                    });

                    if (angular.isDefined(_this.selectedIban)) {
                        var index = -1;
                        _this.items.some(function (obj, i) {
                            return obj.prop4 === _this.selectedIban ? index = i : false;
                        });
                        if (index >= 0) {
                            _this.items[index].selected = true;
                        }
                    }

                    if (_this.items.length === 1) {
                        _this.items[0].selected = true;
                        $rootScope.$broadcast('ing-rich-select-change-account', _this.items[0]);
                    }
                })
                .catch(function (err) {
                    if (angular.isDefined(_this.onError)) {
                        _this.onError(_this,  err.data);
                    }
                    var message = _this.properties['MSG_EligibleAccounts_' + err.data.errorId];
                    if (message) {
                        _this.error = message;
                    } else {
                        _this.error = 'Er is een fout opgetreden bij het ophalen van de rekeningen';
                    }
                })
                .finally(function () {
                    _this.isLoading = false;
                });
        };
    }
}());
