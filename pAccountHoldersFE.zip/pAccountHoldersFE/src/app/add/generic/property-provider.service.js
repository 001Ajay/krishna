/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.add.generic')
        .config(['propertyServiceProvider',
            function (propertyServiceProvider) {
                propertyServiceProvider.add('pAccountHoldersBase.add.generic', {
                    // Error messages
                    MSG_EligibleAccounts_001: 'Onjuist aantal klanten in focus, er dienen 2 klanten opgevoerd te zijn in LISA',

                    MSG_CheckVerify_0001: 'Een of meerdere fouten gevonden.',
                    MSG_CheckVerify_0002: 'Product moet van het type betaalrekening zijn',
                    MSG_CheckVerify_0003: 'Klant heeft teveel betaal rekeningen',
                    MSG_CheckVerify_0004: 'Rekening moet van het type en/of zijn',
                    MSG_CheckVerify_0005: 'Klant heeft gekoppelde producten',
                    MSG_CheckVerify_0006: 'Klant heeft complexe producten'

                });
            }
        ]);

}());



