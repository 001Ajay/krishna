/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.add.generic')
        .service('EligibleAccountsAdd', EligibleAccountsAdd);

    function EligibleAccountsAdd($http, $cacheFactory) {
        $cacheFactory('EligibleAccountsAddCache', {
                maxAge: 60 * 5 * 1000,
                deleteOnExpire: 'aggressive'
            }
        );

        var getEligibleAccounts = function () {
            return $http({
                method: 'GET',
                url: '/api/current-accounts/requests/account-holders/eligible-accounts/add',
                cache: $cacheFactory.get('EligibleAccountsAddCache')
            });
        };

        this.getCustomers = function () {
            return getEligibleAccounts().then(function (resp) {
                return resp.data;
            });
        };

        this.getAllAccounts = function () {
            return getEligibleAccounts()
                .then(function (resp) {
                    var accounts = resp.data
                        .map(function (customer) {
                            return customer.accounts;
                        });
                    return [].concat.apply([], accounts); // flatten accounts
                });
        };

        this.getOtherCustomer = function (iban) {
            return getEligibleAccounts()
                .then(function (resp) {
                    return resp.data
                        .filter(function (customer) {
                            return customer.accounts
                                .map(function (account) {
                                    return account.iban;
                                })
                                .indexOf(iban) === -1;
                        })[0];
                });
        };
    }

    EligibleAccountsAdd.$inject = ['$http', '$cacheFactory'];

}());
