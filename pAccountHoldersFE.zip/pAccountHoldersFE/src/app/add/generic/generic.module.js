/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.add.generic', [
        'ingGlobal'
    ]);

}());