/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.add.lisa')
        .component('appAddLisa', {
            templateUrl: 'app/add/lisa/app-add-lisa.html',
            controller: AppAddLisaController
        });

    function AppAddLisaController(navigatorService) {

        this.state = {

        };

        this.step1Complete = function() {
            var navCtrl = navigatorService.get('pAccountHoldersNavCtrl');
            navCtrl.allow('step1', 'step2');
            navCtrl.restrict('step2', 'step3');
        };
    }
}());
