/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.add.lisa')
        .component('finished', {
            templateUrl: 'app/add/lisa/finished/finished.html',
            controller: AddFinishedController
        });

    function AddFinishedController() {

    }
}());
