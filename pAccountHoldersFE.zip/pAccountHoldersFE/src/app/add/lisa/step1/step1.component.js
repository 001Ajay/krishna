/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.add.lisa')
        .component('step1', {
            bindings: {
                selectedIban: '=?',
                onComplete: '&?',
                onNavigationController: '&?'
            },
            templateUrl: 'app/add/lisa/step1/step1.html',
            controller: Step1Controller
        });

    function Step1Controller($scope, navigatorService, /* jshint unused: false */ richSelectOrderService) {
        var _this = this;

        this.onIbanSelected = function (account) {
            this.selectedIban = account.iban;
            if (angular.isDefined(_this.onComplete)) {
                _this.onComplete();
            }
        };

        this.$onInit = function () {
            _this.navigationController = navigatorService.get('pAccountHoldersNavCtrl');
            if (angular.isDefined(_this.onNavigationController)) {
                _this.onNavigationController({controller: _this.navigationController});
            }

            _this.navigationController.addCallback('step1', _this.nextCallback);
        };

        this.onError = function (/* jshint unused: false */ component, error) {
            _this.navigationController.restrict('step1', 'step2');
        };

        this.nextCallback = function () {
            if (_this.step1Form.$valid) {
                return true;
            } else {
                $scope.$broadcast('checkValidity');
                return false;
            }
        };
    }
}());
