/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.add.lisa')
        .component('step2', {
            bindings: {
                selectedIban: '=?',
                onComplete: '&?',
                onNavigationController: '&?'
            },
            templateUrl: 'app/add/lisa/step2/step2.html',
            controller: Step2Controller
        });

    function Step2Controller(/* jshint unused: false */ navigatorService) {
        var _this = this;

    }
}());
