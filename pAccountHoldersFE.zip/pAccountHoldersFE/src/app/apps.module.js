/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersAddLisaApp', [
        'pAccountHoldersBase.add.lisa'
    ]);

    angular.module('pAccountHoldersRemoveLisaApp', [
        'pAccountHoldersBase.remove.lisa'
    ]);

}());
