/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.generic')
        .service('CramTanService', CramTanService);

    function CramTanService($http) {
        return {
            initiate: function (encryptedIban, encryptedLeavingCustomerId) {
                return $http({
                    method: 'POST',
                    url: '/api/current-accounts/requests/account-holders/cram/initiate',
                    data: {
                        encryptedIban: encryptedIban,
                        encryptedLeavingCustomerId: encryptedLeavingCustomerId
                    }
                }).then(function (response) {
                    return response.data;
                });
            }
        };
    }

    CramTanService.$inject = ['$http'];

}());
