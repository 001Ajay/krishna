/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.generic', []);

}());