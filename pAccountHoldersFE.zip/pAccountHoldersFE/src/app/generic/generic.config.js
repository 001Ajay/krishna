/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.generic')
        .config(function ($httpProvider) {
            $httpProvider.useApplyAsync(true);
        });

}());

