/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.generic.lisa', [
        'pAccountHoldersBase.generic',
        'gApprovalCustomerAssistedDirective',
        'pAccountHoldersBase.remove.generic'
    ]);

}());