/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.generic.lisa')
        .component('ahNotification', {
            bindings: {
                propertyServiceName: '@',
                defaultMessage: '@?',
                messagePropValue: '<?',
                buttonPropValue: '@',
                onButtonClick: '&'
            },
            templateUrl: 'app/generic/lisa/notification/ahNotification.html',
            controller: AHNotificationController
        });

    function AHNotificationController(propertyService) {
        var _this = this;

        this.$onChanges = function () {
            try {
                _this.properties = _this.propertyService.properties(_this.propertyServiceName);
                _this.messageValue = _this.properties[_this.messagePropValue] ?
                    _this.properties[_this.messagePropValue] : _this.defaultMessage;
            } catch (err) {
                _this.messageValue = _this.defaultMessage;
            }
        };

        this.$onInit = function() {
            _this.propertyService = propertyService;
            _this.properties = propertyService.properties(_this.propertyServiceName);
        };
    }
}());
