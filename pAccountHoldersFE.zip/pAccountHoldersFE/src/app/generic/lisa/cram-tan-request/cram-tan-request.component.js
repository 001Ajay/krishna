/* globals angular: false */
(function () {
    'use strict';

    angular.module('pAccountHoldersBase.generic.lisa')
        .component('cramTanRequest', {
            bindings: {
                processName: '@',              // Cram process name, incase you want to use this component multiple times
                encryptedIban: '<',            // The iban of the en/of account
                encryptedLeavingCustomerId: '<',      // customerId we want to remove
                onError: '&?',
                onComplete: '&',
                onCanceled: '&',
                properties: '@'
            },
            templateUrl: 'app/generic/lisa/cram-tan-request/cram-tan-request.html',
            controller: CramTanRequestController
        });

    function CramTanRequestController($scope, propertyService, CramTanService) {
        var _this = this;

        this.$onDestroy = function () {
            _this.authorisedFn();
            _this.cancelledFn();
            _this.completedFn();
            _this.errorFn();
        };

        this.initiateCramRequest = function () {
            if (_this.encryptedIban && _this.encryptedLeavingCustomerId) {
                _this.isLoading = true;
                    CramTanService.initiate(_this.encryptedIban, _this.encryptedLeavingCustomerId).then(function (response) {
                        _this.encryptedAuthorizationReferenceId = response.encryptedReferenceId;
                        _this.dataWasLoaded = true;
                        _this.error = null;
                        if (!angular.isDefined(_this.encryptedAuthorizationReferenceId)) {
                            _this.error = 'Reference ID was empty';
                            if (angular.isDefined(_this.onError)) {
                                _this.onError(_this, _this.error);
                            }
                        }
                    }).catch(function (error) {
                        if (angular.isDefined(_this.onError)) {
                            _this.onError(_this, error);
                        }
                        _this.error = error;
                    }).finally(function () {
                        _this.isLoading = false;
                    });
            } else {
                _this.encryptedAuthorizationReferenceId = null;
            }
        };

        this.$onInit = function () {
            _this.properties = propertyService.properties(_this.properties);

            _this.encryptedAuthorizationReferenceId = null;
            _this.cramExecutedSuccessfully = false;
            _this.dataWasLoaded = false;

            /*
             START: Riviera events
            */
            _this.authorisedFn = $scope.$on('authorised.assistedAuth.' + _this.processName, function () {
                _this.cramExecutedSuccessfully = true;
                _this.assistedAuthCancelled = false;
                if (angular.isDefined(_this.onComplete)) {
                    _this.onComplete(_this);
                }
            });

            _this.cancelledFn = $scope.$on('cancelled.assistedAuth.' + _this.processName, function () {
                _this.cramExecutedSuccessfully = false;
                _this.assistedAuthCancelled = true;
                if (angular.isDefined(_this.onCanceled)) {
                    _this.onCanceled(_this);
                }
            });

            _this.completedFn = $scope.$on('completed.assistedAuth.' + _this.processName, function () {
                /*
                 When you receive a event for 'Completed', that means the overall customer
                 request is not yet fully processed because of some reason. One reason might be that
                 one or more parties also needs to approve the same customer request. Another reason
                 could be that on CRAM side some asynchronous processing on customer request in progress
                 and the final state is not yet achieved. So in cases you know that there is no party
                 remaining to approve the request but event you have received is 'Completed',
                 you must check the latest status of customer request with CRAM. A event for 'Completed'
                 can only assure you that a particular party's action (approval/cancel) was successfully
                 accepted by CRAM since directive received 'OK' as processing status.
                 */
                _this.cramExecutedSuccessfully = true;
                _this.assistedAuthCancelled = false;
                if (angular.isDefined(_this.onComplete)) {
                    _this.onComplete(_this);
                }
            });

            _this.errorFn = $scope.$on('error.assistedAuth.' + _this.processName, function (/* jshint unused: false */ error) {
                //The structure of the error object:
                //{
                //    'errorCode': <<errorCodeString>>,
                //    'message': '<<error message>>'
                //
                _this.cramExecutedSuccessfully = false;
                if (angular.isDefined(_this.onError)) {
                    _this.onError(_this);
                }
            });
            /*
             END: Riviera events
            */

            //http-get on /status sets the http tokens needed for the http-post action that follows
            this.initiateCramRequest();
        };
    }
}());
