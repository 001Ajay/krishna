/* globals angular,describe,beforeEach,module,it,expect,inject,jasmine,spyOn,fail: false */
'use strict';

describe('Add - The app-add-lisa component', function() {

    var ctrl, $componentController, $rootScope;

    var navCtrlMock = {
        allow: jasmine.createSpy('allow'),
        restrict: jasmine.createSpy('restrict'),
        addCallback: jasmine.createSpy('addCallback'),
        navigate: jasmine.createSpy('navigate')
    };

    var navigatorServiceMock = {
        get: jasmine.createSpy('get').and.returnValue(navCtrlMock)
    };

    beforeEach(function() {
        module('pAccountHoldersBase.add.lisa');
        inject(function(_$componentController_, _$rootScope_) {
            $componentController = _$componentController_;
            $rootScope = _$rootScope_;
        });
        ctrl = $componentController('appAddLisa',
            {
                navigatorService: navigatorServiceMock
            });
    });

    describe('regarding the initialization of the component', function() {
        it('should be instantiated', function() {
            expect(ctrl).toBeDefined();
        });
    });

    describe('regarding the step1Complete method', function() {
        beforeEach(function() {
            ctrl.step1Complete();
        });
        it('should call the relevant methods on the navigation controller', function () {
            expect(navCtrlMock.allow).toHaveBeenCalled();
            expect(navCtrlMock.restrict).toHaveBeenCalled();
        });
    });
});
