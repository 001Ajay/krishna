/* globals angular,describe,beforeEach,module,it,expect,inject,jasmine,spyOn,fail: false */
'use strict';


describe('Add - The step2 component', function () {

    var ctrl, $rootScope, $q;

    var navCtrl = {
        allow: jasmine.createSpy('allow'),
        restrict: jasmine.createSpy('restrict'),
        addCallback: jasmine.createSpy('addCallback'),
        navigate: jasmine.createSpy('navigate')
    };

    var navigatorServiceMock = {
        get: jasmine.createSpy('get').and.returnValue(navCtrl)
    };

    beforeEach(function () {
        module('pAccountHoldersBase.add.lisa');
        inject(function ($componentController, _$rootScope_, _$q_) {
            $q = _$q_;
            $rootScope = _$rootScope_;
            ctrl = $componentController('step2', {
                $scope: $rootScope.$new(),
                navigatorService: navigatorServiceMock
            });
        });
    });

    describe('regarding the construction of the component', function () {
        it('should be instantiated', function () {
            expect(ctrl).toBeDefined();
        });
    });
});
