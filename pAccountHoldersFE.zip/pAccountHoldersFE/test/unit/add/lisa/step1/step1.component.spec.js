/* globals angular,describe,beforeEach,module,it,expect,inject,jasmine,spyOn,fail: false */
'use strict';

describe('Add - The step1 component', function () {

    var ctrl, $componentController, $rootScope, $q;

    var navCtrlMock = {
        allow: jasmine.createSpy('allow'),
        restrict: jasmine.createSpy('restrict'),
        addCallback: jasmine.createSpy('addCallback'),
        navigate: jasmine.createSpy('navigate')
    };

    var navigatorServiceMock = {
        get: jasmine.createSpy('get').and.returnValue(navCtrlMock)
    };

    var onCompleteMock = jasmine.createSpy('onComplete');

    var onNavigationControllerMock = jasmine.createSpy('onNavigationController');

    beforeEach(function () {
        module('pAccountHoldersBase.add.lisa');
        inject(function (_$componentController_, _$rootScope_, _$q_) {
            $componentController = _$componentController_;
            $q = _$q_;
            $rootScope = _$rootScope_;
            ctrl = $componentController('step1', {
                    $scope: $rootScope.$new(),
                    navigatorService: navigatorServiceMock
                },
                {
                    onComplete: onCompleteMock,
                    onNavigationController: onNavigationControllerMock
                });
        });
    });

    describe('regarding the construction of the component', function () {
        it('should be instantiated', function () {
            expect(ctrl).toBeDefined();
        });
    });

    describe('regarding the initialization of the component', function () {
        describe('when the onNavigationController binding is defined', function () {
            beforeEach(function () {
                ctrl.$onInit();
            });
            it('should call the onNavigationController method with the navigationController as a parameter', function () {
                expect(onNavigationControllerMock).toHaveBeenCalledWith({controller: navCtrlMock});
            });
        });

        describe('when the onNavigationController binding is not defined', function () {
            beforeEach(function () {
                ctrl = $componentController('step1', {
                    $scope: $rootScope.$new(),
                    navigatorService: navigatorServiceMock
                });
                onNavigationControllerMock.calls.reset();
                ctrl.$onInit();
            });
            it('should not call the onNavigationController method', function () {
                expect(onNavigationControllerMock).not.toHaveBeenCalled();
            });
        });
    });

    describe('regarding the onIbanSelected method', function () {
        describe('when it is called and the onComplete binding is defined', function () {
            beforeEach(function () {
                ctrl.onIbanSelected({holder: 0});
            });
            it('should call the onComplete method', function () {
                expect(onCompleteMock).toHaveBeenCalled();
            });
        });

        describe('when the onComplete binding is not defined', function () {
            beforeEach(function () {
                ctrl = $componentController('step1', {
                    $scope: $rootScope.$new(),
                    navigatorService: navigatorServiceMock
                });
                onCompleteMock.calls.reset();
                ctrl.$onInit();
                ctrl.onIbanSelected({holder: 0});
            });
            it('should not call the onComplete method', function () {
                expect(onCompleteMock).not.toHaveBeenCalled();
            });
        });
    });

    describe('regarding the onError method', function () {
        beforeEach(function () {
            ctrl.$onInit();
            ctrl.onError();
        });
        it('should call restrict on the navigationController with the correct steps as parameters', function () {
            expect(navCtrlMock.restrict).toHaveBeenCalledWith('step1', 'step2');
        });
    });

    describe('regarding the nextCallback method', function () {
        describe('when step1Form is valid', function () {
            beforeEach(function () {
                ctrl.step1Form = {$valid: true};
            });
            it('should return true', function () {
                var result = ctrl.nextCallback();
                expect(result).toBe(true);
            });
        });

        describe('when step1Form is invalid', function () {
            beforeEach(function () {
                ctrl.step1Form = {$valid: false};
            });
            it('should return true', function () {
                var result = ctrl.nextCallback();
                expect(result).toBe(false);
            });
        });
    });
});
