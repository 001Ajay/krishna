/* globals angular,describe,beforeEach,module,it,expect,inject,jasmine,spyOn,fail: false */
'use strict';

describe('Add - The finished component', function() {

    var $componentController;

    beforeEach(function() {
        module('pAccountHoldersBase.add.lisa');
        inject(function(_$componentController_) {
            $componentController = _$componentController_;
        });
    });

    describe('regarding the initialization of the component', function() {
        var ctrl;
        beforeEach(function() {
            ctrl = $componentController('finished', {});
        });
        it('should be instantiated', function() {
            expect(ctrl).toBeDefined();
        });
    });

});
