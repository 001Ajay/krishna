/* globals angular,describe,beforeEach,module,it,expect,inject,jasmine,spyOn,fail: false */
'use strict';


describe('Add - The account-selector component', function () {

    var ctrl, $rootScope, $q, EligibleAccountsAdd, CheckAccountAdd;

    var onUpdateMock = jasmine.createSpy('onUpdate');
    var onErrorMock = jasmine.createSpy('onError');

    beforeEach(function () {
        module('pAccountHoldersBase.add.generic');
        inject(function (_$timeout_, $componentController, _$rootScope_, _$q_, _EligibleAccountsAdd_, _CheckAccountAdd_) {
            $q = _$q_;
            $rootScope = _$rootScope_;
            EligibleAccountsAdd = _EligibleAccountsAdd_;
            CheckAccountAdd = _CheckAccountAdd_;
            ctrl = $componentController('addAccountSelector', {
                    $scope: $rootScope.$new()
                },
                {
                    onUpdate: onUpdateMock,
                    onError: onErrorMock
                });
        });
    });

    describe('regarding the construction of the component', function () {
        it('should be instantiated', function () {
            expect(ctrl).toBeDefined();
        });
    });

    describe('regarding the initialization of the component', function () {
        describe('when the call for getting the eligible accounts is successful and an IBAN is not selected', function () {
            var result = [
                {iban: 'account1'},
                {iban: 'account2'}
            ];
            beforeEach(function () {
                spyOn(EligibleAccountsAdd, 'getAllAccounts').and.returnValue($q.resolve(result));
                ctrl.$onInit();
                $rootScope.$apply();
            });
            it('should set the accounts on the controller as items for the rich select', function () {
                expect(ctrl.items[0].prop4).toEqual('account1');
                expect(ctrl.items[1].prop4).toEqual('account2');
            });

        });

        describe('when the call for getting the eligible accounts is successful and an IBAN is selected', function () {
            var result = [
                {iban: 'account1'},
                {iban: 'account2'}
            ];
            beforeEach(function () {
                spyOn(EligibleAccountsAdd, 'getAllAccounts').and.returnValue($q.resolve(result));
                ctrl.selectedIban = 'account1';
                ctrl.$onInit();
                $rootScope.$apply();
            });
            it('should set the accounts on the controller as items for the rich select', function () {
                expect(ctrl.items[0].prop4).toEqual('account1');
                expect(ctrl.items[1].prop4).toEqual('account2');
            });
            it('should set the account with the selected IBAN as selected', function () {
                expect(ctrl.items[0].selected).toBe(true);
            });

        });

        describe('when the call for getting the eligible accounts fails with a known error', function () {
            beforeEach(function () {
                spyOn(EligibleAccountsAdd, 'getAllAccounts').and.returnValue($q.reject({data: {errorId: '001'}}));
                ctrl.$onInit();
                ctrl.properties = {
                    MSG_EligibleAccounts_001: 'Onjuist aantal klanten in focus'
                };
                $rootScope.$apply();
            });
            it('should set the error on the controller', function () {
                expect(ctrl.error).toEqual('Onjuist aantal klanten in focus');
                expect(onErrorMock).toHaveBeenCalled();
            });
        });

        describe('when the call for getting the eligible accounts fails with an unknown error', function () {
            beforeEach(function () {
                spyOn(EligibleAccountsAdd, 'getAllAccounts').and.returnValue($q.reject({data: {errorId: '001'}}));
                ctrl.$onInit();
                ctrl.properties = {};
                $rootScope.$apply();
            });
            it('should set the error on the controller', function () {
                expect(ctrl.error).toEqual('Er is een fout opgetreden bij het ophalen van de rekeningen');
                expect(onErrorMock).toHaveBeenCalled();
            });
        });
    });

    describe('regarding selecting the account', function () {
        describe('when an account gets selected and it was ok', function () {
            var eligibleAccountsResult;
            var checkAccountsResult;
            beforeEach(function () {
                var result = [
                    {iban: 'account1'},
                    {iban: 'account2'}
                ];

                var checkResult = {
                    "status": "OK",
                    "message": null,
                    "details": null
                };

                eligibleAccountsResult = $q.resolve(result);
                checkAccountsResult = $q.resolve(checkResult);
                spyOn(EligibleAccountsAdd, 'getAllAccounts').and.returnValue(eligibleAccountsResult);
                spyOn(CheckAccountAdd, 'getAccountCheck').and.returnValue(checkAccountsResult);
                ctrl.$onInit();
            });
            it('should set the selected account IBAN on the controller', function () {
                eligibleAccountsResult.then(function () {
                    $rootScope.$broadcast('ing-rich-select-change-account', {prop4: 'account1'});
                    checkAccountsResult.then(function () {
                        expect(ctrl.selectedIban).toEqual('account1');
                    });
                });
                $rootScope.$apply();
            });
        });

        describe('when only one account get\'s loaded it was ok', function () {
            var eligibleAccountsResult;
            var checkAccountsResult;
            beforeEach(function () {
                var result = [
                    {iban: 'account1'}
                ];
                var checkResult = {
                    "status": "OK",
                    "message": null,
                    "details": null
                };
                eligibleAccountsResult = $q.resolve(result);
                checkAccountsResult = $q.resolve(checkResult);
                spyOn(EligibleAccountsAdd, 'getAllAccounts').and.returnValue(eligibleAccountsResult);
                spyOn(CheckAccountAdd, 'getAccountCheck').and.returnValue(checkAccountsResult);
                ctrl.$onInit();
            });
            it('should set the selected account IBAN on the controller', function () {
                eligibleAccountsResult.then(function () {
                    checkAccountsResult.then(function () {
                        expect(ctrl.selectedIban).toEqual('account1');
                    });
                });
                $rootScope.$apply();
            });
        });

        describe('when an account gets selected and it was an invalid', function () {
            var eligibleAccountsResult;
            var checkAccountsResult;
            beforeEach(function () {
                var result = [
                    {iban: 'account1'},
                    {iban: 'account2'}
                ];

                var checkResult = {
                    "status": "ERROR",
                    "details": null
                };

                eligibleAccountsResult = $q.resolve(result);
                checkAccountsResult = $q.resolve(checkResult);
                spyOn(EligibleAccountsAdd, 'getAllAccounts').and.returnValue(eligibleAccountsResult);
                spyOn(CheckAccountAdd, 'getAccountCheck').and.returnValue(checkAccountsResult);
                ctrl.$onInit();
            });
            it('should not set the selected account IBAN on the controller', function () {
                eligibleAccountsResult.then(function () {
                    $rootScope.$broadcast('ing-rich-select-change-account', {prop4: 'account1'});
                    checkAccountsResult.then(function () {
                        expect(ctrl.selectedIban).toEqual(null);
                    });
                });
                $rootScope.$apply();
            });
        });

        describe('when an account gets selected and it was ok but checkFailed', function () {
            var eligibleAccountsResult;
            var checkAccountsResult;
            beforeEach(function () {
                var result = [
                    {iban: 'account1'},
                    {iban: 'account2'}
                ];

                eligibleAccountsResult = $q.resolve(result);
                checkAccountsResult = $q.reject('error');
                spyOn(EligibleAccountsAdd, 'getAllAccounts').and.returnValue(eligibleAccountsResult);
                spyOn(CheckAccountAdd, 'getAccountCheck').and.returnValue(checkAccountsResult);
                ctrl.$onInit();
            });
            it('should set the selected account IBAN on the controller', function () {
                eligibleAccountsResult.then(function () {
                    $rootScope.$broadcast('ing-rich-select-change-account', {prop4: 'account1'});
                    checkAccountsResult.then(function () {
                        fail('Should not succeed');
                    }).finally(function () {
                        expect(ctrl.error).toEqual('error');
                        expect(onErrorMock).toHaveBeenCalled();
                    });
                });
                $rootScope.$apply();
            });



            describe('On initialization of the compnent', function () {
                beforeEach(function () {
                    ctrl.onError = undefined;
                    onErrorMock.calls.reset();
                    $rootScope.$broadcast('ing-rich-select-change-account', {prop4: 'account1'});
                    $rootScope.$apply();
                });
                it('should not try to call the onError method', function () {
                    expect(onErrorMock).not.toHaveBeenCalled();
                });
            });
        });
    });

});
