/* globals angular,describe,beforeEach,module,it,expect,inject,jasmine,spyOn,fail: false */
'use strict';


describe('Add - The new-account-holder-info component', function () {

    var ctrl, $rootScope, $q, EligibleAccountsAdd;

    var onErrorMock = jasmine.createSpy('onError');

    beforeEach(function () {
        module('pAccountHoldersBase.add.generic');
        inject(function (_$timeout_, $componentController, _$rootScope_, _$q_, _EligibleAccountsAdd_) {
            $q = _$q_;
            $rootScope = _$rootScope_;
            EligibleAccountsAdd = _EligibleAccountsAdd_;
            ctrl = $componentController('newAccountHolderInfo', {
                $scope: $rootScope.$new(),
                    EligibleAccountsAdd: EligibleAccountsAdd
            },
            {
                onError: onErrorMock
            });
        });

    });

    describe('regarding the construction of the component', function () {
        it('should be defined', function () {
            expect(ctrl).toBeDefined();
        });
    });

    describe('regarding the $onChanged lifecycle method', function () {
        describe('when the selectedIban gets changed to an IBAN', function () {
            beforeEach(function () {
                var result = {
                    "correspondenceName": "Hr NI AzuratCT",
                    "born": "01-12-1945",
                    "accounts": [
                        {iban: 'account1'}
                    ]
                };
                spyOn(EligibleAccountsAdd, 'getOtherCustomer').and.returnValue($q.resolve(result));
                ctrl.$onChanges({selectedIban: {currentValue: 'account1'}});
                $rootScope.$apply();
            });
            it('should set the details of the other customer on the controller', function () {
                expect(ctrl.customer.correspondenceName).toEqual('Hr NI AzuratCT');
                expect(ctrl.customer.born).toEqual('01-12-1945');
            });
        });

        describe('when the selectedIban gets changed to an invalid value (null, undefined)', function () {
            beforeEach(function () {
                ctrl.$onChanges({selectedIban: {currentValue: undefined}});
                $rootScope.$apply();
            });
            it('should clear the details of the other customer on the controller', function () {
                expect(ctrl.customer).toBe(null);
            });
        });

        describe('when the selectedIban get changed and the service for getting the customer info fails', function () {
            beforeEach(function () {
                spyOn(EligibleAccountsAdd, 'getOtherCustomer').and.returnValue($q.reject('error!'));
                ctrl.$onChanges({selectedIban: {currentValue: 'account1'}});
                $rootScope.$apply();
            });
            it('should set the error on the controller', function () {
                expect(ctrl.error).toEqual('error!');
            });
        });
    });
});
