#Unit tests
Everything in this folder following the pattern `**/*.spec.js` will be run by karma

#Example

```
//view1.controller.spec.js

'use strict';

describe('Add - pAccountHolders.view1 module', function () {

    beforeEach(module('pAccountHoldersBase.view1'));

    describe('Add - view1 controller', function () {
        var $controller, view1Ctrl;

        beforeEach(inject(function (_$controller_) {
             $controller = _$controller_;
             view1Ctrl = $controller('View1Controller');
        }));

        it('should be defined', function() {
            expect(view1Ctrl).toBeDefined();
            expect(view1Ctrl.greeting).toBeDefined();
            expect(view1Ctrl.name).toBeDefined();
        });

        it('name should be view1', function() {
            expect(view1Ctrl.name).toBe('view 1');
        });

        it('should return a warm welcome', function() {
            expect(view1Ctrl.greeting('Mario')).toBe('Hi there Mario');
        });
    });

});
```