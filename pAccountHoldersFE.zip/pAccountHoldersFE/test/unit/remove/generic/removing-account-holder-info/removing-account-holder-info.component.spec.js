/* globals angular,describe,beforeEach,module,it,expect,inject,jasmine,spyOn,fail: false */
'use strict';

describe('Remove - The remove account holder component', function () {

    var ctrl, $rootScope, $q;

    var onErrorMock = jasmine.createSpy('onError');
    var customerServiceMock = {
        getCustomerByCustomerId: jasmine.createSpy('getCustomerByCustomerId'),
        getByIban: jasmine.createSpy('getByIban')
    };
    var onSelectedCustomerMock = jasmine.createSpy('onSelectedCustomer');

    beforeEach(function () {
        module('pAccountHoldersBase.remove.generic');
        inject(function (_$timeout_, $componentController, _$rootScope_, _$q_) {
            $q = _$q_;
            $rootScope = _$rootScope_;
            ctrl = $componentController('removingAccountHolderInfo', {
                    CustomerService: customerServiceMock
                },
                {
                    onSelectedCustomer: onSelectedCustomerMock,
                    onError: onErrorMock
                });
        });
    });

    describe('regarding the construction of the component', function () {
        it('should be instantiated', function () {
            expect(ctrl).toBeDefined();
        });
    });

    describe('regarding the customerSelected method', function () {
        var customer = {encryptedCustomerId: '-1', name: 'Henk'};
        describe('when an customer is selected', function () {
            beforeEach(function () {
                ctrl.customerSelected(customer);
                $rootScope.$apply();
            });
            it('should set the removed customer on the controller', function () {
                expect(ctrl.encryptedLeavingCustomerId).toEqual(customer.encryptedCustomerId);
            });
            it('should check if the onSelectedCustomer is set', function () {
                expect(onSelectedCustomerMock).toHaveBeenCalledWith({customer: customer});
            });
        });
    });

    describe('regarding the $onChanges method', function () {
        describe('when the service is loading', function () {
            beforeEach(function () {
                customerServiceMock.getByIban.and.returnValue($q.resolve({}));

                ctrl.$onChanges({
                        encryptedIban: {
                            currentValue: 'newiban'
                        }
                    }
                );
            });
            it('should set the isLoading flag', function () {
                expect(ctrl.isLoading).toBe(true);
            });
        });

        describe('when the service succeeds', function () {
            beforeEach(function () {
                customerServiceMock.getByIban.and.returnValue($q.resolve([
                    {
                        encryptedCustomerId: '2394621784623178463178463278462323423423423',
                        name: 'Hr F. Vermeulen'
                    },
                    {
                        encryptedCustomerId: '2394621784623178463178463278462323423423411',
                        name: 'Hr F. de Zwart'
                    }
                ]));

                ctrl.encryptedLeavingCustomerId = '2394621784623178463178463278462323423423411';

                ctrl.$onChanges({
                        encryptedIban: {
                            currentValue: 'newiban'
                        }
                    }
                );
                $rootScope.$apply(); // resolves the promise

            });
            it('should unset the isLoading flag', function () {
                expect(ctrl.isLoading).toBe(false);
            });
            it('should set selected on the customer to be removed', function () {
                expect(ctrl.customers).toContain({
                    encryptedCustomerId: '2394621784623178463178463278462323423423423',
                    name: 'Hr F. Vermeulen'
                });
                expect(ctrl.customers).toContain({
                    encryptedCustomerId: '2394621784623178463178463278462323423423411',
                    name: 'Hr F. de Zwart',
                    selected: true
                });
            });
            it('should set the encryptedLeavingCustomerId', function () {
                expect(ctrl.encryptedLeavingCustomerId).toBe('2394621784623178463178463278462323423423411');
            });
        });
    });

    describe('when the service fails', function () {
        beforeEach(function () {
            customerServiceMock.getByIban.and.returnValue($q.reject({data:'error'}));
            ctrl.$onChanges({
                        encryptedIban: {
                            currentValue: 'newiban'
                        }
                    }
                );
            $rootScope.$apply();
        });
        it('should unset the customers on the controller', function () {
            expect(ctrl.customers).toBe(null);
        });
        it('should set the error on the controller', function () {
            expect(ctrl.error).toEqual('error');
        });
        it('should call the onError function binding', function () {
            expect(onErrorMock).toHaveBeenCalled();
        });
    });

    describe('if the changed object does not contain an iban', function () {
        beforeEach(function () {
            ctrl.$onChanges({});
        });
        it('should unset the customers on the controller', function () {
            expect(ctrl.customers).toBe(null);
        });
    });
});
