/* globals angular,describe,beforeEach,module,it,expect,inject,jasmine,spyOn,fail: false */
'use strict';

describe('Remove - The EligibleAccounts service', function () {
    var $rootScope, $httpBackend, EligibleAccountsRemove;

    beforeEach(function () {
        module('pAccountHoldersBase.remove.generic');
        inject(function (_$rootScope_, _$httpBackend_, _$cacheFactory_, _$q_, _EligibleAccountsRemove_) {
            $rootScope = _$rootScope_;
            $httpBackend = _$httpBackend_;
            EligibleAccountsRemove = _EligibleAccountsRemove_;
        });
    });

    describe('regarding the getAllAccounts method', function () {
        describe('when the service has not been called before and the call is successful', function () {
            beforeEach(function () {
                $httpBackend.expectGET('/api/current-accounts/requests/account-holders/eligible-accounts/remove').respond(function () {
                    return [200, [
                        {
                            accounts: [
                                {iban: 'account1'},
                                {iban: 'account2'}
                            ]
                        }
                    ], {'Content-Type': 'application/json'}];
                });
            });
            it('should resolve the promise with the accounts received from the service', function (done) {
                EligibleAccountsRemove.getAllAccounts()
                    .then(function (res) {
                        expect(res).toContain({iban: 'account1'});
                        expect(res).toContain({iban: 'account2'});
                    })
                    .finally(done);
                $httpBackend.flush();
            });
        });

        describe('when the service has been called before and the call is successful', function () {
            beforeEach(function () {
                $httpBackend.expectGET('/api/current-accounts/requests/account-holders/eligible-accounts/remove').respond(function () {
                    return [200, [
                        {
                            accounts: [
                                {iban: 'account1'},
                                {iban: 'account2'}
                            ]
                        }
                    ], {'Content-Type': 'application/json'}];
                });
                EligibleAccountsRemove.getAllAccounts();
            });

            it('should have received data from second call from cache', function (done) {
                EligibleAccountsRemove.getAllAccounts()
                    .then(function (res) {
                        expect(res).toContain({iban: 'account1'});
                        expect(res).toContain({iban: 'account2'});
                    })
                    .finally(done);
                $httpBackend.flush();
            });
        });

        describe('regarding the getCustomers method', function () {
            describe('when the service has not been called before and the call is successful', function () {
                beforeEach(function () {
                    $httpBackend.expectGET('/api/current-accounts/requests/account-holders/eligible-accounts/remove').respond(function () {
                        return [200, [
                            {correspondenceName: 'name1', born: '00-00-0000'},
                            {correspondenceName: 'name2', born: '00-00-0000'}
                        ], {'Content-Type': 'application/json'}];
                    });
                });
                it('should resolve the promise with the accounts received from the service', function (done) {
                    EligibleAccountsRemove.getCustomers()
                        .then(function (res) {
                            expect(res).toContain({correspondenceName: 'name1', born: '00-00-0000'});
                            expect(res).toContain({correspondenceName: 'name2', born: '00-00-0000'});
                        })
                        .finally(done);
                    $httpBackend.flush();
                });
            });

            describe('when the service has been called before and the call is successful', function () {
                beforeEach(function () {
                    $httpBackend.expectGET('/api/current-accounts/requests/account-holders/eligible-accounts/remove').respond(function () {
                        return [200, [
                            {correspondenceName: 'name1', born: '00-00-0000'},
                            {correspondenceName: 'name2', born: '00-00-0000'}
                        ], {'Content-Type': 'application/json'}];
                    });
                    EligibleAccountsRemove.getCustomers();
                });

                it('should have received data from second call from cache', function (done) {
                    EligibleAccountsRemove.getCustomers()
                        .then(function (res) {
                            expect(res).toContain({correspondenceName: 'name1', born: '00-00-0000'});
                            expect(res).toContain({correspondenceName: 'name2', born: '00-00-0000'});
                        })
                        .finally(done);
                    $httpBackend.flush();
                });
            });
        });
    });

    describe('regarding the getOtherCustomer method', function () {
        describe('the service is successful', function () {
            var result;
            beforeEach(function () {
                $httpBackend.expectGET('/api/current-accounts/requests/account-holders/eligible-accounts/remove').respond(function () {
                    return [200, [
                        {
                            correspondenceName: 'name1',
                            born: '00-00-0000',
                            accounts: [
                                {iban: 'account1'}
                            ]
                        },
                        {
                            correspondenceName: 'name2',
                            born: '00-00-0000',
                            accounts: [
                                {iban: 'account2'}
                            ]
                        }
                    ], {'Content-Type': 'application/json'}];
                });
                result = EligibleAccountsRemove.getOtherCustomer('account1');
            });
            it('should return the other customer', function (done) {
                result.then(function (customer) {
                    expect(customer.correspondenceName).toEqual('name2');
                }).finally(done);
                $httpBackend.flush();
            });
        });
    });
});
