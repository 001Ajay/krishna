/* globals angular,describe,beforeEach,module,it,expect,inject,jasmine,spyOn,fail: false */
'use strict';


describe('Remove - The check-info component', function () {

    var ctrl, $rootScope, $q, CheckAccountRemove;

    var onErrorMock = jasmine.createSpy('onError');

    var complex = {
        "code": "ERROR",
        "errors": [
            {
                "code": "0004",
                "message": "Customer has complex products."
            }
        ]
    };

    var notComplex = {
        "status": "OK"
    };

    beforeEach(function () {
        module('pAccountHoldersBase.remove.generic');
        inject(function (_$timeout_, $componentController, _$rootScope_, _$q_, _CheckAccountRemove_) {
            $q = _$q_;
            $rootScope = _$rootScope_;
            CheckAccountRemove = _CheckAccountRemove_;
            ctrl = $componentController('removeCheckInfo', {
                    $scope: $rootScope.$new()
                }, {
                    onError: onErrorMock
                });
        });
    });

    describe('regarding the construction of the component', function () {
        it('should be instantiated', function () {
            expect(ctrl).toBeDefined();
        });
    });

    describe('regarding the initialization of the component', function () {
        describe('should not show any error check information', function () {

            beforeEach(function () {
                spyOn(CheckAccountRemove, 'getAccountCheck').and.returnValue($q.resolve(notComplex));
                ctrl.$onInit();
                $rootScope.$apply();
            });
            it('should set hasCheckErrors to be false and checkOrVerifyErrors to be null', function () {
                expect(ctrl.hasCheckErrors).toBe(false);
                expect(ctrl.checkOrVerifyErrors).toBe(null);
            });
        });
    });

    describe('regarding the initialization of the component', function () {
        describe('when IBAN and Customer was selected', function () {

            beforeEach(function () {
                spyOn(CheckAccountRemove, 'getAccountCheck').and.returnValue($q.resolve(complex));
                ctrl.encryptedIban = 'NL51INGB0000123456';
                ctrl.encryptedLeavingCustomerId = '1234567';
                ctrl.$onInit();
                $rootScope.$apply();
            });
            it('should should hasCheckErrors and checkOrVerifyErrors when complex', function () {
                expect(ctrl.hasCheckErrors).toEqual(true);
                expect(ctrl.checkOrVerifyErrors).toContain( {
                    "code": "0004",
                    "message": "Customer has complex products."
                });
            });

        });

        describe('getVerifyMsg ', function () {

            beforeEach(function () {
                ctrl.$onInit();
                ctrl.properties = {
                    MSG_CheckVerify_ECO: 'Heeft compliance kenmerk.',
                    MSG_CheckVerify_ECO2: 'Heeft ander compliance kenmerk.',
                    MSG_CheckVerify_EAR: 'In behandeling bij achterstanden.',
                    MSG_CheckVerify_EFR: 'Heeft fraude kenmerk(en).',
                    MSG_CheckVerify_EAU: 'Geen bevoegdheid tot de rekening.',
                    MSG_CheckVerify_EAA: 'Is geen eigenaar van de rekening.',
                    MSG_CheckVerify_UNK: 'Geen reden bekend.'
                };
                $rootScope.$apply();
            });
            it('should correctly return generic or detailed messages', function () {
                expect(ctrl.getVerifyMsg({
                    "code": "ECO1",
                    "message": "."
                })).toEqual('Heeft compliance kenmerk. (ECO1)');
                expect(ctrl.getVerifyMsg({
                    "code": "ECO2",
                    "message": "."
                })).toEqual('Heeft ander compliance kenmerk.');
                expect(ctrl.getVerifyMsg({
                    "code": "EAU",
                    "message": "."
                })).toEqual('Geen bevoegdheid tot de rekening.');
            });

        });

        describe('when IBAN and Customer was selected', function () {
            beforeEach(function () {
                spyOn(CheckAccountRemove, 'getAccountCheck').and.returnValue($q.resolve(notComplex));
                ctrl.encryptedIban = 'NL51INGB0000123456';
                ctrl.encryptedLeavingCustomerId = '1234567';
                ctrl.$onInit();
                $rootScope.$apply();
            });
            it('should set hasCheckErrors to be false', function () {
                expect(ctrl.hasCheckErrors).toBe(false);
                expect(ctrl.hasValidData).toBe(true);
                expect(ctrl.checkOrVerifyErrors).toBe(null);
            });
        });

        describe('when the call for getting the eligible accounts fails with a known error', function () {
            beforeEach(function () {
                spyOn(CheckAccountRemove, 'getAccountCheck').and.returnValue($q.reject({
                    data: {
                        "httpStatusCode": 500,
                        "errorId": "1",
                        "message": "Technical error occurred when getting eligible accounts",
                        "applicationId": "605",
                        "timestamp": 1500454806810
                    }
                }));
                ctrl.encryptedIban = 'NL51INGB0000123456';
                ctrl.encryptedLeavingCustomerId = '1234567';
                ctrl.$onInit();
                $rootScope.$apply();
            });
            it('should set the error on the controller', function () {
                expect(ctrl.hasComponentError).toBe(true);
                expect(ctrl.hasValidData).toBe(false);
                expect(onErrorMock).toHaveBeenCalled();
            });
        });

        describe('getCheck function is getting called', function () {
            beforeEach(function () {
                spyOn(ctrl, 'getCheck');
            });
            it('should call the getCheck method', function () {
                ctrl.reCheck();
                expect(ctrl.getCheck).toHaveBeenCalled();
            });
            it('should call the getCheck method', function () {
                ctrl.$onChanges();
                expect(ctrl.getCheck).toHaveBeenCalled();
            });
        });
    });
});
