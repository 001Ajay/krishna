/* globals angular,describe,beforeEach,module,it,expect,inject,jasmine,spyOn,fail: false */
'use strict';

describe('Remove - The CheckAccount service', function () {
    var $rootScope, $httpBackend, CheckAccountRemove;

    beforeEach(function () {
        module('pAccountHoldersBase.remove.generic');
        inject(function (_$rootScope_, _$httpBackend_, _$cacheFactory_, _$q_, _CheckAccountRemove_) {
            $rootScope = _$rootScope_;
            $httpBackend = _$httpBackend_;
            CheckAccountRemove = _CheckAccountRemove_;
        });
    });

    describe('regarding the getAccountCheck method', function () {
        describe('the service is successful', function () {

            beforeEach(function () {
                $httpBackend.expectGET('/api/current-accounts/requests/account-holders/check/remove?encryptedIban=NL44INGB0751630500').respond(200, {
                    "status": "OK",
                    "details": null
                }, {'Content-Type': 'application/json'});
            });

            it('should return status OK', function (done) {
                CheckAccountRemove.getAccountCheck('NL44INGB0751630500').then(function(response) {
                    expect(response.status).toEqual('OK');
                }).finally(done);

                $httpBackend.flush();
            });
        });
        describe('the service will respond with an error', function () {
            beforeEach(function () {
                $httpBackend.expectGET('/api/current-accounts/requests/account-holders/check/remove?encryptedIban=NL16INGB0751630519').respond(200, {
                    "status": "ERROR",
                    "errors": [
                        {
                            "code": "0002",
                            "message": "Not product Type 20 found 21"
                        }
                    ]
                }, {'Content-Type': 'application/json'});
            });

            it('should return status OK', function (done) {
                CheckAccountRemove.getAccountCheck('NL16INGB0751630519').then(function (data) {
                    expect(data.status).toEqual('ERROR');
                }).finally(done);

                $httpBackend.flush();
            });

        });
    });
});
