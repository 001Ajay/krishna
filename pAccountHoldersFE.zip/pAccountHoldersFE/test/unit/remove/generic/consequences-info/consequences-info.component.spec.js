/* globals angular,describe,beforeEach,module,it,expect,inject,jasmine,spyOn,fail: false */
'use strict';


describe('Remove - The consequences component', function () {

    var ctrl, $rootScope, $q;

    var onUpdateMock = jasmine.createSpy('onUpdate');
    var onErrorMock = jasmine.createSpy('onError');
    var customerServiceMock = {
        getCustomerByCustomerId: jasmine.createSpy('getCustomerByCustomerId'),
        getOtherCustomerByCustomerId: jasmine.createSpy('getOtherCustomerByCustomerId')
    };

    beforeEach(function () {
        module('pAccountHoldersBase.remove.generic');
        inject(function (_$timeout_, $componentController, _$rootScope_, _$q_) {
            $q = _$q_;
            $rootScope = _$rootScope_;
            ctrl = $componentController('consequencesInfo', {
                    $scope: $rootScope.$new(),
                    CustomerService: customerServiceMock
                },
                {
                    onUpdate: onUpdateMock,
                    onError: onErrorMock
                });
        });
    });

    describe('regarding the construction of the component', function () {
        it('should be instantiated', function () {
            expect(ctrl).toBeDefined();
        });
    });

    describe('regarding the getCustomer method', function () {
        describe('when an account and a customer are selected', function () {
            beforeEach(function () {
                ctrl.encryptedIban = 'NL51INGB0000123456';
                ctrl.encryptedLeavingCustomerId = '1234567';

                customerServiceMock.getCustomerByCustomerId.and.returnValue($q.resolve({}));
                ctrl.getCustomer();
                $rootScope.$apply();
            });
            it('should set the removed customer on the controller', function () {
                expect(ctrl.removedCustomer).toEqual({});
            });
        });

        describe('when either an account or a customer are not selected', function () {
            beforeEach(function () {
                ctrl.encryptedIban = 'NL51INGB0000123456';

                ctrl.getCustomer();
            });
            it('should set the removed customer on the controller', function () {
                expect(ctrl.removedCustomer).toEqual(null);
            });
        });
    });

    describe('regarding the getOtherCustomer method', function () {
        describe('when an account and a customer are selected', function () {
            beforeEach(function () {
                ctrl.selectedIban = 'NL51INGB0000123456';
                ctrl.encryptedLeavingCustomerId = '1234567';

                customerServiceMock.getOtherCustomerByCustomerId.and.returnValue($q.resolve({}));
                ctrl.getOtherCustomer();
                $rootScope.$apply();
            });
            it('should set the removed customer on the controller', function () {
                expect(ctrl.selectedIban).toEqual('NL51INGB0000123456');
            });
        });

        describe('when either an account or a customer are not selected', function () {
            beforeEach(function () {
                ctrl.selectedIban = 'NL51INGB0000123456';

                ctrl.getCustomer();
            });
            it('should set the removed customer on the controller', function () {
                expect(ctrl.removedCustomer).toEqual(null);
            });
        });
    });


    describe('regarding the $onChanges method', function () {
        beforeEach(function () {
            spyOn(ctrl, 'getCustomer');
            ctrl.$onChanges();
        });
        it('should set the isLoading flag', function () {
            expect(ctrl.isLoading).toBe(true);
        });
        it('should call the getCustomer method', function () {
            expect(ctrl.getCustomer).toHaveBeenCalled();
        });
    });

    describe('regarding the $onInit method', function () {
        beforeEach(function () {
            spyOn(ctrl, 'getCustomer');
            ctrl.$onInit();
        });
        it('should call the getCustomer method', function () {
            expect(ctrl.getCustomer).toHaveBeenCalled();
        });
    });

    describe('when the call for getting the customer fails with a known error', function () {
        beforeEach(function () {
            customerServiceMock.getCustomerByCustomerId.and.returnValue($q.reject({
                data: {
                    "errorId": "2",
                }
            }));
            ctrl.encryptedIban = 'NL51INGB0000123456';
            ctrl.encryptedLeavingCustomerId = '1234567';
            ctrl.$onInit();
            ctrl.getCustomer();
            $rootScope.$apply();
        });
        it('should set the error on the controller', function () {
            expect(onErrorMock).toHaveBeenCalled();
            expect(ctrl.error.errorId).toEqual('2');
        });
    });
    describe('when the call for getting the other customer fails with a known error', function () {
        beforeEach(function () {
            customerServiceMock.getOtherCustomerByCustomerId.and.returnValue($q.reject({
                data: {
                    "errorId": "1",
                }
            }));
            ctrl.encryptedIban = 'NL51INGB0000123456';
            ctrl.encryptedLeavingCustomerId = '1234567';
            ctrl.$onInit();
            ctrl.getOtherCustomer();
            $rootScope.$apply();
        });
        it('should set the error on the controller', function () {
            expect(ctrl.error.errorId).toEqual('1');
            expect(onErrorMock).toHaveBeenCalled();
        });
    });
});
