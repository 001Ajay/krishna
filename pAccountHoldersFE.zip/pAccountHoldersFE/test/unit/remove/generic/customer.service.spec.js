/* globals angular,describe,beforeEach,module,it,expect,inject,jasmine,spyOn,fail: false */
'use strict';

describe('Remove - The EligibleAccounts service', function () {
    var $httpBackend, CustomerService;

    beforeEach(function () {
        module('pAccountHoldersBase.remove.generic');
        inject(function (_$httpBackend_, _CustomerService_) {
            $httpBackend = _$httpBackend_;
            CustomerService = _CustomerService_;
        });
    });

    describe('regarding the getByIban method', function () {
        describe('when the service has not been called before and the call is successful', function () {
            beforeEach(function () {
                $httpBackend.expectGET(/\/api\/current-accounts\/requests\/account-holders\/customers\/byIban.*/).respond(function () {
                    return [200, [
                            { "name": "Hr F. Vermeulen" }, { "name": "Hr F. de Zwart" }
                        ], {'Content-Type': 'application/json'}];
                });
            });
            it('should resolve the promise with the accounts received from the service', function (done) {
                CustomerService.getByIban('NL51INGB0000123456')
                    .then(function (res) {
                        expect(res).toContain({name: 'Hr F. Vermeulen'});
                        expect(res).toContain({name: 'Hr F. de Zwart'});
                    })
                    .finally(done);
                $httpBackend.flush();
            });
        });
    });

    describe('regarding the getCustomerByCustomerId method', function () {
        describe('when the service has not been called before and the call is successful', function () {
            beforeEach(function () {
                $httpBackend.expectGET(/\/api\/current-accounts\/requests\/account-holders\/customers\/byIban.*/).respond(function () {
                    return [200, [
                            { 'name': 'Hr F. Vermeulen', 'encryptedCustomerId': '1' },
                            { 'name': 'Hr F. de Zwart', 'encryptedCustomerId': '2' }
                        ], {'Content-Type': 'application/json'}];
                });
            });
            it('should resolve the promise with the accounts received from the service', function (done) {
                CustomerService.getCustomerByCustomerId('NL51INGB0000123456', '2')
                    .then(function (res) {
                        expect(res).toEqual({name: 'Hr F. de Zwart', encryptedCustomerId: "2"});
                    })
                    .finally(done);
                $httpBackend.flush();
            });
        });
    });

    describe('regarding the getOtherCustomerByCustomerId method', function () {
        describe('when the service has not been called before and the call is successful', function () {
            beforeEach(function () {
                $httpBackend.expectGET(/\/api\/current-accounts\/requests\/account-holders\/customers\/byIban.*/).respond(function () {
                    return [200, [
                            { 'name': 'Hr F. Vermeulen', 'encryptedCustomerId': '1' },
                            { 'name': 'Hr F. de Zwart', 'encryptedCustomerId': '2' }
                        ], {'Content-Type': 'application/json'}];
                });
            });
            it('should resolve the promise with the accounts received from the service', function (done) {
                CustomerService.getOtherCustomerByCustomerId('2')
                    .then(function (res) {
                        expect(res).toEqual({name: 'Hr F. Vermeulen', encryptedCustomerId: '1'});
                    })
                    .finally(done);
                $httpBackend.flush();
            });
        });
    });
});
