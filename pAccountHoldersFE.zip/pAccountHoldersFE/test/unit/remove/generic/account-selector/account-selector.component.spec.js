/* globals angular,describe,beforeEach,module,it,expect,inject,jasmine,spyOn,fail: false */
'use strict';


describe('Remove - The account-selector component', function () {

    var ctrl, $rootScope, $q, EligibleAccountsRemove, CheckAccountRemove;

    var onUpdateMock;
    var onErrorMock;
    var result2 = [
        {name: 'Piet van As', iban: 'account1', encryptedIban: 'encryptedAccount1'},
        {name: 'Fred Kerstens', iban: 'account2', encryptedIban: 'encryptedAccount2'}
    ];
    var result1 = [
        result2[0]
    ];

    beforeEach(function () {
        module('pAccountHoldersBase.remove.generic');
        onUpdateMock = jasmine.createSpy('onUpdate');
         onErrorMock = jasmine.createSpy('onError');
        inject(function (_$timeout_, $componentController, _$rootScope_, _$q_, _EligibleAccountsRemove_, _CheckAccountRemove_) {
            $q = _$q_;
            $rootScope = _$rootScope_;
            EligibleAccountsRemove = _EligibleAccountsRemove_;
            CheckAccountRemove = _CheckAccountRemove_;
            ctrl = $componentController('removeAccountSelector', {
                    $scope: $rootScope.$new()
                },
                {
                    onUpdate: onUpdateMock,
                    onError: onErrorMock
                });
        });
    });

    describe('regarding the construction of the component', function () {
        it('should be instantiated', function () {
            expect(ctrl).toBeDefined();
        });
    });

    describe('regarding the $onDestroy method', function () {
        beforeEach(function () {
            ctrl.$onInit();
        });
        it('should call onDestroy successfully', function () {
            ctrl.$onDestroy();
        });
    });

    describe('regarding the initialization of the component', function () {
        describe('when the call for getting the eligible accounts is successful and an IBAN is not selected', function () {

            beforeEach(function () {
                spyOn(EligibleAccountsRemove, 'getAllAccounts').and.returnValue($q.resolve(result2));
                ctrl.$onInit();
                $rootScope.$apply();
            });
            it('should set the accounts on the controller as items for the rich select', function () {
                expect(ctrl.items[0].prop4).toEqual('account1');
                expect(ctrl.items[1].prop4).toEqual('account2');
            });

        });

        describe('when the call for getting the eligible accounts is successful and an IBAN is selected', function () {
            beforeEach(function () {
                spyOn(EligibleAccountsRemove, 'getAllAccounts').and.returnValue($q.resolve(result2));
                ctrl.encryptedIban = 'encryptedAccount1';
                ctrl.$onInit();
                $rootScope.$apply();
            });
            it('should set the accounts on the controller as items for the rich select', function () {
                expect(ctrl.items[0].prop4).toEqual('account1');
                expect(ctrl.items[1].prop4).toEqual('account2');
            });
            it('should set the account with the selected IBAN as selected', function () {
                expect(ctrl.items[0].selected).toBe(true);
            });

        });

        describe('when the call for getting the eligible accounts fails with a known error', function () {
            beforeEach(function () {
                spyOn(EligibleAccountsRemove, 'getAllAccounts').and.returnValue($q.reject({data: {errorId: '001'}}));
                ctrl.$onInit();
                ctrl.properties = {
                };
                $rootScope.$apply();
            });
            it('should set the error on the controller', function () {
                expect(ctrl.error.errorId).toEqual('001');
                expect(onErrorMock).toHaveBeenCalled();
            });
        });

        describe('when the call for getting the eligible accounts fails with a known error', function () {
            beforeEach(function () {
                spyOn(EligibleAccountsRemove, 'getAllAccounts').and.returnValue($q.reject({data: {errorId: '001'}}));
                delete ctrl.onError;
                ctrl.$onInit();
                ctrl.properties = {
                };
                $rootScope.$apply();
            });
            it('should not have called onError', function () {
                expect(onErrorMock).not.toHaveBeenCalled();
            });
        });

    });

    describe('regarding selecting the account', function () {
        describe('when an account gets selected and it was ok', function () {
            var eligibleAccountsResult;
            var checkAccountsResult;
            beforeEach(function () {
                var checkResult = {
                    "status": "OK",
                    "message": null,
                    "details": null
                };

                eligibleAccountsResult = $q.resolve(result2);
                checkAccountsResult = $q.resolve(checkResult);
                spyOn(EligibleAccountsRemove, 'getAllAccounts').and.returnValue(eligibleAccountsResult);
                spyOn(CheckAccountRemove, 'getAccountCheck').and.returnValue(checkAccountsResult);
                ctrl.$onInit();
            });
            it('should set the selected account IBAN on the controller', function () {
                eligibleAccountsResult.then(function () {
                    $rootScope.$broadcast('ing-rich-select-change-account',{name: 'Piet van As', prop4: 'account1', iban: 'account1', encryptedIban: 'encryptedAccount1'});
                    checkAccountsResult.then(function () {
                        expect(ctrl.encryptedIban).toEqual('encryptedAccount1');
                        expect(onUpdateMock).toHaveBeenCalledWith({account: {name: 'Piet van As', iban: 'account1', encryptedIban: 'encryptedAccount1'}});
                    });
                });
                $rootScope.$apply();
            });
            it('should set the selected account IBAN on the controller', function () {
                delete ctrl.onUpdate;
                eligibleAccountsResult.then(function () {
                    $rootScope.$broadcast('ing-rich-select-change-account',{name: 'Piet van As', prop4: 'account1', iban: 'account1', encryptedIban: 'encryptedAccount1'});
                    checkAccountsResult.then(function () {
                        expect(onUpdateMock).not.toHaveBeenCalled();
                    });
                });
                $rootScope.$apply();
            });
        });

        describe('when only one account gets loaded it was ok', function () {
            var eligibleAccountsResult;
            var checkAccountsResult;
            beforeEach(function () {
                var checkResult = {
                    "status": "OK",
                    "details": null
                };
                eligibleAccountsResult = $q.resolve(result1);
                checkAccountsResult = $q.resolve(checkResult);
                spyOn(EligibleAccountsRemove, 'getAllAccounts').and.returnValue(eligibleAccountsResult);
                spyOn(CheckAccountRemove, 'getAccountCheck').and.returnValue(checkAccountsResult);
                ctrl.$onInit();
            });
            it('should set the selected account IBAN on the controller', function () {
                eligibleAccountsResult.then(function () {
                    checkAccountsResult.then(function () {
                        expect(ctrl.encryptedIban).toEqual('encryptedAccount1');
                    });
                });
                $rootScope.$apply();
            });
        });

    });

});
