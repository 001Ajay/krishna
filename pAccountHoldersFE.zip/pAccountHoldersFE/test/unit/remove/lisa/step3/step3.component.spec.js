/* globals angular,describe,beforeEach,module,it,expect,inject,jasmine,spyOn,fail: false */
'use strict';


describe('Remove - The step3 component', function () {

    var ctrl, $rootScope, $q, propertyService;

    var navCtrl = {
        allow: jasmine.createSpy('allow'),
        restrict: jasmine.createSpy('restrict'),
        addCallback: jasmine.createSpy('addCallback'),
        navigate: jasmine.createSpy('navigate'),
        next: jasmine.createSpy('next')
    };
    var onCompleteMock;
    var onCanceledMock;
    var onErrorMock;

    var navigatorServiceMock = {
        get: null
    };

    beforeEach(function () {
        module('pAccountHoldersBase.remove.lisa');
        onCompleteMock = jasmine.createSpy('onComplete');
        onCanceledMock = jasmine.createSpy('onCanceled');
        navigatorServiceMock.get = jasmine.createSpy('get').and.returnValue(navCtrl);
        onErrorMock = jasmine.createSpy('onError');
        inject(function ($componentController, _$rootScope_, _$q_, _propertyService_) {
            $q = _$q_;
            $rootScope = _$rootScope_;
            propertyService = _propertyService_;
            ctrl = $componentController('step3', {
                    propertyService: _propertyService_,
                    navigatorService: navigatorServiceMock
                },
                {
                    onError: onErrorMock,
                    onComplete: onCompleteMock,
                    onCanceled: onCanceledMock,
                });
        });
    });

    describe('regarding the construction of the component', function () {
        it('should be instantiated', function () {
            expect(ctrl).toBeDefined();
        });
    });

    describe('regarding cancelation', function () {
        beforeEach(function () {
            ctrl.$onInit();
            ctrl.cramRequestCanceled();
        });
        it('should continue to next page', function () {
            expect(onCanceledMock).toHaveBeenCalled();
            expect(navCtrl.next).toHaveBeenCalled();
        });
    });

    describe('regarding cancelation', function () {
        beforeEach(function () {
            ctrl.$onInit();
            delete ctrl.onCanceled;
            ctrl.cramRequestCanceled();
        });
        it('should continue to next page and onCanceled not have been called.', function () {
            expect(onCanceledMock).not.toHaveBeenCalled();
            expect(navCtrl.next).toHaveBeenCalled();
        });
    });

    describe('regarding completion', function () {
        beforeEach(function () {
            ctrl.$onInit();
            ctrl.cramRequestCompleted();
        });
        it('should continue to next page', function () {
            expect(onCompleteMock).toHaveBeenCalled();
            expect(navCtrl.next).toHaveBeenCalled();
        });
    });

    describe('regarding completion', function () {
        beforeEach(function () {
            ctrl.$onInit();
            delete ctrl.onComplete;
            ctrl.cramRequestCompleted();
        });
        it('should continue to next page without onComplete have been called', function () {
            expect(onCompleteMock).not.toHaveBeenCalled();
            expect(navCtrl.next).toHaveBeenCalled();
        });
    });
});

