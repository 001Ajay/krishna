/* globals angular,describe,beforeEach,module,it,expect,inject,jasmine,spyOn,fail: false */
'use strict';

describe('Remove - The step1 component', function () {

    var ctrl, $componentController, $rootScope, $q;

    var navCtrlMock = {
        allow: jasmine.createSpy('allow'),
        restrict: jasmine.createSpy('restrict'),
        addCallback: jasmine.createSpy('addCallback'),
        navigate: jasmine.createSpy('navigate')
    };

    var navigatorServiceMock = {
        get: jasmine.createSpy('get').and.returnValue(navCtrlMock)
    };

    var onCompleteMock;

    var onNavigationControllerMock = jasmine.createSpy('onNavigationController');

    beforeEach(function () {
        module('pAccountHoldersBase.remove.lisa');
         onCompleteMock = jasmine.createSpy('onComplete');
        inject(function (_$componentController_, _$rootScope_, _$q_) {
            $componentController = _$componentController_;
            $q = _$q_;
            $rootScope = _$rootScope_;
            ctrl = $componentController('step1', {
                    $scope: $rootScope.$new(),
                    navigatorService: navigatorServiceMock
                },
                {
                    onComplete: onCompleteMock,
                    onNavigationController: onNavigationControllerMock
                });
        });
    });

    describe('regarding the construction of the component', function () {
        it('should be instantiated', function () {
            expect(ctrl).toBeDefined();
        });
    });

    describe('regarding the initialization of the component', function () {
        describe('when the onNavigationController binding is defined', function () {
            beforeEach(function () {
                ctrl.$onInit();
            });
            it('should call the onNavigationController method with the navigationController as a parameter', function () {
                expect(onNavigationControllerMock).toHaveBeenCalledWith({controller: navCtrlMock});
            });
        });

        describe('when the onNavigationController binding is not defined', function () {
            beforeEach(function () {
                ctrl = $componentController('step1', {
                    $scope: $rootScope.$new(),
                    navigatorService: navigatorServiceMock
                });
                onNavigationControllerMock.calls.reset();
                ctrl.$onInit();
            });
            it('should not call the onNavigationController method', function () {
                expect(onNavigationControllerMock).not.toHaveBeenCalled();
            });
        });
    });

    describe('regarding the onIbanSelected method', function () {
        describe('when it is called and the onComplete binding is defined', function () {
            beforeEach(function () {
                ctrl.onIbanSelected({holder: 0});
            });
            it('should reset the selected customer id', function () {
                expect(ctrl.encryptedLeavingCustomerId).toBe(null);
                expect(onCompleteMock).toHaveBeenCalledWith({isComplete: false});
            });
        });

        describe('when the onComplete binding is not defined', function () {
            beforeEach(function () {
                onCompleteMock.calls.reset();
                delete ctrl.onComplete;
                ctrl.onIbanSelected({holder: 0});
            });
            it('should not call the onComplete method', function () {
                expect(onCompleteMock).not.toHaveBeenCalled();
            });
        });
    });

    describe('regarding the onSelectedCustomer method', function () {
        describe('when it is called and the onComplete binding is defined', function () {
            beforeEach(function () {
                ctrl.onSelectedCustomer({'name':'foo'});
            });
            it('should call onComplete', function () {
                expect(onCompleteMock).toHaveBeenCalledWith({isComplete:true});
            });
        });

        describe('when it is called and the onComplete binding is not defined', function () {
            beforeEach(function () {
                delete ctrl.onComplete;
                onCompleteMock.calls.reset();
                ctrl.onSelectedCustomer({});
            });
            it('should not call onComplete', function () {
                expect(onCompleteMock).not.toHaveBeenCalled();
            });
        });
    });

    describe('regarding the nextCallback method', function () {
        describe('when step1Form is valid', function () {
            beforeEach(function () {
                ctrl.encryptedIban = "encryptedIban";
                ctrl.encryptedLeavingCustomerId = "encryptedLeavingCustomerId";
                ctrl.step1Form = {$valid: true};
            });
            it('should return true', function () {
                var result = ctrl.nextCallback();
                expect(result).toBe(true);
            });
        });

        describe('when step1Form is invalid', function () {
            beforeEach(function () {
                ctrl.step1Form = {$valid: false};
            });
            it('should return true', function () {
                var result = ctrl.nextCallback();
                expect(result).toBe(false);
            });
        });
    });
});
