/* globals angular,describe,beforeEach,module,it,expect,inject,jasmine,spyOn,fail: false */
'use strict';

describe('Remove - The app-remove-lisa component', function() {

    var ctrl, $componentController, $rootScope;

    var navCtrlMock = {
        allow: jasmine.createSpy('allow'),
        restrict: jasmine.createSpy('restrict'),
        addCallback: jasmine.createSpy('addCallback'),
        navigate: jasmine.createSpy('navigate')
    };

    var navigatorServiceMock = {
        get: jasmine.createSpy('get').and.returnValue(navCtrlMock)
    };

    beforeEach(function() {
        module('pAccountHoldersBase.remove.lisa');
        inject(function(_$componentController_, _$rootScope_) {
            $componentController = _$componentController_;
            $rootScope = _$rootScope_;
        });
        ctrl = $componentController('appRemoveLisa',
            {
                navigatorService: navigatorServiceMock
            });
    });

    describe('regarding the initialization of the component', function() {
        it('should be instantiated', function() {
            expect(ctrl).toBeDefined();
        });
    });

    describe("regarding step3Canceled", function() {
        beforeEach(function() {
            ctrl.step3Canceled();
        });
        it('should be true', function() {
            expect(ctrl.canceled).toBe(true);
        });
    });

    describe("regarding step3Complete", function() {
        beforeEach(function() {
            ctrl.step3Complete();
        });
        it('should be false', function() {
            expect(ctrl.canceled).toBe(false);
        });
    });

    describe("regarding $onInit", function() {
        beforeEach(function() {
            ctrl.$onInit();
        });
        it('should be false', function() {
            expect(ctrl.canceled).toBe(false);
        });
    });

    // RVT 12 Okt 2017: Kept here for the moment, We can now only continue when validators are correct
    // So there is no need anymore to call allow/restrict
    // describe('regarding the step1Complete method', function() {
    //     beforeEach(function() {
    //         ctrl.step1Complete();
    //     });
    //     it('should call the relevant methods on the navigation controller', function () {
    //         expect(navCtrlMock.allow).toHaveBeenCalled();
    //         expect(navCtrlMock.restrict).toHaveBeenCalled();
    //     });
    // });
});
