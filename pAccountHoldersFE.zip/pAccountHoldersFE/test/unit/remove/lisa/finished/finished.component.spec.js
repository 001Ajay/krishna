/* globals angular,describe,beforeEach,module,it,expect,inject,jasmine,spyOn,fail: false */
'use strict';

describe('Remove - The finished component', function () {

    var ctrl, $rootScope, $q, CustomerService;

    var onUpdateMock;
    var onErrorMock;

    beforeEach(function () {
        module('pAccountHoldersBase.remove.lisa');
        onUpdateMock = jasmine.createSpy('onUpdate');
        onErrorMock = jasmine.createSpy('onError');
        inject(function ($componentController, _$rootScope_, _$q_, _CustomerService_) {
            $q = _$q_;
            $rootScope = _$rootScope_;
            CustomerService = _CustomerService_;
            ctrl = $componentController('finished', {
                    CustomerService: CustomerService
                },
                {
                    onUpdate: onUpdateMock,
                    onError: onErrorMock
                });
        });
    });

    describe('regarding the $onChanges method', function () {
        beforeEach(function () {
            spyOn(ctrl, 'getCustomer').and.callThrough();
            ctrl.encryptedIban = 'encryptedAccount1_1';
            ctrl.encryptedLeavingCustomerId = '1234567';
            ctrl.$onChanges();
        });
        it('should set the isLoading flag', function () {
            expect(ctrl.isLoading).toBe(true);
        });
        it('should call the getCustomer method', function () {
            expect(ctrl.getCustomer).toHaveBeenCalled();
        });
    });

    describe('regarding the getCustomer method', function () {
        describe('when an account and a customer are selected', function () {
            beforeEach(function () {
                ctrl.encryptedIban = 'NL51INGB0000123456';
                ctrl.encryptedLeavingCustomerId = '1234567';

                spyOn(CustomerService, 'getCustomerByCustomerId').and.returnValue($q.resolve({}));
                spyOn(CustomerService, 'getOtherCustomerByCustomerId').and.returnValue($q.resolve({}));
                ctrl.getCustomer();
                $rootScope.$apply();
            });
            it('should set the removed customer on the controller', function () {
                expect(ctrl.removedCustomer).toEqual({});
            });
        });
        describe('when either an account or a customer are not selected', function () {
            beforeEach(function () {
                ctrl.encryptedIban = 'NL51INGB0000123456';

                ctrl.getCustomer();
            });
            it('should set the removed customer on the controller', function () {
                expect(ctrl.removedCustomer).toEqual(null);
            });
        });
    });

    describe('regarding the $onInit method', function () {
        beforeEach(function () {
            spyOn(ctrl, 'getCustomer');
            ctrl.$onInit();
        });
        it('should call the getCustomer method', function () {
            expect(ctrl.getCustomer).toHaveBeenCalled();
        });
    });
});
