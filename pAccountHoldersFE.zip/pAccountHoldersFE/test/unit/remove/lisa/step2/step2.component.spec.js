/* globals angular,describe,beforeEach,module,it,expect,inject,jasmine,spyOn,fail: false */
'use strict';


describe('Remove - The step2 component', function () {

    var ctrl, $rootScope, $q, EligibleAccountsRemove, CustomerService, propertyService;

    var result2 = [
        {name: 'Piet van As', iban: 'account1', encryptedIban: 'encryptedAccount1'},
        {name: 'Fred Kerstens', iban: 'account2', encryptedIban: 'encryptedAccount2'}
    ];

    beforeEach(function () {
        module('pAccountHoldersBase.remove.lisa');
        inject(function ($componentController, _$rootScope_, _$q_, _EligibleAccountsRemove_,
                         _CustomerService_, _propertyService_) {
            $q = _$q_;
            $rootScope = _$rootScope_;
            EligibleAccountsRemove = _EligibleAccountsRemove_;
            CustomerService = _CustomerService_;
            propertyService = _propertyService_;
            ctrl = $componentController('step2', {
                CustomerService: CustomerService,
                EligibleAccountsRemove: EligibleAccountsRemove,
                propertyService: propertyService
            });
        });
    });

    describe('regarding the construction of the component', function () {
        it('should be instantiated', function () {
            expect(ctrl).toBeDefined();
        });
    });

    describe('regarding the $onChanges method', function () {
        beforeEach(function () {
            spyOn(ctrl, 'getCustomer').and.callThrough();
            ctrl.encryptedIban = 'encryptedAccount1_1';
            ctrl.encryptedLeavingCustomerId = '1234567';
            ctrl.$onChanges();
        });
        it('should set the isLoading flag', function () {
            expect(ctrl.isLoading).toBe(true);
        });
        it('should call the getCustomer method', function () {
            expect(ctrl.getCustomer).toHaveBeenCalled();
        });
    });

    describe('regarding the getCustomer method', function () {
        describe('when an account and a customer are selected', function () {
            beforeEach(function () {
                ctrl.encryptedIban = 'encryptedAccount1';
                ctrl.encryptedLeavingCustomerId = '1234567';
                ctrl.properties = { MSG_EnOf: '' };

                spyOn(EligibleAccountsRemove, 'getAllAccounts').and.returnValue($q.resolve(result2));
                spyOn(CustomerService, 'getCustomerByCustomerId').and.returnValue($q.resolve(result2[0]));
                spyOn(CustomerService, 'getOtherCustomerByCustomerId').and.returnValue($q.resolve(result2[0]));
                ctrl.getCustomer();
                $rootScope.$apply();
            });
            it('should set the removed customer on the controller', function () {
                expect(ctrl.customer).toEqual(result2[0]);
                expect(ctrl.selectedIban).toEqual('account1');
            });
        });
        describe('when either an account or a customer are not selected', function () {
            beforeEach(function () {
                ctrl.encryptedIban = 'NL51INGB0000123456';
                ctrl.getCustomer();
            });
            it('should set the removed customer on the controller', function () {
                expect(ctrl.customer).toEqual(null);
                expect(ctrl.selectedIban).toEqual(null);
            });
        });
    });

    describe('regarding the $onInit method', function () {
        beforeEach(function () {
            spyOn(ctrl, 'getCustomer');
            ctrl.$onInit();
        });
        it('should call the getCustomer method', function () {
            expect(ctrl.getCustomer).toHaveBeenCalled();
        });
    });
});
