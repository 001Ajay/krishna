/* globals angular,describe,beforeEach,module,it,expect,inject,jasmine,spyOn,fail: false */
'use strict';


describe('Generic - The pAccountHolders generic module', function() {

    var $httpProvider;

    beforeEach(function () {
        module(function (_$httpProvider_) {
            $httpProvider = _$httpProvider_;
            spyOn($httpProvider, 'useApplyAsync');
        });
        module('pAccountHoldersBase.generic');
        inject();
    });

    it('should enable useApplyAsync', function () {
        expect($httpProvider.useApplyAsync)
            .toHaveBeenCalledWith(true);
    });

});
