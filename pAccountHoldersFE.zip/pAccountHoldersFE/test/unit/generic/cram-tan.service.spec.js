/* globals angular,describe,beforeEach,module,it,expect,inject,jasmine,spyOn,fail: false */
'use strict';

describe('Generic - The Cram Tan service', function () {
    var $httpBackend, CramTanService;

    beforeEach(function () {
        module('pAccountHoldersBase.generic');
        inject(function (_$httpBackend_, _CramTanService_) {
            $httpBackend = _$httpBackend_;
            CramTanService = _CramTanService_;
        });
    });

    describe('regarding the initiate method', function () {
        describe('the service is successful', function () {

            beforeEach(function () {
                $httpBackend.expectPOST('/api/current-accounts/requests/account-holders/cram/initiate').respond(function () {
                    return [200, {
                        referenceId: 'C6151',
                        encryptedReferenceId: '1jkJnISuOaE9AcmH84PsE1GWBYZFydAqbNJgjkdz4zQ.'
                    }, {'Content-Type': 'application/json'}];
                });
            });

            it('should return referenceid C6151', function (done) {
                CramTanService.initiate('encryptedIban', 'encryptedLeavingCustomerId').then(function (data) {
                    expect(data.referenceId).toEqual('C6151');
                }).finally(done);

                $httpBackend.flush();
            });
        });
    });

});
