/* globals angular,describe,beforeEach,module,it,expect,inject,jasmine,spyOn,fail: false */
'use strict';

describe('Generic - The Cram Tan Component', function () {

    var ctrl, $rootScope, $q, CramTanService;

    var onErrorMock;
    var onCompleteMock;
    var onCanceledMock;

    beforeEach(function () {
        module('pAccountHoldersBase.generic.lisa');
        onErrorMock = jasmine.createSpy('onError');
        onCompleteMock = jasmine.createSpy('onComplete');
        onCanceledMock = jasmine.createSpy('onCanceled');
        inject(function (_$timeout_, $componentController, _$rootScope_, _$q_, _CramTanService_) {
            $q = _$q_;
            $rootScope = _$rootScope_;
            CramTanService = _CramTanService_;
            ctrl = $componentController('cramTanRequest', {
                    $scope: $rootScope.$new(),
                    CramTanService: CramTanService
                }, {
                    onError: onErrorMock,
                    onComplete: onCompleteMock,
                    onCanceled: onCanceledMock
                });
            ctrl.processName = 'mockApp';
        });
    });

    describe('regarding the construction of the component', function () {
        it('should be instantiated', function () {
            expect(ctrl).toBeDefined();
        });
    });

    describe('when either an account and a customer are selected', function () {
        beforeEach(function () {
            ctrl.encryptedIban = 'NL51INGB0000123456';
            ctrl.encryptedLeavingCustomerId = '1234567';
        });

        describe('regarding the status method', function () {
            beforeEach(function () {
                ctrl.initiateCramRequest();
            });
            it('should set the isLoading flag', function () {
                expect(ctrl.isLoading).toBe(true);
            });
        });

        describe('regarding valid data on initiate', function () {
            beforeEach(function () {
                spyOn(CramTanService, 'initiate').and.returnValue($q.resolve({
                    referenceId: 'refId',
                    encryptedReferenceId: 'encrRefId',
                }));
                ctrl.error = 'error';
                ctrl.initiateCramRequest();
                $rootScope.$apply();
            });
            it('should set reset error', function () {
                expect(ctrl.error).toEqual(null);
            });
            it('should set the Authorization Reference Id', function () {
                expect(ctrl.encryptedAuthorizationReferenceId).toEqual('encrRefId');
            });
        });

        describe('regarding empty initiate', function () {
            beforeEach(function () {
                spyOn(CramTanService, 'initiate').and.returnValue($q.resolve({}));
                ctrl.initiateCramRequest();
                $rootScope.$apply();
            });
            it('should set the error to true', function () {
                expect(ctrl.error).toEqual('Reference ID was empty');
            });
            it('should have called onError', function () {
                expect(ctrl.onError).toHaveBeenCalled();
            });
        });

        describe('regarding failed initiate', function () {
            beforeEach(function () {
                spyOn(CramTanService, 'initiate').and.returnValue($q.reject({}));
                ctrl.initiateCramRequest();
                $rootScope.$apply();
            });
            it('should set the error to true', function () {
                expect(ctrl.error).toEqual({});
            });
            it('should have called onError', function () {
                expect(ctrl.onError).toHaveBeenCalled();
            });
        });

    });

    describe('when either an account or a customer are not selected', function () {
        describe('regarding the authorization reference id', function () {
            beforeEach(function () {
                ctrl.encryptedIban = 'NL51INGB0000123456';
                ctrl.initiateCramRequest();
            });
            it('should reset authorisation request ', function () {
                expect(ctrl.encryptedAuthorizationReferenceId).toEqual(null);
            });
        });

    });

    describe('regarding the $onInit method', function () {
        beforeEach(function () {
            spyOn(ctrl, 'initiateCramRequest').and.callThrough();
            ctrl.encryptedIban = 'NL51INGB0000123456';
            ctrl.encryptedLeavingCustomerId = '1234567';
            ctrl.$onInit();
        });
        it('should set the isLoading flag', function () {
            expect(ctrl.isLoading).toBe(true);
        });
        it('should call the getCustomer method', function () {
            expect(ctrl.initiateCramRequest).toHaveBeenCalled();
        });
    });

    describe('regarding the $onDestroy method', function () {
        beforeEach(function () {
            ctrl.$onInit();
        });
        it('should call onDestroy successfully', function () {
            ctrl.$onDestroy();
        });
    });

    describe('the cram component', function () {
        beforeEach(function () {
            ctrl.$onInit();
            $rootScope.$broadcast('cancelled.assistedAuth.' + ctrl.processName, {});
        });
        it('should have called onCanceled', function () {
            expect(ctrl.cramExecutedSuccessfully).toEqual(false);
            expect(ctrl.assistedAuthCancelled).toEqual(true);
            expect(onCanceledMock).toHaveBeenCalled();
        });
    });

    describe('the cram component', function () {
        beforeEach(function () {
            ctrl.$onInit();
            $rootScope.$broadcast('completed.assistedAuth.' + ctrl.processName, {});
        });
        it('should have called onComplete', function () {
            expect(ctrl.cramExecutedSuccessfully).toEqual(true);
            expect(ctrl.assistedAuthCancelled).toEqual(false);
            expect(onCompleteMock).toHaveBeenCalled();
        });
    });

    describe('the cram component', function () {
        beforeEach(function () {
            delete ctrl.onComplete;
            ctrl.$onInit();
            $rootScope.$broadcast('completed.assistedAuth.' + ctrl.processName, {});
        });
        it('should not have called onComplete', function () {
            expect(onCompleteMock).not.toHaveBeenCalled();
        });
    });

    describe('the cram component', function () {
        beforeEach(function () {
            ctrl.$onInit();
            $rootScope.$broadcast('authorised.assistedAuth.' + ctrl.processName, {});
        });
        it('should have called onComplete', function () {
            expect(ctrl.cramExecutedSuccessfully).toEqual(true);
            expect(ctrl.assistedAuthCancelled).toEqual(false);
            expect(onCompleteMock).toHaveBeenCalled();
        });
    });

    describe('the cram component', function () {
        beforeEach(function () {
            ctrl.$onInit();
            $rootScope.$broadcast('error.assistedAuth.' + ctrl.processName, {});
        });
        it('should have called onError', function () {
            expect(ctrl.cramExecutedSuccessfully).toEqual(false);
            expect(onErrorMock).toHaveBeenCalled();
        });
    });

    describe('the cram component', function () {
        beforeEach(function () {
            delete ctrl.onError;
            ctrl.$onInit();
            $rootScope.$broadcast('error.assistedAuth.' + ctrl.processName, {});
        });
        it('should not have called onError', function () {
            expect(onErrorMock).not.toHaveBeenCalled();
        });
    });

});
