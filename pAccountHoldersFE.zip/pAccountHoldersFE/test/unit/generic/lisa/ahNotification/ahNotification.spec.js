/* globals angular,describe,beforeEach,module,it,expect,inject,jasmine,spyOn,fail: false */
'use strict';

describe('Generic - The ah Notification Component', function () {

    var ctrl, $rootScope, $q, propertyService;

    var onButtonClickMock;

    beforeEach(function () {
        module('pAccountHoldersBase.generic.lisa');
        onButtonClickMock = jasmine.createSpy('onButtonClick');
        inject(function (_$timeout_, $componentController, _$rootScope_, _$q_, _propertyService_) {
            $q = _$q_;
            $rootScope = _$rootScope_;
            propertyService = _propertyService_;
            ctrl = $componentController('ahNotification', {
                $scope: $rootScope.$new(),
                propertyService: _propertyService_
            }, {
                onButtonClick: onButtonClickMock
            });
            ctrl.processName = 'mockApp';
        });
    });

    describe('regarding the construction of the component', function () {
        it('should be instantiated', function () {
            expect(ctrl).toBeDefined();
        });
    });

    describe('regarding the default message without properties', function () {
        beforeEach(function () {
            ctrl.defaultMessage = '1234567';
            ctrl.properties = {};
            ctrl.$onChanges();
        });
        it('should set the default message', function () {
            expect(ctrl.messageValue).toEqual('1234567');
        });
    });

    describe('regarding the default message with properties but wrong messagePropValue', function () {
        beforeEach(function () {
            ctrl.defaultMessage = '1234567';
            ctrl.messagePropValue = '001';
            ctrl.propertyServiceName = 'generic'
            ctrl.propertyService =
                {
                    properties: function () {
                        return {
                            // Error messages
                            '001': 'other code'
                        };
                    }
                }
            ctrl.$onChanges();
        });
        it('should set the default message', function () {
            expect(ctrl.messageValue).toEqual('other code');
        });
    });
})
;
