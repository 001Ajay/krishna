/* globals angular,describe,beforeEach,module,it,expect,inject,jasmine,spyOn,fail: false */
'use strict';

describe('The pAccountHoldersAddLisaApp module', function() {
    it('should be present', function() {
        var module = angular.module('pAccountHoldersAddLisaApp');
        expect(module).toBeDefined();
    });
});

describe('The pAccountHoldersRemoveLisaApp module', function() {
    it('should be present', function() {
        var module = angular.module('pAccountHoldersRemoveLisaApp');
        expect(module).toBeDefined();
    });
});

