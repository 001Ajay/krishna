var fs = require('fs');
var path = require('path');
var chai = require('chai');
var chaiAsPromised = require('chai-as-promised');

chai.use(chaiAsPromised);
var expect = chai.expect;

module.exports = function () {
    // On my windows system I got function timed out after 5000 milliseconds from
    // tests. This seems to fix it.
    this.setDefaultTimeout(30000);

    this.Given(/^I'm logged in with profile "([^"]*)"$/, function (profilename) {
        browser.driver.get(browser.baseUrl + 'api/current-accounts/requests/account-holders/login');

        takeScreenshot(browser, 'before_login.png');
        browser.driver.findElement(by.css('body > form > select > option[value = ' + profilename + ']')).click();
        browser.driver.findElement(by.css('body > form > input[type = submit]')).click();
    });

    this.Given(/^the "([^"]*)" application is started$/, function (app) {
        browser.get('/index-' + app + '.html');
    });

    this.Given(/^the "([^"]*)" application is started with the following stubs set up$/, function (app, table) {
        var params = table.hashes().reduce(function (acc, stub) {
            var param = '' + stub.name + '=' + encodeURIComponent(stub.value);
            return !acc ? param : acc + '&' + param;
        }, null);
        browser.get('/index-e2e-' + app + '-lisa.html#?' + params);
    });

    this.Given(/^the "([^"]*)" application is started on ming with the following customers logged in$/, function (app, table) {
        var processName;
        if (app === 'remove') {
            processName = 'afmelden';
        } else {
            processName = 'aanmelden';
        }

        var baseUrl = 'https://test.mijn.ing.nl/ssm/stub/login?';
        var sessionType = '1';
        var applicationUrl = '/particulier/zelf-regelen/wijzigen/betaalrekening/' + processName +
            '-rekeninghouder/index';

        var constParams = 'sessiontype=' + sessionType + '&url=' + applicationUrl;

        var varParams = '';
        var tableData = table.raw();
        for (var i = 1; i < tableData.length; i++) {
            for (var j = 0; j < tableData[0].length; j++) {
                varParams += '&' + tableData[0][j] + '=' + tableData[i][j];
            }
        }

        browser.ignoreSynchronization = true;
        browser.get(baseUrl + constParams + varParams);
        var submitButton = element(by.buttonText("Inloggen"));
        submitButton.click();
        browser.ignoreSynchronization = false;
        takeScreenshot(browser, 'ming.png');

        //https://stackoverflow.com/questions/28808463/what-is-browser-ignoresynchronization-in-protractor
        browser.waitForAngular=false;
    });


    this.When(/^the account with iban "([^"]*)" is selected in the rich select at "([^"]*)"$/, function (iban, cssSelector, callback) {
        var htmlElement = element(by.css(cssSelector));
        var clickable = htmlElement.element(by.cssContainingText('span', iban));
        clickable.click().then(callback);
    });

    this.When(/^the user "([^"]*)" is selected in the radio select at "([^"]*)"$/, function (user, cssSelector, callback) {
        var htmlElement = element(by.css(cssSelector));
        var labelElement = htmlElement.element(by.cssContainingText('label', user));
        var clickable = labelElement.element(by.css('input[type=radio]'));
        clickable.click().then(callback);
    });

    this.When(/^the radio with text "([^"]*)" is clicked$/, function (labelTxt, callback) {
        var labelElement = element(by.cssContainingText('label', labelTxt));
        var clickable = labelElement.element(by.css('input[type=radio]'));
        clickable.click().then(callback);
    });

    this.When(/^the checkbox with text "([^"]*)" is clicked$/, function (labelTxt, callback) {
        var labelElement = element(by.cssContainingText('label', labelTxt));
        var clickable = labelElement.element(by.css('input[type=checkbox]'));
        clickable.click().then(callback, callback);
    });

    this.Then(/^the text "([^"]*)" should be visible in the element at "([^"]*)"$/, function (expectedText, cssSelector, callback) {
        var htmlElement = element(by.css(cssSelector));
        expect(htmlElement.getText()).to.eventually.contain(expectedText).and.notify(callback);
    });

    this.Then(/^the following text should be visible in the element at "([^"]*)"$/, function (cssSelector, expectedText, callback) {
        var htmlElement = element(by.css(cssSelector));
        expect(htmlElement.getText()).to.eventually.contain(expectedText).and.notify(callback);
    });

    this.Then(/^the following items should be visible in the rich select at "([^"]*)"$/, function (cssSelector, table, callback) {
        var htmlElement = element(by.css(cssSelector));
        table.raw().filter(function (elem) {
            expect(htmlElement.getText()).to.eventually.have.string(elem).and.notify(callback);
        });
    });

    this.Then(/^no items should be visible in the rich select at "([^"]*)"$/, function (cssSelector, callback) {
        var htmlElements = element.all(by.css(cssSelector + '>* input'));
        expect(htmlElements).to.eventually.be.empty.and.notify(callback);
    });

    this.Then(/^a button that retries the action should be visible at "([^"]*)"$/, function (cssSelector, callback) {
        var htmlElement = element(by.css(cssSelector));
        expect(htmlElement.getText()).to.eventually.contain('Opnieuw proberen').and.notify(callback);
    });

    this.Then(/^an selection should be visible with at "([^"]*)" containing "([^"]*)" radio elements$/, function (cssSelector, number, callback) {
        var htmlElements = element.all(by.css(cssSelector + ' input[type=radio]'));
        expect(htmlElements).to.eventually.be.lengthOf(number).and.notify(callback);
    });

    this.Then(/^an error that contains the following text should be visible$/, function (message, callback) {
        var htmlElement = element(by.css('.alert-danger'));
        expect(htmlElement.getText()).to.eventually.contain(message).and.notify(callback);
    });

    this.Then(/^an error with button that contains the following text should be visible$/, function (message, callback) {
        var htmlElement = element(by.css('.alert-danger .row span'));
        var htmlButtonElement = element(by.css('.alert-danger button'));
        expect(htmlElement.getText()).to.eventually.contain(message);
        expect(htmlButtonElement.isDisplayed()).to.eventually.be.true.and.notify(callback);
    });

    this.Then(/^an info that contains the following text should be visible$/, function (message, callback) {
        var htmlElement = element(by.css('.alert-info'));
        expect(htmlElement.getText()).to.eventually.contain(message).and.notify(callback);
    });

    this.Then(/^an warning that contains the following text should be visible$/, function (message, callback) {
        var htmlElement = element(by.css('.has-error'));
        expect(htmlElement.getText()).to.eventually.contain(message).and.notify(callback);
    });

    this.Then(/^the button with the text "([^"]*)" should be visible$/, function (text, callback) {
        var htmlElement = element(by.buttonText(text));
        expect(htmlElement.isDisplayed()).to.eventually.be.true.and.notify(callback);
    });

    this.Then(/^the button with the text "([^"]*)" is clicked$/, function (text, callback) {
        var htmlElement = element(by.buttonText(text));
        htmlElement.click().then(callback);
    });

    this.Then(/^the button within the element "([^"]*)" with text "([^"]*)" is clicked$/, function (el, text, callback) {
        var withinElement = element(by.css(el));
        var htmlElement = withinElement.element(by.buttonText(text));
        htmlElement.click().then(callback);
    });

    this.Then(/^the button with the text "([^"]*)" should not be visible$/, function (text, callback) {
        var htmlElement = element(by.buttonText(text));
        expect(htmlElement.isPresent()).to.eventually.be.false.and.notify(callback);
    });

    this.Then(/^I confirm the popup$/, function () {
        browser.driver.switchTo().alert().accept();
    });

    this.Then(/^I dismiss the popup$/, function () {
        browser.driver.switchTo().alert().dismiss();
    });

    this.Then(/^the progress will still be at step "([^"]*)"$/, function (stepNumber, callback) {
        var htmlElement = element(by.css('.pagination-wrapper li.active span span'));
        expect(htmlElement.getText()).to.eventually.contain(stepNumber).and.notify(callback);
    });
};

function takeScreenshot(browser, fileName) {
    browser.takeScreenshot().then(function (data) {
        var filePath = path.join('reports', fileName);
        var stream = fs.createWriteStream(filePath);
        stream.write(new Buffer(data, 'base64'));
        stream.end();
    });
}
