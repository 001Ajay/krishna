#Mocks
Everything in this folder with `.js` & `.json` will be copied to the bower package

#Example

```
// mock.js
(function(pAccountHolders){
    pAccountHolders.mock = {
        message: 'Awesome api call'
    };
})(window.pAccountHolders = window.pAccountHolders || {});
```