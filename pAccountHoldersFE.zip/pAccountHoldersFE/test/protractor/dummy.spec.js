'use strict';

describe('A dummy spec so the build will pass for add', function () {
    beforeEach(function () {
        browser.get('/index-e2e-add-lisa.html#?c_r_a_eligible-accounts=add/two_eligible');
    });
    it('should show the first step', function () {
        var htmlElement = element(by.id('pAccountHoldersNavCtrl'));
        expect(htmlElement.isDisplayed()).toBeTruthy();
    });
});

describe('A dummy spec so the build will pass for remove', function () {
    beforeEach(function () {
        browser.get('/index-e2e-remove-lisa.html#?c_r_a_eligible-accounts=remove/two_eligible');
    });
    it('should show the first step', function () {
        var htmlElement = element(by.id('pAccountHoldersNavCtrl'));
        expect(htmlElement.isDisplayed()).toBeTruthy();
    });
});