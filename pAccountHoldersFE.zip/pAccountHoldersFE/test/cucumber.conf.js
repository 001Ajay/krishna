exports.config = {

    framework: 'custom',
    frameworkPath: '../node_modules/protractor-cucumber-framework',

    keepAlive: true,

    multiCapabilities: [
        {
            'browserName': 'chrome',
            'chromeOptions': {

                args: [
                    'test-type', // get rid of the ignore cert warning
                    '--no-sandbox' // Disable chrome sandboxing to improve performance.
                ]
            },
            shardTestFiles: true,
            maxInstances: 4
        }
    ],

    specs: [
        'features/**/*.feature'
    ],

    cucumberOpts: {
        require: ['features/**/step_definitions/*.js'],
        timeout: 10000,
        format: 'pretty',
        tags: ['@stubbed']
    }

};
