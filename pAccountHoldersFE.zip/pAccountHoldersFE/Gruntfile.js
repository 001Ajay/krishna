'use strict';

var serveStatic = require('serve-static');
var path = require('path');

module.exports = function (grunt) {
    require('fl-buildpack-common')(grunt);

    grunt.config.merge({
        hosts: {
            runtime: 'localhost.ing.intranet'
        },
        wiredep: {
            app: {
                src: ['<%= paths.src %>/index-add-lisa.html', '<%= paths.src %>/index-remove-lisa.html'],
                ignorePath: /\.\.\//,
                exclude: [/the-guide-styles/],
                devDependencies: true
            },
            e2e: {
                src: ['<%= paths.src %>/index-e2e-add-lisa.html', '<%= paths.src %>/index-e2e-remove-lisa.html'],
                ignorePath: /\.\.\//,
                exclude: [/the-guide-styles/],
                devDependencies: true
            }
        },
        connect: {
            server: {
                proxies: [
                    {
                        context: '/api/current-accounts/requests/account-holders',
                        host: '<%= hosts.fqdn %>',
                        port: grunt.option('api_port') || 9292,
                        https: false,
                        changeOrigin: false,
                        xforward: false
                    }
                ]
            },
            e2e: {
                options: {
                    middleware: function (connect) {
                        var cwd = grunt.config.get('config.paths.cwd');

                        return [
                            require('grunt-connect-proxy/lib/utils').proxyRequest,
                            connect().use('/lib', serveStatic(
                                path.resolve(cwd, './bower_components'))),
                            connect().use('/lib', serveStatic(
                                path.resolve(cwd, grunt.file.readJSON('.bowerrc').directory || './lib'))),
                            connect().use('/app', serveStatic(
                                path.resolve(cwd, grunt.template.process('<%= paths.tmp %>/instrumented/<%= paths.scripts %>')))),
                            connect().use('/', serveStatic(
                                path.resolve(cwd, grunt.config.get('paths.run')))),
                            connect().use('/', serveStatic(
                                path.resolve(cwd, grunt.config.get('paths.src')))),
                            connect().use('/', serveStatic(
                                path.resolve(cwd, grunt.template.process('<%= paths.test%>/protractor')))),
                            connect().use('/mocks', serveStatic(
                                path.resolve(cwd, grunt.template.process('<%= paths.test%>/mocks'))))
                        ];
                    }
                }
            }
        },
        protractor: {
            options: {
                configFile: 'test/cucumber.conf.js'
            }
        }
    });

    grunt.registerTask('prepareE2e', 'Run the preparation tasks for protractor tests', [
        'clean:e2e',
        'instrument',
        'wiredep:e2e',
        'fileblocks:app',
        'portPick:e2e',
        'portPick:collector',
        'connect:e2e'
    ]);

    grunt.registerTask('prepareCucumber', 'Run the preparation tasks for cucumber tests', [
        'clean:e2e',
        'wiredep:app',
        'portPick:e2e',
        'portPick:collector',
        'configureProxies:server',
        'connect:e2e'
    ]);

    grunt.registerTask('e2e_local', 'Run protractor on local environment', [
        'e2e:local'
    ]);

    grunt.registerTask('serve', 'Start up a server', [
        'force:on',
        'wiredep:app',
        'force:off',
        'fileblocks:app',
        'portPick:server',
        'portPick:livereload',
        'configureProxies:server',
        'connect:server',
        'watch'
    ]);
};