# BuildPack Common

## What is it?
A set of preconfigured grunt tasks to run your application locally.
You can start a server or run unit and protractor tests.
The protractor tests can be tested locally or against the grid.

## Why?
You don't need to make your own Gruntfile or build configurations.
No maintenance.
And because the buildpacks are in sync with the build you don't get any weird problems in the build anymore.
You can now test and verify your applications locally just

# Installation

#### 1. Install as NPM Module
```
npm install fl-buildpack-common
```

#### 2. Update the webdriver

```
./node_modules/fl-buildpack-common/node_modules/protractor/bin/webdriver-manager update
```
_Pro tip: make sure that your proxy is working_

----


# LibrarySets
LibrarySets can be downloaded and configured to the bower.json file.

#### Setting a librarySet
Run the following command to install/overwrite the dependencies in the `bower.json`.

```
grunt setLibrarySet:KITT
```

#### Setting a librarySet by stable/unstable
Run the following command to install/overwrite the dependencies in the
`bower.json` with the server defined librarySet for the stable/unstable branch.
Note that this behaviour also works for `getLibrarySet`.

```
grunt setLibrarySet:stable
```

#### Previewing a librarySet
To lookup which dependencies are included in the librarySet, use the
getLibrarySet function.

```
grunt getLibrarySet:KITT
```

#### Listing all librarySets
To list all available librarySets that are available for install, run:

```
grunt getAllLibrarySets
```

# Testing

### Running tests
Tests can be run with `npm test`, for development we recommend to use the
command `npm watch-test`. This command can be run in a background tab, and
will trigger a growl notification upon test failure.

### Spec lookups
Test specs are defined in the `./spec/` directory. The file structure is
identical to the root, with the filename affixed by `Spec`.
For instance; `./grunt/librarySet.js` becomes `./spec/grunt/librarySetSpec.js`.

The `*Spec.js` affix is essential to identify the files within your editor,
with the same directory structure to simplify lookups.

**Pro Tip:** Do a little research to see if your IDE also supports jasmine plugins
to have the quick option to open a spec from within your script file.

**Sovereign Pro Tip:** When prefixing an 'f' in front of your `describe`, it
will force jasmine to run that test only. Other tests wont be pending. Do it
as: `fdescribe` or `fit`.

## Grunt tasks

```
Available tasks
                  a11y  Test the application for accessibility issues.
                        Defaults to a11y:local. Use a11y:grid
                        --fqdn $(hostname) to use remote selenium hub.
         getLibrarySet  Return the list of dependencies in a library set.
                        `grunt getLibrarySet:angular1.2`.
                        Will return all available librarySets whennot called
                        with any arguments: `grunt getLibrarySet`
         setLibrarySet  Merge and overrule the libraries set's dependencies to
                        bower.js. Use `grunt setLibrarySet:angular1.2`
     getAllLibrarySets  Return a list of all available librarySets
 setLibrarySetByPortal  Merge and overrule the libraries set's dependencies to
                        bower.js. Use `grunt setLibrarySet:angular1.2`
 getLibrarySetByPortal  Return the list of dependencies in a library set by
                        portal. `gruntgetLibrarySetByPortal:open:development`.
                        Will return all availablelibrarySets when not called
                        with any arguments: `grunt getLibrarySetByPortal`
         getAllPortals  Return a list of all available portals
  bower-install-simple  Install or Update Bower Dependencies *
      configureProxies  Configure any specified connect proxies.
                 clean  Clean files and folders. *
               connect  Start a connect web server. *
                  copy  Copy files. *
                jshint  Validate files with JSHint. *
                 watch  Run predefined tasks whenever watched files change.
                eslint  Validate files with ESLint *
            fileblocks  Prepares a block in a file by inserting or removing a
                        line (script tag, link, or reference) for each file
                        matching a specified pattern. *
                 force  Custom task.
            instrument  instruments a file or a directory tree
           reloadTasks  override instrumented tasks
         storeCoverage  store coverage from global
            makeReport  make coverage report
                 karma  run karma. *
         portPickIndie  Scan and pick an available port
              portPick  Scan and pick an available port, for other grunt tasks
                        *
   protractor_coverage  Instrument your code and gather coverage data from
                        Protractor E2E tests *
                 shell  Run shell commands *
               wiredep  Inject Bower components into your source code. *
                 specs  Custom task.
                 serve  Start up a server
                  unit  Test the application
                 bower  Clean the bower installation
                   e2e  Run E2E tests using the local or remote Selenium hub,
                        use e2e:local to run against the local selenium hub,
                        use e2e:grid --fqdn $(hostname) to run against the
                        remote selenium hub
        flMutationTest  Does mutations on the files and reports how often test break.

Tasks run in the order specified. Arguments may be passed to tasks that accept
them by using colons, like "lint:files". Tasks marked with * are "multi tasks"
and will iterate over all sub-targets if no argument is specified.
```
