'use strict';

module.exports = {
    server: {
        targets: [
            'connect.options.port'
        ]
    },
    livereload: {
        targets: [
            'connect.server.options.livereload',
            'watch.options.livereload'
        ]
    },
    karma: {
        targets: [
            'karma.options.port'
        ]
    },
    e2e: {
        targets: [
            'connect.options.port'
        ]
    },
    collector: {
        targets: [
            'protractor_coverage.options.collectorPort'
        ]
    },
    mutation:{
        targets:[
            'mutationTest.options.karma.port'
        ]
    }
};
