'use strict';
var http = require('http');

/**
 * @module kirk
 * @description
 * Module to interact with the kirk API
 *
 * @param {Object} grunt The reference to the initiated grunt instance
 * @returns {Function} The function that you can use to call the kirk API
 */
module.exports = function (grunt) {


    /**
     * Function to make calls to the Kirk API. Reads config, Validates, Parses
     * and handles potential HTTP errors.
     *
     * @param {String|Object} data Parameters object to configure the call, or
     * path
     * @param {String} [data.path] The path you want to access on the server
     * @param {Boolean} [data.parseJSON=true] Whether to parse the response
     * from the server as JSON or not.
     * @param {callbackErrData} callback The response from the server. Can be
     * an object or string if parseJSON was false.
     *
     * @example
     * kirk('libraryset/angular1.4', function(err, librarySet) {
     *     mergeLibrarySet(librarySet);
     * }
     */
    return function(data, callback) {

        // Convert data to object if string
        if(typeof data === 'string') {
            data = { path: data };
        }

        // Make the url
        var url = grunt.config('hosts.kirkAddress') + '/' + data.path;
        grunt.log.writeln('Making API call to: '+url);

        // Retrieve the complete set of all libraries from the server
        http.get(url, function(res) {

            var str = '';

            // Handle the data
            res.on('data', function(chunk) {
                str += chunk.toString();
            });

            // Execute once all buffers are received
            res.on('end', function() {

                // Handle the errors properly
                if(res.statusCode >= 400) {
                    return callback(res.statusCode + ' - ' + str);
                }

                // Optionally Skip the JSON parsing
                if(data.parseJSON === false) {
                    return callback(null, str);
                }

                var parsedResponse;
                try {
                    // Parse the JSON buffer
                    parsedResponse = JSON.parse(str);
                } catch(e) {
                    grunt.log.warn('Could not parse response from server: \n'+
                                    e + '\n' +
                                    str);
                    return callback(e);
                }

                // Trigger error if the response wasn't parsed and isn't an
                // object
                if(typeof parsedResponse !== 'object') {
                    return callback('Output from the server is not json');
                }

                // Return the librarySetName
                return callback(null, parsedResponse);
            });

        // Handle the potential error
        }).on('error', function(err){
            grunt.log.warning('Could not complete request to the kirk server. '+err);
            callback(err);
        });
    };
};
