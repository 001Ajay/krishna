'use strict';

module.exports = function(grunt) {

    var path = require('path');
    var param = require('../lib/parameter')(grunt);
    var a11y = require('../lib/a11y')(grunt);

    var urls = function() {

        var port = grunt.config.get('connect.options.port');
        var fqdn = grunt.config.get('hosts.fqdn');

        // Flatten all arrays to a single array of test urls
        return [].concat(
            a11y.generateAllTestUrls(grunt.config.get('paths.src'), fqdn, port),
            a11y.generateAllTestUrls(path.join(grunt.config.get('paths.test'), 'protractor'), fqdn, port)
        );
    };

    return {
        'local': {
            urls: urls,
            dest: '<%=paths.reports%>/a11y.json',
            options: {
                browser: 'chrome',
                server: param.resolve('selenium-address', 'http://localhost:4444/wd/hub')
            }
        },
        'grid': {
            urls: urls,
            dest: '<%=paths.reports%>/a11y.json',
            options: {
                browser: 'chrome',
                server: param.resolve('selenium-address', 'http://bl00041.nl.europe.intranet:4444/wd/hub')
            }
        }
    }
};
