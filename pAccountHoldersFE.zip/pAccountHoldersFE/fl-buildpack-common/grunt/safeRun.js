'use strict';

var child_process = require('child_process');

module.exports = function(grunt) {

    /**
     * Makes a task run safely in a subprocess. If anything happens in that process, it just crashes and
     * doesn't interfere with the main process. Also has a timeout of half an hour, after which the child
     * process is sent a sigterm signal.
     *
     * @param {string} configVariables The config variables that need to be synced, commaseparated
     * @param {string} task The name of your grunt task, followed by your
     * parameters
     * @returns {Undefined} Prints output of subtask to the console
     */
    grunt.registerTask('safeRun', 'Runs grunt tasks safely', function(configVariables) {
        var done = this.async();
        var setConfigs = configVariables.split(',').map(name => {
            var configValue = grunt.config.get(name);
            var configJson = JSON.stringify(configValue);
            var configBase64 = new Buffer(configJson).toString('base64');
            return 'setConfig:' + name + ':' + configBase64;
        });

        // Convert arguments to a mutable array
        var args = [].slice.call(arguments);

        // Remove the first item, configVariables, because we already parsed it
        args.shift();

        // Concatenate the arguments to parameters to the first task
        // Also concatenate with the current command line flags, such as
        // --force, --gruntfile, --verbose etc.
        var taskWithParameters = args.join(':');
        var cliArguments = setConfigs.concat(taskWithParameters, grunt.option.flags());


        var child = child_process.spawn(
            'grunt',
            cliArguments,
            {
                cwd: grunt.config.get('config.paths.cwd'),
                stdio: 'inherit'
            }
        );
        var maxRunTime = 5 * 60 * 1000; // 5 minutes in milliseconds
        var timeout = setTimeout(function() {
            grunt.fail.warn('Safe run of task exceeded timeout of ' +
                (maxRunTime / 1000) + ' seconds. Could not finish task: ' +
                args.join(':'));
            child.kill('SIGTERM');
        }, maxRunTime);

        child.on('close', function() {
            clearTimeout(timeout);
            done();
        });

    });
};
