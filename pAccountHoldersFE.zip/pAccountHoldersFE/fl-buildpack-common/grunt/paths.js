'use strict';

/**
 * Paths configuration for grunt
 * */
module.exports = function () {
    return {
        src: '<%= config.paths.src %>',
        grunt: '<%= config.paths.grunt %>',
        run: '<%= config.paths.run %>',
        bower: '<%= config.paths.bower %>',
        scripts: '<%= config.paths.scripts %>',
        test: '<%= config.paths.test %>',
        spec: '<%= config.paths.spec %>',
        coverage: '<%= config.paths.coverage %>',
        reports: '<%= config.paths.reports %>',
        tmp: '<%= config.paths.tmp %>',
        www: '<%= config.paths.www %>',
        lib: '<%= config.paths.lib %>'
    };
};
