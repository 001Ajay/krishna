'use strict';

var merge = require('merge');
var fs = require('fs');
var util = require('util');

/**
 * @module bower
 * Bower utilities
 *
 * @param {Object} grunt grunt reference
 */
module.exports = function(grunt) {
    /**
     * Merges two bower files recursively into one. Bower file B overwrites the property keys of bower file A
     *
     * @param {bowerLibraryConfig} bowerConfigA - The original bower file
     * @param {bowerLibraryConfig} bowerConfigB - The libraries that should overwrite and merge into bowerConfigA
     * @returns {bowerLibraryConfig} The merged bower configuration
     */
    function mergeDependencies(bowerConfigA, bowerConfigB) {
        return merge.recursive(true, bowerConfigA, bowerConfigB);
    }

    /**
     * Returns the current bower configuration
     *
     * @param {callbackErrData} done The currently defined bower config in the project
     */
    function getConfig(done) {
        var bowerPath = grunt.config.get('config.paths.bower');
        grunt.log.debug('Getting bower Config');
        grunt.log.debug('Bower config path: '+bowerPath);
        grunt.log.writeln('Bower config path: '+bowerPath);
        grunt.log.debug('Checking existence of bower.json file');

        // Check if the file exists first to trigger a proper error
        fs.exists(bowerPath, function(exists) {
            
            // Stop when the file does not exist
            if(!exists) {
                var err = 'Bower file does not exist, read location: '+bowerPath;
                return done(err);
            }

            fs.readFile(bowerPath, function(err, data) {
            
                // Forward err if present
                if(err) {
                    return done(err);
                }

                grunt.log.debug('Received bower config from fs');
                grunt.log.debug('Bower config: '+data.toString());

                done(null, JSON.parse(data));
            });
        });
    }


    /**
     * @typedef {Object} kirkLibraryConfig
     * @property {String} name The name of the library
     * @property {String} version The version of the library
     * @property {String} type The environment the library should be installed to
     * @example
     * { version: '1.4', name: 'angular-mocks', type: 'DEV' }
     */

    /**
     * @typedef {Object} bowerLibraryConfig
     * @property {Object} dependencies - An Object defining a dependency as a key,
     * with it's versioning number as its value
     * @property {Object} devDependencies - An Object defining a devDependency as a key,
     * with it's versioning number as its value
     * @example
     *  {
     *       dependencies: {
     *           'angular': 1.4,
     *       },
     *       devDependencies: {
     *           'angular-mocks' : '1.4'
     *       }
     *  }
     */

    /**
     * Converts a librarySet list from Kirk to Bower's dependency formatting
     *
     * @param {module:bower~kirkLibrarySet} kirkLibrarySet - A librarySet defined by Kirk
     * @return {module:bower~bowerLibraryConfig} An object containing bower dependencies
     */
    function convertKirkToBowerFormat(kirkLibrarySet) {
        var out = { dependencies: {}, devDependencies: {} };

        kirkLibrarySet.libraries.forEach(function(lib) {

            // Fix for Kirk's awkward `null` stuttering
            // Explain: in the array of libraries returned by kirk, there are
            // objects. Sometimes, there is no object but just `null`.
            // We need to write an exception for that, or fix that in kirk.
            if(lib === null) {
                return;
            }

            if(lib.type === 'RUNTIME') {
                out.dependencies[ lib.name ] = lib.version;
            }
            if(lib.type === 'DEV') {
                out.devDependencies[ lib.name ] = lib.version;
            }
        });

        return out;
    }

    /**
     * Writes the given bower config (object) to bower.json and then calls the
     * callback
     *
     * @param {bowerConfig} bowerConfig A full complete bower configuration to
     * write away
     * @param {callbackErr} callback Will be called when function is done
     */
    function setConfig (bowerConfig, callback) {
        var bowerPath = grunt.config.get('config.paths.bower');

        grunt.log.writeln('Writing to bower file ...' + bowerPath);

        var bowerJson = JSON.stringify(bowerConfig, null, 4);

        // Write new file to disk
        fs.writeFile(bowerPath, bowerJson, function(err) {
            if(err) {
                grunt.log.error(err);
                return callback('Cannot write away bower file to disk. Path:' + bowerPath + ', ' + err);
            }

            grunt.log.writeln('Done. New bower file created!');
            grunt.log.writeln('The new bower config is: \n' +
                util.inspect(bowerConfig, false, null, true));

            callback(null);
        });
    }

    return {
        getConfig: getConfig,
        setConfig: setConfig,
        mergeDependencies: mergeDependencies,
        convertKirkToBowerFormat: convertKirkToBowerFormat
    };
}
