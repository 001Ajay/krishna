'use strict';

module.exports = function(grunt) {
    grunt.registerTask('setConfigVariable',
        'Sets a grunt config variable',
        function(configVariableName, configVariableValue) {
            grunt.config.set(configVariableName, configVariableValue);
        }
    );
};
