'use strict';

var path = require('path');

module.exports = function(grunt) {

    grunt.registerTask('saveKarmaConfig', 'Saves the karma config to the config directory', function() {

        this.requires('setKarmaFiles');
        this.requiresConfig('karmaConfig');

        var karmaConfigJson = JSON.stringify(grunt.config.get('karmaConfig'), null, 4);
        var karmaConfigPath = path.join(grunt.config.get('config.paths.config'), 'karma.conf.js');
        var karmaJs = 'module.exports=function(config) { config.set(' + karmaConfigJson + '); };';

        grunt.file.write(karmaConfigPath, karmaJs);
    });
}
