'use strict';

var async = require('async');
var kirkLib = require('./kirk');
var librarySetLib = require('./librarySet');
var utilitiesLib = require('./utilities');


/**
 * All tools related to retrieving librarySets by portals
 *
 * #### Previewing a librarySet via the portal name and env
 * To lookup which dependencies are included in the librarySet via the portal
 * name, use the getLibrarySetByPortal function.
 * ```
 * grunt getLibrarySetByPortal:open:development
 * ```
 *
 * #### Set a a librarySet to bower via the portal name and env
 * To lookup which dependencies are included in the librarySet via the portal
 * name and environment, use the getLibrarySetByPortal function.
 * ```
 * grunt setLibrarySetByPortal:open:development
 * ```
 *
 * #### Listing all portals
 * To list all available portals, run:
 * ```
 * grunt getAllPortals
 * ```
 */
module.exports = function portalLibarySet(grunt) {

    // Initialize requires
    var kirk = kirkLib(grunt);
    var librarySet = librarySetLib(grunt);
    var utilities = utilitiesLib(grunt);

    grunt.registerTask('setLibrarySetByPortal',
        'Merge and overrule the libraries set\'s dependencies to bower.js. '+
        'Use `grunt setLibrarySet:angular1.2`',
        setLibrarySetByPortal);

    grunt.registerTask('getLibrarySetByPortal',
        'Return the list of dependencies in a library set by portal. `grunt'+
        'getLibrarySetByPortal:open:development`. \nWill return all available'+
        'librarySets when not called with any arguments: `grunt getLibrarySetByPortal`',
        getLibrarySetByPortal);

    grunt.registerTask('getAllPortals',
        'Return a list of all available portals',
        utilities.gruntLogCallback(getAllPortals, function(portals) {

            return 'Got all portals back from the server: \n\n' +
                utilities.wordlist(
                    portals

                    // Only list the enabled ones
                    .filter(function(portal) { return portal.enabled; })

                    // Only show the name
                    .map(function(portal) {
                        return portal.name + ' - ' + portal.environment;
                    })

                    // Sort for nice readings
                    .sort()
                );
        }));



    /**
     * Returns or prints a librarySet by portal and environment
     *
     * @param {String} portal The name of the portal
     * @param {module:portal~environmentValues} environment The type of the environment
     * @param {module:portal~librarySet} callback The librarySet
     */
    function getLibrarySetByPortal(portal, environment, callback) {
        // Proxy function to getOrSetLibrarySetByPortal
        getOrSetLibrarySetByPortal(
            librarySet.getLibrarySet,
            portal,
            environment,
            callback || utilities.gruntCallback(this)
        );
    }
    // TODO put these 2 functions in a generator function to make it even
    // shorter

    /**
     * Configures a librarySet to bower.json by portal and environment
     *
     * @param {String} portal The name of the portal
     * @param {module:portal~environmentValues} environment The type of the environment
     * @param {module:librarySet~librarySet} callback The librarySet
     */
    function setLibrarySetByPortal(portal, environment, callback) {
        // Proxy function to getOrSetLibrarySetByPortal
        getOrSetLibrarySetByPortal(
            librarySet.setLibrarySet,
            portal,
            environment,
            callback || utilities.gruntCallback(this)
        );
    }

    /**
     * Retrieves the librarySetName by portal and environment and passes it on
     * to the getOrSet function
     *
     * @param {Function} getOrSet The function to pass the librarySetName onto
     * @param {String} portal The name of the portal
     * @param {module:portal~environmentValues} environment The type of
     * environment
     * @param {module:librarySet~librarySet} callback The librarySet
     */
    function getOrSetLibrarySetByPortal(getOrSet, portal, environment, callback) {
        if(!callback) {
            callback = this.async();
        }

        if(typeof getOrSet !== 'function' || getOrSet.length !== 2) {
            var err = 'Invalid value for getOrSet function. Expected a function with 2 arguments';
            grunt.log.error(err);
            return callback(err);
        }

        // Fallback to the grunt --option flags if parameters are empty
        portal = portal || grunt.option('portal');
        environment = environment || grunt.option('environment');

        // When the portal flag was not specified..
        if(!portal || portal === true) {
            grunt.log.writeln('The given portal option is invalid or empty');

            // .. give back the librarySet flag example, and a list of all
            // available options
            return getAllPortals(function(err, portals){

                err = 'Please specify the portal. I.E. grunt getLibrarySetByPortal:open or grunt --librarySet=open\n' +
                    'The options are: \n- ' +
                    portals
					.filter(function(portal){ return portal.enabled; })
					.map(function(portal){
						return portal.name + ' - ' + portal.environment;
					})
					.sort()
					.join('\n- ');

                callback(err);
            });
        }

        // A nice way to pass on the callbacks from one function to the next
        // one.
        async.waterfall([

            // Get the librarySetName
            function(callback){
                resolveLibrarySetNameByPortal(portal, environment, callback);
            },

            // And pass it on to getOrSet the librarySet
            getOrSet
        ], callback);
    }

    /**
     * @typedef {Object} portal
     * @property {String} name
     * @property {String} environment
     * @property {String} ciName
     * @property {String} jobName
     * @property {Boolean} enabled
     * @property {Object} modules
     * @property {String} librarySet
     * @example
	 *	{
	 *		"name": "beleggen",
	 *		"environment": "Development",
	 *		"ciName": "gBeleggen",
	 *		"jobName": "portal-build-beleggen",
	 *		"enabled": true,
	 *		"modules": {
	 *			"spectingular-core": "UNSTABLE",
	 *			"spectingular-components": "UNSTABLE"
	 *		},
	 *		"librarySet": "angular1.2"
	 *	}*/

    /**
     * @typedef {Function} portalsCallback
     * @param {String} err Whether an error occured in retrieving the portals
     * @param {Array.<module:portal~portal>} portals The portals in an array
     *
     */

    /**
     * Returs all avaliable portal names on Kirk back via the callback
     *
     * @param {module:portal~portalCallback} callback All portals that are
     * available on kirk
     */
    function getAllPortals(callback) {
        kirk('portals', callback);
    }

    /**
     * The possible environment values for resolveLibrarySetByPortal
     * @enum {String} environmentValues
     */
    var environmentValues = {
        Development: true,
        Acceptance: true,
        Test: true,
        Production: true
    };

    /**
     * Returns the librarySet name for a portal and environment
     *
     * @param {String} portal The name of the portal you want to load the
     * librarySet of
     * @param {module:portal~environmentValues} environment The type of environment you want to load
     * @param {module:librarySet~librarySetNameCallback} callback The
     * librarySet name that is configured on that branch state
     */
    function resolveLibrarySetNameByPortal (portal, environment, callback) {


        // Normalize environment value
        if(typeof environment === 'string' && environment.length > 0) {
            environment = environment.charAt(0).toUpperCase() + environment.slice(1).toLowerCase();
        }

        // validate the value for environment
        if(typeof environment !== 'string' ||  environmentValues[environment] !== true) {
            return callback('Invalid environment value: '+environment+
                            ', should be a string equal to: '+
                            ' \n - '+
                            Object.keys(environmentValues).join('\n - '));
        }

        // Get the librarySetName from the server based on portal, and environment
        kirk({
            path: 'portals/'+portal+'/'+environment+'/libraryset',
            parseJSON: false
        }, callback);
    }

    return {
        getAllPortals: getAllPortals,
        getLibrarySetByPortal: getLibrarySetByPortal,
        setLibrarySetByPortal: setLibrarySetByPortal,
        resolveLibrarySetNameByPortal: resolveLibrarySetNameByPortal,
        getOrSetLibrarySetByPortal: getOrSetLibrarySetByPortal
    };
};
