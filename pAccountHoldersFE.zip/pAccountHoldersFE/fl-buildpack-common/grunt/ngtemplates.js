'use strict';
module.exports = function(grunt) {

    var param = require('../lib/parameter.js')(grunt);

    return {
        module: {
            options: {
                logging: param.resolve('show-debug-info'),
                module: '<%= config.moduleName %>',
                concat: 'module',
                htmlmin: {
                   collapseBooleanAttributes: true,
                   collapseWhitespace: true,
                   removeComments: true,
                   removeEmptyAttributes: true,
                   removeRedundantAttributes: true
                }
            },
            cwd: '<%= config.paths.src %>',
            src: ['<%= config.paths.appHtmlDirectory %>/**/*.html'],
            dest: '<%= config.paths.root %>/templates.js'
        },
        bootPartialOpen: {
            options: {
                logging: param.resolve('show-debug-info'),
                module: '<%= config.moduleName %>',
                concat: 'module',
                prefix: '<%= config.bootPartialPrefix %>',
                htmlmin: {
                    collapseBooleanAttributes: true,
                    collapseWhitespace: true,
                    removeComments: true,
                    removeEmptyAttributes: true,
                    removeRedundantAttributes: true
                }
            },
            cwd: '<%= config.paths.src %>/<%= config.paths.partialPath %>',
            src: '<%= config.paths.bootPartial %>',
            dest: '<%= config.paths.root %>/bootTemplateOpen.js'
        },
        bootPartialOpenOmniChannel: {
            options: {
                logging: param.resolve('show-debug-info'),
                module: '<%= config.moduleNameWithoutApp %>',
                concat: 'module',
                prefix: '<%= config.moduleNameWithoutApp %>/app/partials/',
                htmlmin: {
                    collapseBooleanAttributes: true,
                    collapseWhitespace: true,
                    removeComments: true,
                    removeEmptyAttributes: true,
                    removeRedundantAttributes: true
                }
            },
            cwd: '<%= config.paths.src %>/<%= config.paths.partialPath %>',
            src: '<%= config.paths.bootPartial %>',
            dest: '<%= config.paths.root %>/bootTemplateOpenOmniChannel.js'
        }
    }
};
