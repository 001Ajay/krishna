'use strict';

var wiredep = require('wiredep');

module.exports = function(grunt) {

    grunt.registerTask('setKarmaFiles', 'Sets the files to the karma config with wiredep', function() {
        var paths = grunt.config('config').paths;

        // Get the files from bower.json with wiredep
        var opts = {
            bowerJson: grunt.file.readJSON(paths.bower),
            cwd: paths.cwd || grunt.config('cwd'),
            directory: paths.lib,

            devDependencies: true,
            dependencies: true,

            onError: function(err) {
                if(err.code === 'PKG_NOT_INSTALLED') {
                    grunt.log.warn(err);
                }
                else {
                    grunt.fail.fatal(err);
                }
            }

        };

        var files  = wiredep(opts).js;
        
        // in case module does not have js files
        if (!files) {
            files=[];
        }

        // Make all paths relative, not including the cwd
        files = files.map(f => f.replace(opts.cwd + '/', ''));

        putDependencyOnTop(files, /jquery\.js$/i);

        // Add build dependencies
        files = files.concat([

            'test/mocks/*.js', // all mock data.
            'test/mocks/**/*.js', // all mock data.
            'src/app/*.module.js',
            'src/app/*.js',
            'src/app/**/*.module.js',
            'src/app/**/*.js',
            'src/js/*.js', // contains the angular.module('name', [deps]) which is required before using it.
            'src/js/**/*.js', // all other js files.
            'test/unit/lib/**/*.js', // all utility stuff.
            'test/unit/**/*.js', // all the tests.,
            'src/app/**/*.html', // partials
            'src/partials/**/*.html' // partials
        ]);

        // Set the files to the karma config
        grunt.config.set('karmaConfig.files', files);
        grunt.config.set('karmaConfig.basePath', opts.cwd);

        // Bind preprocessors to rootpath, because basePath config
        // is resolved after preprocessors load the templates.
        var preprocessors = grunt.config('karmaConfig.preprocessors');
        var newPre = {};
        Object.keys(preprocessors).forEach(key => {
            newPre[opts.cwd+'/'+key] = preprocessors[key]
        });

        grunt.config.set('karmaConfig.preprocessors', newPre);
    });

    function putDependencyOnTop(arr, depMatch){
        var depIndex = arr.findIndex(dep => depMatch.test(dep));
        if (!~depIndex) {return;} // not found

        var dep = arr[depIndex];
        arr.splice(depIndex, 1);
        arr.unshift(dep);
    }
};
