'use strict';

module.exports = function(grunt) {

    return {

        // frameworks to use
        // available frameworks: https://npmjs.org/browse/keyword/karma-adapter
        frameworks: ['jasmine'],

        // list of files / patterns to load in the browser
        files: [
            // run setKarmaFiles to fill the files list
        ],

        // list of files to exclude
        exclude: [
            'src/js/**/generated/**/*.js', // assume that generated javascript will be placed in a directory named generated.
            'src/partials**/generated/**/*.html' // assume that generated partials will be placed in a directory named generated.
        ],

        // preprocess matching files before serving them to the browser
        // available preprocessors: https://npmjs.org/browse/keyword/karma-preprocessor
        preprocessors: {
            'src/partials/**/*.html': 'html2js',
            'src/app/**/*.html': 'html2js',
            'src/**/!(momentjs)/*.js': 'coverage'
        },

        coverageReporter: {
            reporters: [
                {type: 'html', dir: 'reports/karma/coverage'},
                {type: 'json', dir: 'reports/karma/coverage'},
                {type: 'text'}
            ]
        },

        ngHtml2JsPreprocessor: {
            stripPrefix: 'src/',
            moduleName: '<%=config.moduleName%>' // change to modulename
        },

        // test results reporter to use
        // possible values: 'dots', 'progress'
        // available reporters: https://npmjs.org/browse/keyword/karma-reporter
        reporters: ['progress', 'coverage', 'junit'],

        junitReporter: {
            outputDir: 'reports/karma/',
            outputFile: 'reports.xml'
        },
        // web server port
        // port: 0,

        // enable / disable colors in the output (reporters and logs)
        colors: !grunt.option('nocolor'),

        // level of logging
        // possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO || config.LOG_DEBUG
        logLevel: grunt.option('debug') ? 'DEBUG' : 'INFO',

        // start these browsers
        // available browser launchers: https://npmjs.org/browse/keyword/karma-launcher
        browsers: ['PhantomJS'],

        plugins: [
            'karma-jasmine',
            'karma-junit-reporter',
            'karma-coverage',
            'karma-chrome-launcher',
            'karma-firefox-launcher',
            'karma-phantomjs-launcher',
            'karma-ng-html2js-preprocessor'
        ],

        // Continuous Integration mode
        // if true, Karma captures browsers, runs the tests and exits
        singleRun: false,

        // enable / disable watching file and executing tests whenever any file changes
        autoWatch: true,
        captureTimeout: 10000,
        browserDisconnectTimeout : 10000,
        browserDisconnectTolerance : 1,
        browserNoActivityTimeout : 60000

    };


};
