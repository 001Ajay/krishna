'use strict';

module.exports = function(grunt) {
    var param = require('../lib/parameter')(grunt);

    return {
        options: {
            keepAlive: true,
            noColor: false,
            collectorPort: 0,
            debug: false,
            coverageDir: '<%= paths.coverage %>/protractor',
            configFile: '<%=config.paths.config%>/protractor.conf.js'
        },
        grid: {
            options: {
                args: {
                    baseUrl: 'http://<%= hosts.fqdn %>:<%= connect.options.port %>/',
                    seleniumAddress: param.resolve('selenium-address', 'http://bl00041.nl.europe.intranet:4444/wd/hub'),
                    specs: [
                        '<%= paths.test %>/protractor/**/*spec.js',
                        '<%= paths.test %>/protractor/**/*Spec.js'
                    ]
                }
            }
        },
        local: {
            options: {
                args: {
                    baseUrl: 'http://localhost:<%= connect.options.port %>/',
                    specs: [
                        '<%= paths.test %>/protractor/**/*spec.js',
                        '<%= paths.test %>/protractor/**/*Spec.js'
                    ]
                }
            }
        }
    }
};
