'use strict';

/**
 * Hosts configuration for grunt
 * */
module.exports = function (grunt) {

    var param = require('../lib/parameter.js')(grunt);

    return {
        kirkAddress: param.resolve('kirk-address',
            'http://spectingular.europe.intranet/api/kirk'),
        fqdn: param.resolve('fqdn', 'localhost'),
        runtime: '0.0.0.0'
    };
};
