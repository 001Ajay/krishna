'use strict';

module.exports = {
    files: '<%= paths.scripts %>/**/*.js',
    options: {
        lazy: true,
        basePath: '<%= paths.tmp %>/instrumented'
    }
};
