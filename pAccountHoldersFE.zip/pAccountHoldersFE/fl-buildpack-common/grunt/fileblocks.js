'use strict';

module.exports = {
    app: {
        files: [{
            options: {
                removeFiles :true
            },
            src: ['<%= paths.src %>/*.html', '<%= paths.run %>/*.html', '<%= paths.test %>/protractor/**/*.html'],
            blocks: {
                app: {
                    cwd: '<%= paths.src %>',
                    src: ['app/*.module.js', 'app/**/*.module.js',  'app/*.js', 'app/**/*.js']
                },
                run: {
                    cwd: '<%= paths.run %>',
                    src: ['app/*.module.js', 'app/**/*.module.js',  'app/*.js', 'app/**/*.js']
                },
                mocks: {
                    cwd: '<%= paths.test %>',
                    src: ['mocks/*.js', 'mocks/**/*.js']
                }
            }
        }
        ]
    }
};
