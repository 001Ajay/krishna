'use strict';

module.exports = {
    options: {
        jshintrc: require('path').join(__dirname, '..', 'config', 'jshint.json'),
        reporter: require('jshint-junit-reporter'),
        reporterOutput:'<%=config.paths.reports%>/jshint/jshint.xml',
        makeFilesRelative: false
    },
    scripts: {
        src: ['<%= paths.src %>/**/*.js']
    }
};
