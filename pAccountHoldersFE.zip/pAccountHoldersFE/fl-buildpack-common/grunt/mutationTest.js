'use strict';
var fs = require('fs');
var path = require('path');
var glob = require('glob');

module.exports = function(grunt) {

    var wiredep = require('wiredep');

    // I'm calling this flMutationTest to refer to the FruitLoops mutation test
    // There is also another mutationTest grunt task maintained within the
    // company by theGuide team. Only, this test automatically configures the
    // dependencies and relies on the FruitLoops defined styleguide
    grunt.registerTask('flMutationTest',  'Run a mutation test', mutationTest);

    function mutationTest() {
        // Load grunt-mutation-testing dependency
        grunt.loadNpmTasks('grunt-mutation-testing');

        // Guard statements to check application state
        var cwd = process.cwd();
        var karmaConfDir = 'test/karma.conf.js';
        var specFiles = 'test/unit/**/*[Ss]pec.js';
        var jsFiles = 'src/app/**/*.js';

        if (!fs.existsSync(cwd + '/' + karmaConfDir)) {
            return grunt.fail.fatal('no "karma.conf.js" found at ' + cwd + '/' + karmaConfDir);
        }

        // Test if the spec and js files that were configured exist
        if (!glob.sync(specFiles).length){
            return grunt.fail.fatal('no testfiles found at ' + cwd + '/' + specFiles);
        }
        if (!glob.sync(jsFiles).length){
            return grunt.fail.fatal('no js files found at ' + cwd + '/' + jsFiles);
        }

        // Use wiredep to locate js dependencies
        var config = grunt.config.get('config');
        var files = wiredep({devDependencies:true}).js.map(f => f.replace(cwd + '/', ''));
        files = files.concat([
            // app files
            'src/**/*.module.js',
            'src/**/*.js',
            'src/**/*.html'
        ]);

        grunt.config.set('mutationTest', {
            options: {
                karma: {
                    // FileSpec fails a promise. It doesn't really matter what is filled here, as long as it is not a path that resolves to a file. But it helps the application to choose the right way of matching specs
                    fileSpecs: 'bs-property that makes the application work',
                    configFile: karmaConfDir,
                    waitforRunnerTime: 30
                },
                reporters: {
                    html: {
                        dir: 'reports/mutation-test-html'
                    },
                    text: {
                        dir: 'reports/mutation-test-text'
                    }
                }
            },
            all: {
                options: {

                    // Fix issues in grunt-mutation-test, either built in in grunt-mitation-testing
                    code: files,
                    specs: specFiles,
                    mutate: [jsFiles]
                }
            }
        });

        grunt.task.run([
            'portPick:mutation',
            'mutationTest:all']);
    };


    return mutationTest;

};
