'use strict';


/**
 * This configuration is used for running tests via cucumber. Go to protractor_coverage.js for the jasmine protractor configuration
 *
 * @param {Object} grunt The grunt object created in gruntfile.js
 * @returns {Object} Settings to define on grunt.config('protractor')}
 */
module.exports = function(grunt) {
    var param = require('../lib/parameter')(grunt);

    return {
        options: {
            keepAlive: true,
            noColor: false,
            collectorPort: 0,
            debug: false,
            coverageDir: '<%= paths.coverage %>/cucumber',
            configFile: '<%=config.paths.config%>/cucumber.conf.js'
        },
        grid: {
            options: {
                args: {
                    baseUrl: 'http://<%= hosts.fqdn %>:<%= connect.options.port %>/',
                    seleniumAddress: param.resolve('selenium-address', 'http://clrv0000013118.ic.ing.net:4444/wd/hub')
                }
            }
        },
        local: {
            options: {
                args: {
                    baseUrl: 'http://localhost:<%= connect.options.port %>/'
                }
            }
        }
    }
};
