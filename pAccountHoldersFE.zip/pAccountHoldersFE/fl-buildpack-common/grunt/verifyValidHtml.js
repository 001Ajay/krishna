'use strict';

var glob = require('glob');
var fs = require('fs');
var async = require('async');
var path = require('path');
var minify = require('html-minifier').minify;

module.exports = function(grunt) {

    grunt.registerTask('verifyValidHtml', 'Verifies that the HTML is parseable by html minifier', function() {

        var doneWithGrunt = this.async();
        var config = grunt.config.get('config');

        // In case someone defined config.paths.src as a root path, and cwd is
        // a root path as well, make src relative so you don't get
        // /root/cwd+/root/cwd/src as src directory
        if(config.paths.src.charAt(0) === '/') {
            grunt.log.warn('Config.paths.src should not be defined as a root path, but should be relative instead from cwd');
            var relativeSrc = path.relative(config.paths.cwd, config.paths.src);
        }
        else {
            var relativeSrc = config.paths.src;
        }

        var src = path.join(
            config.paths.cwd,
            relativeSrc
        );

        async.waterfall([

            // Get the file names by the ng templates pattern
            done => getFilenamesByPattern(
                src,
                grunt.config.get('ngtemplates').module.src,
                done
            ),

            // Test whether the files can be parsed by htmlmin
            testFiles,

            // Write to htmlresult.json
            writeFile

        ], (err) => {
            if(err) {
                grunt.log.warn('An error occured in the process of verifyValidHTML');
                grunt.log.warn(err);
            }
            doneWithGrunt();
        });
    });

    /**
     * Writes away the htmlReport.json
     *
     * @param {object} results The output of testFiles
     * @param {function} callback Returns err when file writing goes wrong
     */
    function writeFile(results, callback) {
        var htmlReportJson = JSON.stringify(results, null, '    ');
        var htmlReportPath = path.join(grunt.config.get('config.paths.reports'), 'htmlReport.json');

        grunt.file.write(htmlReportPath, htmlReportJson);
        callback();
    }

    /**
     * Tests each file whether it can be parsed and returns an object with the results
     *
     * @param {array} filenames An array of file names
     * @param {function} done err, data
     * @example
     * // Returns
     * {
     *      filenameA.html: true,
     *      filenameB.html: false
     * }
     */
    function testFiles(filenames, done) {
        var src = path.join(
            grunt.config.get('config.paths.cwd'),
            grunt.config.get('config.paths.src')
        );

        async.map(filenames, (filename, done) => {
            testFile(
                filename,
                grunt.config.get('ngtemplates.module.options.htmlmin'),
                done
            )
        }, (err, results) => {

            // Make object out of results
            var resultObj = filenames.reduce((obj, filename, index) => {
                var cleanFilename = filename.replace(src, '');
                if(!results[index]) {
                    obj[cleanFilename] = false;
                }
                return obj
            }, {});

            done(null, resultObj);
        });
    }

    /**
     * Gets the file names by a file pattern and returns it with a callback
     *
     * @param {src} The src directory to start the patterns from
     * @param {array} patterns An array of file patterns
     * @param {function} callback Callback with err, array of file names
     */
    function getFilenamesByPattern(src, patterns, callback) {
        async.map(patterns, function(pattern, done) {
            var fullPathPattern = path.join(src, pattern);
            grunt.verbose.ok('globbing for pattern: ' + fullPathPattern);
            glob(fullPathPattern, done);
        }, function(err, fileNamesByPattern) {
            if(err) {
                return callback(err);
            }

            // Combine all arrays of filename by patterns into one array
            var fileNames = [].concat.apply([], fileNamesByPattern);

            grunt.verbose.writeln('filenames are: \n' + fileNames.join('- \n'));
            callback(err, fileNames);
        });
    }

    /**
     * Returns a boolean callback whether the file could be parsed & html
     * minified. Returns False when an error occured.
     *
     * @param {string} filename
     * @param {object} options A html-minifier options object:
     * https://github.com/kangax/html-minifier#options-quick-reference
     * @param {function} callback Invoked asynchronously with the result as err, boolean.
     */
    function testFile(filename, options, callback) {
        fs.readFile(filename, 'utf8', function(err, fileContent) {
            if(err) {
                return callback(err);
            }

            try {
                minify(fileContent, options);
            }
            catch (e) {
                grunt.log.warn('An error occured in minifying the file: ', filename, e);
                return callback(null, false);
            }
            callback(null, true);
        });
    }

};
