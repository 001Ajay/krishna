'use strict';

module.exports = {
    www: [
        '<%= paths.www %>'
    ],
    test: [
        '<%= paths.tmp %>',
        '<%= paths.coverage %>/unit'
    ],
    e2e: [
        '<%= paths.tmp %>',
        '<%= paths.coverage %>/protractor'
    ],
    flaky: [
        '<%= paths.coverage %>/protractorCoverage'
    ],
    lib: [
        '<%= paths.lib %>'
    ]
};
