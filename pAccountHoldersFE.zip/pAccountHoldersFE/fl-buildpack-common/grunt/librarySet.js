'use strict';

var async = require('async');
var util = require('util');
var kirkLib = require('./kirk');
var bowerLib = require('./bower');
var utilitiesLib = require('./utilities');

/**
 * @module librarySet
 * @param {Object} grunt Pass an initialized grunt object to build upon
 * @description
 *
 * This is a script that allows you to install a librarySet's dependencies via
 * a simple grunt command.
 *
 * ---
 *
 * ## Usage:
 * #### To set a libraryset to the bower config
 * ```
 * grunt setLibrarySet:KITT
 * ```
 *
 * #### Previewing a librarySet
 * To lookup which dependencies are included in the librarySet, use the
 * getLibrarySet function.
 * ```
 * grunt getLibrarySet:KITT
 * ```
 *
 * #### Listing all librarySets
 * To list all available librarySets that are available for install, run:
 * ```
 * grunt getAllLibrarySets
 * ```
 *
 * ---
 *
 * ### Using it outside of grunt
 * To include this module outside of grunt, initialize it first with the grunt
 * settings, then you can call each module individually.
 *
 * ---
 *
 * ## How the library works
 * The `setLibrarySet` function uses the `getLibrarySet` function to retrieve
 * the librarySet dependencies from Kirk, asynchronous and paralel with
 * `getBowerConfig`. The librarySet then gets parsed with
 * `convertKirkToBowerFormat` and then merged with `mergeBowerDependencies`.
 * Then called to `getBowerConfig` to finally write the new `bower.json` away.
 *
 **/
module.exports = function librarySet(grunt) {

    // Initialize requires
    var kirk = kirkLib(grunt);
    var bower = bowerLib(grunt);
    var utilities = utilitiesLib(grunt);

    // Private shared variables
    var stableUnstableRegex = /^(stable|unstable)$/i;

    grunt.registerTask('getLibrarySet',
        'Return the list of dependencies in a library set. `grunt '+
        'getLibrarySet:angular1.2`. \nWill return all available librarySets when'+
        'not called with any arguments: `grunt getLibrarySet`',
        getLibrarySet);

    grunt.registerTask('setLibrarySet',
        'Merge and overrule the libraries set\'s dependencies to bower.js. '+
        'Use `grunt setLibrarySet:angular1.2`',
        setLibrarySet);

    grunt.registerTask('getAllLibrarySets',
        'Return a list of all available librarySets',
        utilities.gruntLogCallback(getAllLibrarySetNames, utilities.wordlist));

    /**
     * @typedef {Function} librarySetCallback
     * @param {String} err - Information about the error.
     * @param {Object} librarySet - LibrarySet
     */

    /**
     * Retrieves a librarySet form Kirk, logs it in grunt and optionally sends
     * the dependencies back with a callback in a bower.js style formatting
     *
     * @param {String} librarySetName - The name of your librarySet
     * @param {module:librarySet~librarySetCallback} callback - Will be called when done
     */
    function getLibrarySet(librarySetName, callback) {
        if(!callback) {
            callback = this.async();
        }

        librarySetName = librarySetName || grunt.option('librarySet');

        // When the librarySet flag was not specified..
        if(!librarySetName || librarySetName === true) {
            grunt.log.writeln('The given librarySet option is invalid or empty');

            // .. give back the librarySet flag example, and a list of all
            // available options
            return getAllLibrarySetNames(function(err, libraryNames){

                err = 'Please specify the library set. I.E. grunt getLibrarySet:KITT or grunt --librarySet=KITT\n' +
                    'The options are: \n- ' +
                    libraryNames.sort().join('\n- ');

                grunt.log.error(err);
                callback(err);
            });
        }

        if (librarySetName.match(stableUnstableRegex)) {
            return resolveLibrarySetNameByStableUnstable(librarySetName, function (err, resolvedLibrarySetName) {

                // FWD Error if present
                if(err) {
                    return callback(err);
                }

                // Trigger a proper error and die when resolvedLibrarySetName
                // is equal to "stable" or "unstable" to prevent a recursive
                // loop
                if(resolvedLibrarySetName.match(stableUnstableRegex)) {
                    err = 'IMPROPERLY DECLARED LIBRARYSET '+librarySetName+'.'+
                        'librarySetName "'+librarySetName+'" resolves to ' +
                        resolvedLibrarySetName + '. Causing an infinite' +
                        'resolving loop. Please Do not use ambiguous' +
                        'librarySetNames such as stable or unstable and make it' +
                        'more descriptive.';
                    grunt.log.error(err);
                    return callback(err);
                }

                // Call the same function again with the resolved
                // librarySetName
                getLibrarySet(resolvedLibrarySetName, callback);
            });
        }

        kirk('librarysets/'+librarySetName, function (err, librarySet) {
            if(err) {
                return callback(err);
            }

            var dependencies = bower.convertKirkToBowerFormat(librarySet);

            // Print a pretty log with all the dependencies
            grunt.log.writeln(
                librarySetName +
                ' contains the following dependencies: \n' +
                util.inspect(dependencies, false, null, true));

            // Send the data back if wanted
            callback(null, dependencies);
        });
    }

    /**
     * @typedef {Function} librarySetNamesCallback
     * @param {String} err - Information about the error.
     * @param {Array} librarySetNames - The librarySet names in the shape of a
     * string
     */

    /**
     * Returns all librarySetNames that are available to install
     *
     * @param {module:librarySet~librarySetNamesCallback} callback - Will be
     * called with all librarySetNames in an Array
     *
     */
    function getAllLibrarySetNames(callback){
        grunt.log.writeln('Getting all library set names');

        kirk('librarysets', function (err, librarySets) {

            // Forward the error
            if(err) {
                return callback(err);
            }

            // Format the libraries in a nice response
            var libraries = librarySets.map(function (library) {
                return library.name;
            });

            // Return the libraries
            return callback(null, libraries);
        });
    }

	/**
	 * @typedef {Object} kirkLibrarySet
     * @property {String} name The name of the librarySet
     * @property {Array.<module:librarySet~kirkLibraryConfig>} libraries All libraries, defined
     * @example
     * {
     *      name: 'KITT',
     *      libraries:
     *          [ { version: '1.4', name: 'angular', type: 'RUNTIME' },
     *          null,
     *          { version: '1.4', name: 'angular-mocks', type: 'DEV' }]
     *      }
     * }
     **/

    /**
     * @typedef {Function} librarySetNameCallback
     * @param {String} err - Information about the potential error.
     * @param {String} librarySetName - The librarySet name
     * string
     */

    /**
     * Returns the librarySet name for the current module and stable/unstable branch
     *
     * @param {String} stableUnstable The branch you want to resolve to
     * @param {module:librarySet~librarySetNameCallback} callback The librarySet name that is
     * configured on that branch state
     */
    function resolveLibrarySetNameByStableUnstable (stableUnstable, callback) {

        // validate the type of stableUnstable
        if(typeof stableUnstable !== 'string' || !stableUnstable.match(stableUnstableRegex)) {
            return callback('Invalid stableUnstable type: '+stableUnstable+', should be a string matching: '+stableUnstableRegex);
        }

        // Passes trough the arguments in the callback to the next function
        async.waterfall([
            // Get the bower config
            bower.getConfig,

            // Get the librarySetName from the server based on the name and
            // stableUnstable
            function (bowerConfig, callback) {
                kirk({
                    path: 'modules/'+bowerConfig.name+'/library-sets/'+stableUnstable,
                    parseJSON: false
                }, callback);
            }
        ], callback);
    }
    /**
     * Gets the librarySet's dependencies from the server and overwrites them
     * in the bower config
     *
     * @param {String} librarySetName The name of your librarySet
     * @param {callbackErr} callback Will be fired after completion, with
     * potentially err as an error string
     */
    function setLibrarySet(librarySetName, callback) {

        grunt.log.debug('Running setLibrarySet function with: '+librarySetName);
        callback = callback || this.async();

        async.parallel({

            // Get the dependencies in the current bower file
            bower : bower.getConfig,

            /* Get the dependencies in the given library set */
            library: function (done) {
                return getLibrarySet(librarySetName, done);
            }

        // Once we got both, gotDeps will be called
        }, function (err, dependencies) {

            grunt.log.writeln('Received both dependencies from Kirk and bower.js');

            // Trigger on fail
            if(err) {
                // make nice debug RED error message
                grunt.log.error(err);

                return callback(err);
            }

            var newBower = bower.mergeDependencies(
                dependencies.bower,
                dependencies.library);

            grunt.log.writeln('Created new bower file');

            bower.setConfig(newBower, callback);

        });
    }

    return {
        // LibrarySet Related
        getLibrarySet: getLibrarySet,
        setLibrarySet: setLibrarySet,
        getAllLibrarySetNames: getAllLibrarySetNames,

        resolveLibrarySetNameByStableUnstable: resolveLibrarySetNameByStableUnstable
    };
};


