'use strict';

module.exports = function(grunt) {

    /**
     * Sets an entire config variable as a grunt task. Useful for passing initialized grunt configs to other processes via the command line
     *
     * @param {String} name The name of your config variable
     * @param {String} configBase64 The config variable encoded as json, then base64ized for command line safety
     */
    grunt.registerTask('setConfig', 'Overwrite an entire config variable', function(name, configBase64) {
        var configJson = new Buffer(configBase64, 'base64').toString();
        var config = JSON.parse(configJson);

        grunt.config.set(name, config);
    });
};
