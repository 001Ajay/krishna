'use strict';

module.exports = {
    options: {
        livereload: 0
    },
    js: {
        files: [
            '<%= paths.run %>/**/*.js',
            '<%= paths.src %>/**/*.js',
            '<%= paths.lib %>/**/*.js'
        ],
        tasks: [
            'jshint:scripts'
        ]
    },
    html: {
        files: [
            '<%= paths.src %>/index.html',
            '<%= paths.run %>/index.html',
            '<%= paths.scripts %>/**/*.html'
        ]
    }
};
