'use strict';

// shamelessly borrowed from https://github.com/yeoman/generator-angular
module.exports = {
    app: {
        src: ['<%= paths.src %>/*.html', '<%= paths.test %>/protractor/**/*.html'],
        ignorePath: /\.\.\//,
        devDependencies: true,
        exclude: '^((?!(<%= paths.lib %>\/(theguide|theGuide|TheGuide|the-guide|tg))).)*\.css$', // Any CSS file that is NOT in a The Guide module
        onError: function (err) {
            if (err && err.code === 'PKG_NOT_INSTALLED') {
                // Make sure wiredep still includes the packages it CAN find when it cannot find some others
                var pkgName = err.message ? err.message.split(/\s/)[0] : 'unknown';
                grunt.log.warn('Package [' + pkgName + '] is not installed and is therefore excluded from wiredep.');
            } else {
                // Rethrow all other errors
                throw err;
            }
        }
    },
    karma: {
        devDependencies: true,
        src: '<%= karma.unit.configFile %>',
        ignorePath: /\.\.\//,
        fileTypes: {
            js: {
                block: /(([\s\t]*)\/{2}\s*?bower:\s*?(\S*))(\n|\r|.)*?(\/{2}\s*endbower)/gi,
                detect: {
                    js: /'(.*\.js)'/gi
                },
                replace: {
                    js: '\'{{filePath}}\','
                }
            }
        }
    }
};
