'use strict';

var path = require('path');
module.exports = function (grunt) {

    return {

        www: {
            files: [{
                expand: true,
                cwd: '<%= paths.src %>',
                src: ['**'],
                dest: '<%= paths.www %>/'
            },
                {
                    src: '<%= paths.bower_components %>/**/*',
                    dest: '<%= paths.www %>/'
                }]
        },

        protractor: {
            cwd: path.join(__dirname, '..', 'tpls'),
            expand: true,
            src: ['protractor.conf.js'],
            dest: '<%=config.paths.config%>',
            options: {process: replaceRootElement}
        },

        cucumber: {
            cwd: path.join(__dirname, '..', 'tpls'),
            expand: true,
            src: ['cucumber.conf.js'],
            dest: '<%=config.paths.config%>',
            options: {process: replaceTestPath}
        }
    };

    function replaceRootElement(protractorConfContent) {
        // Updates protractor config
        var paths = grunt.config('config').paths;
        var buildSettingsPath = path.join(paths.config, '/buildSettings.json');
        var rootElement = '';
        var startPage = '';
        if (grunt.file.exists(buildSettingsPath)) {
            var buildSettings = grunt.file.readJSON(buildSettingsPath);
            if (buildSettings.protractor) {
                if(buildSettings.protractor.rootElement) {
                    rootElement = "rootElement: '" + buildSettings.protractor.rootElement + "',";
                }
                if (buildSettings.protractor.startPage) {
                    startPage = "startPage: '" + buildSettings.protractor.startPage + "'";
                }
            }
        }
        
        return protractorConfContent.replace('$startPage$', startPage).replace('$rootElement$', rootElement);
    }

    function replaceTestPath(cucumberConfContent) {
        var paths = grunt.config('config').paths;
        var testPath = path.join(paths.cwd , paths.test).replace(/\\/g, '\\\\');
        return cucumberConfContent.replace(/(\$testPath\$)/g, testPath);
    }

};
