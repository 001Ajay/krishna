'use strict';
var inspect = require('eyes').inspector({

    maxLength: 4096
});

module.exports = function(grunt) {
    grunt.registerTask('printConfigVariable',
        'Print a grunt config variable',
        function(configVariableName) {

            this.requiresConfig(configVariableName);
            grunt.log.writeln('grunt.config.'+configVariableName+':');

            var configVariableValue = grunt.config.get(configVariableName);

            inspect(configVariableValue);
        }
    );
};
