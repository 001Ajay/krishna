'use strict';

/**
 * @typedef {Function} callbackErr
 * @property {String} err Information about the err, otherwise null
 */

/**
 * @typedef {Function} callbackErrData
 * @property {String} err Information about the err, otherwise null
 * @property {Object} data The data, in the shape of an object
 */

/**
 * @module utilities
 *
 * Utilities to use to generate nice grunt log messages or whatever else is
 * nice to reuse across modules
 *
 * @param {Object} grunt The reference to grunt for logging
 */
module.exports = function(grunt) {

    /**
     * A function that can be used to log an error to grunt when calling the
     * function with grunt
     *
     * @param {Object} self Grunt function `this` object
     * @returns {Function} Callback function that can be passed into a function
     * that will call a fatal error when err is truthy
     * @example
     * grunt.registerTask("myFunction", "My Description", myFunction);
     * function myFunction(callback) {
     *      if(!callback) callback = utilities.gruntCallback(this);
     *      ...
     * }
     */
    function gruntCallback(self) {
        var done = self.async();
        return function(err, msg) {
            if(err){
                grunt.fail.fatal(err);
            }
            grunt.log.ok(msg);
            done();
        }
    }

    /**
     * Generates a nice looking string from an array
     *
     * @param {Array} arr An array of items you want to look nice
     * @returns {String} Bullet like list of items
     * @example
     *  - foo
     *  - bar
     *  - john
     */
    function wordlist(arr) {
        return '\n - ' + arr.join('\n - ');
    }

    /**
     * Function to generate a nice response to grunt from a callback
     *
     * @param {Function} func Function that should be called that gives a
     * callback with either an err or response variable
     * @param {Function} response Function to generate the response. Should
     * return a string to be logged
     * @returns {Function} Asynchronous grunt function that can be registered
     * as a task
     */
    function gruntLogCallback(func, response) {
        return function() {
           var done = this.async();

           func(function (err, data) {
                if(err) {
                    grunt.fail.fatal(err);
                }
                // Generate a nice response message with response()
                grunt.log.writeln(response(data));
                done();
           });
        };
    }

    return {
        gruntCallback: gruntCallback,
        gruntLogCallback: gruntLogCallback,
        wordlist: wordlist
    };
};
