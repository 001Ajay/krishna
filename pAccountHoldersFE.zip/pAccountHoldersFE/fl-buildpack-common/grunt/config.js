'use strict';

/**
 * Builds the configuration for grunt
 * */
module.exports = function (grunt) {
    var path = require('path');
    var basePath = require('path').resolve();
    var bowerRcPath = basePath + '/.bowerrc';
    var cwd = grunt.config('cwd') || grunt.option('cwd') || process.cwd();
    var bowerJsonPath = path.join(cwd, 'bower.json');
    var bowerJson = grunt.file.exists(bowerJsonPath) && grunt.file.readJSON(bowerJsonPath);

    return {
        moduleName: bowerJson.moduleName || bowerJson.name,
        paths: {
            cwd: cwd,
            config: path.join(__dirname, '..', 'config'),
            root: '',
            tpls: 'tpls',
            src: 'src',
            grunt: path.join(cwd, 'grunt'),

            // This property is being used in buildpack-ionic
            run: 'run',

            bower: bowerJsonPath,
            scripts: 'src/app',
            test: 'test',
            spec: 'spec',
            reports: 'reports',
            coverage: 'reports/protractorCoverage',
            tmp: '.tmp',
            www : 'www',
            lib : 'lib',
            bowerComponentsDirectory: (
                grunt &&
                grunt.file.exists(bowerRcPath) &&
                grunt.file.readJSON(bowerRcPath).directory ?
                    grunt.file.readJSON(bowerRcPath).directory :
                    'bower_components'
            ),
            appHtmlDirectory : bowerJson.newStyle ? 'app' : 'partials'
        }
    };
};

