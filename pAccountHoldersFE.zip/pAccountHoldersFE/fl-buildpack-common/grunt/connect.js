'use strict';

var serveStatic = require('serve-static');
var path = require('path');

module.exports = function (grunt) {
    return {
        options: {
            port: 0,
            hostname: '<%= hosts.runtime%>'
        },
        server: {
            options: {
                open: true,
                hostname: '<%= hosts.fqdn%>',
                livereload: 0,
                middleware: function (connect) {
                    var cwd = grunt.config.get('config.paths.cwd');

                    return [
                        require('grunt-connect-proxy/lib/utils').proxyRequest,
                        connect().use('/lib', serveStatic(
                            path.resolve(cwd, './bower_components'))),
                        connect().use('/lib', serveStatic(
                            path.resolve(cwd, grunt.file.readJSON('.bowerrc').directory || './lib'))),
                        connect().use('/', serveStatic(
                            path.resolve(cwd, grunt.config.get('config.paths.run')))),
                        connect().use('/', serveStatic(
                            path.resolve(grunt.config.get('config.paths.src')))),
                        connect().use('/mocks', serveStatic(
                            path.resolve(cwd, grunt.config.get('config.paths.test'), './mocks')))
                    ];
                }
            }
        },
        e2e: {
            options: {
                hostname: '<%= hosts.fqdn%>',
                open: false,
                middleware: function (connect) {
                    var cwd = grunt.config.get('config.paths.cwd');

                    return [
                        connect().use('/lib', serveStatic(
                            path.resolve(cwd, './bower_components'))),
                        connect().use('/lib', serveStatic(
                            path.resolve(cwd, grunt.file.readJSON('.bowerrc').directory || './lib'))),
                        connect().use('/app', serveStatic(
                            path.resolve(cwd, grunt.template.process('<%= paths.tmp %>/instrumented/<%= paths.scripts %>')))),
                        connect().use('/', serveStatic(
                            path.resolve(cwd, grunt.config.get('paths.run')))),
                        connect().use('/', serveStatic(
                            path.resolve(cwd, grunt.config.get('paths.src')))),
                        connect().use('/', serveStatic(
                            path.resolve(cwd, grunt.template.process('<%= paths.test%>/protractor')))),
                        connect().use('/mocks', serveStatic(
                            path.resolve(cwd, grunt.template.process('<%= paths.test%>/mocks'))))
                    ];
                }
            }
        },

        test: {
            options: {
                open: false,
                middleware: function (connect) {
                    var config = grunt.config.get('config');
                    var cwd = config.paths.cwd;

                    return [
                        connect().use('/lib', connect.static(
                            path.resolve(cwd, config.paths.lib))),
                        connect().use('/' + config.paths.appSrcDirectory, connect.static(
                            path.resolve(cwd, config.paths.instrumented + '/' + config.paths.src + '/' + config.paths.appSrcDirectory))),
                        connect().use('/', connect.static(
                            path.resolve(cwd, config.paths.src))),
                        connect().use('/', connect.static(
                            path.resolve(cwd, config.paths.test + '/protractor'))),
                        connect().use('/', connect.static(
                            path.resolve(cwd, grunt.config.get('tgBuild.paths.buildDir')))), // Locally built CSS
                        connect().use('/mocks', connect.static(
                            path.resolve(cwd, config.paths.test + '/mocks'))),
                        connect().use('/dist', connect.static(
                            path.resolve(cwd, config.paths.dist)))
                    ];
                }
            }
        }
    }
};
