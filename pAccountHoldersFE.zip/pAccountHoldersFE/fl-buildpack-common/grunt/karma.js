'use strict';

/** Karma task configuration. */
module.exports = function () {
    return {
        options: {
            singleRun: true,
            reporters: ['progress', 'coverage', 'junit']
        },
        unit: {
            // Generated in grunt/karmaConfig using grunt/setKarmaFiles
            // and saved with grunt/saveKarmaConfig
            configFile: '<%=config.paths.config%>/karma.conf.js'
        }
    };
};;
