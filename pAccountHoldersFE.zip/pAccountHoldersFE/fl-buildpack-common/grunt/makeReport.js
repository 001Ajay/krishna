'use strict';

module.exports = {
    src: '<%= paths.coverage %>/protractor/*.json',
    options: {
        type: 'lcov',
        dir: '<%= paths.coverage %>/protractor',
        print: 'detail'
    }
};
