var grunt = require('grunt');
var path = require('path');
var basePath = path.resolve();
var allScriptsTimeout = 60000;
// From fl-buildpack

exports.config = {
    allScriptsTimeout: allScriptsTimeout,
    framework: 'jasmine2',
    keepAlive: true,

    multiCapabilities: [
        {
            'browserName': 'chrome',
            'chromeOptions': {

                args: [
                    'test-type', // get rid of the ignore cert warning
                    '--no-sandbox' // Disable chrome sandboxing to improve performance.
                ]
            },
            shardTestFiles: true,
            maxInstances: 4
        }
    ],

    params: {
        environment: 'BUILD',
        $startPage$
    },

    // Element will be replaced by rootelement specified in build configuration.
    $rootElement$

    onPrepare: function() {
        browser.params.dependencyPath = path.join(exports.config.configDir, '..') + '/lib';
        mkdirp = require('mkdirp');

        var jasmineReporters = require('jasmine-reporters');

        return browser.getProcessedConfig().then(function (config) {
            // Store the name of the browser that's currently being used.
            var browserName = config.capabilities.browserName;

            var directory = path.join(exports.config.configDir, '..') + '/reports/protractor/' + browserName;
            mkdirp(directory, function (err) {
                if (err) {
                    throw new Error('Could not create directory ' + directory);
                }
            });

            var jasmineEnv = jasmine.getEnv();
            jasmineEnv.defaultTimeoutInterval = allScriptsTimeout;
            jasmineEnv.addReporter(new jasmineReporters.JUnitXmlReporter({
                savePath: directory,
                consolidateAll: false,
                consolidate: false
            }));

            browser.driver.manage().window().maximize();
            browser.manage().timeouts().setScriptTimeout(allScriptsTimeout);
        });

    },
    onCleanUp: function () {
    },
    beforeLaunch: function () {
    },
    afterLaunch: function () {
        var reportsBaseDir = path.join(exports.config.configDir, '..') + '/reports/protractor/';
        grunt.file.expand({filter: 'isDirectory', cwd: reportsBaseDir}, '*').forEach(function (dir) {
            var mergedAndUpdatedContent = '<?xml version="1.0"?>\n<testsuites>\n';
            var errors = 0;
            var tests = 0;
            var failures = 0;
            var time = 0;
            var testcases = '';

            grunt.file.expand(reportsBaseDir + dir + '/*').forEach(function (file) {
                var content = grunt.file.read(file);
                var testsuites = content.match(/\<testsuite\s.*\>/g);

                for (var i = 0; i < testsuites.length; i++) {
                    var match = /time="([\d,\.]*)".*errors="(\d*)".*tests="(\d*)".*failures="(\d*)"./g.exec(testsuites[i]);
                    time = time + Number(match[1]);
                    errors = errors + Number(match[2]);
                    tests = tests + Number(match[3]);
                    failures = failures + Number(match[4]);
                }

                content = content.replace(/\<\?xml.+\?\>/gm, '');
                content = content.replace(/\<testsuites>/gm, '');
                content = content.replace(/\<testsuite.*>/gm, '');
                content = content.replace(/\<\/testsuite>/gm, '');
                content = content.replace(/\<\/testsuites>/gm, '');
                testcases = testcases.concat(content);
            });

            var testsuite = '<testsuite ' +
                'name="' + dir + '" ' +
                'package="protractor" ' +
                'tests="' + tests + '" ' +
                'errors="' + errors + '" ' +
                'failures="' + failures + '" ' +
                'time="' + time + '">';
            mergedAndUpdatedContent = mergedAndUpdatedContent.concat(testsuite);
            mergedAndUpdatedContent = mergedAndUpdatedContent.concat(testcases);
            mergedAndUpdatedContent = mergedAndUpdatedContent.concat('</testsuite>');
            mergedAndUpdatedContent = mergedAndUpdatedContent.concat('</testsuites>');
            mergedAndUpdatedContent = mergedAndUpdatedContent.replace(/^\s*[\r\n]/gm, "");
            grunt.file.write(reportsBaseDir + '/protractor-' + dir + '.xml', mergedAndUpdatedContent);
        });
    },
    jasmineNodeOpts: {
        showColors: false,
        defaultTimeoutInterval: allScriptsTimeout
    }
};
