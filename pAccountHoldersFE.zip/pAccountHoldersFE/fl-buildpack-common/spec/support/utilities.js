'use strict';

var ncp = require('ncp').ncp;
var async = require('async');
var mkdirp = require('mkdirp');
var path = require('path');
var rimraf = require('rimraf'); // tool to recursively delete a directory

module.exports = {

    /**
     * Copies all the mock files to tmp/testName to assure it works on clean
     * mock-files, and won't be bothered by other tests runnin simultaneously
     *
     * @param {string} suite The name of the suite you're testing
     * @param {function} doneWithMocksToTmp Callback to be called when done
     */
    copyMocksToTmp: function(suite, doneWithMocksToTmp){
        var tmpMocksFolder = path.join('.tmp', suite, 'mocks');
        async.series([

            // Delete the old mocks folder in tmp
            done => rimraf(tmpMocksFolder, done),

            // Make sure the folder exists
            done => mkdirp(tmpMocksFolder, done),

            done => ncp(path.join('spec','mocks'), tmpMocksFolder, done)

        ], function(err, result) {
            doneWithMocksToTmp(err);
        });
    }

};
