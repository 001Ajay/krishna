'use strict';

var grunt = require('grunt');
var path = require('path');
var fs = require('fs');
var async = require('async');
var clone = require('clone');
var mkdirp = require('mkdirp');
var ncp = require('ncp');
var rimraf = require('rimraf');

// TODO Can we make this into a separate NPM module?
var testUtilities = require('../../lib/testUtilities');

require('../../lib/require-all-grunt')(grunt);

describe('BundleProtractorReport', function() {


    // Include the librarySet and initialize it
    var simplifyFlakyReport = grunt.config('simplifyFlakyReport');

    // Backup the original coverage dir variable in a global variable
    var coverageDirBackup;
    var tmp = grunt.config('paths.tmp');

    // each test has its own mock data
    // when running the test, we change the coverage config flag to use that mock
    // data instead
    // before all tests are run, we copy all mock data to the tmp folder, to
    // assure that we have a fresh start
    beforeAll(function(done){

        // Backup the coverageDir variable to restore it later
        coverageDirBackup = grunt.config('paths.coverage');

        async.series([

            // Create temp, ignore the eror
            done => mkdirp(tmp, done),

            // Delete mocks. Ignore err (when N/A)
            done => rimraf(path.join(tmp, 'mocks'), err => done()),

            // Create a new mocks directory in tmp
            done => mkdirp(path.join(tmp, 'mocks'), done),

            // Copy the mocks to the tmp directory
            done => ncp(
                path.join('.','spec','mocks','reports'),
                path.join(tmp, 'mocks','simplifyFlakyReport'), done),

            // Copy the mocks to the tmp directory
            done => ncp(
                path.join('.','spec','mocks','bundleProtractorSuccess'),
                path.join(tmp, 'mocks', 'bundleProtractorSuccess'), done)

        ], done);
    });

    afterAll(function(){

        // Put back the original coverageDir variable
        grunt.config('paths.coverage', coverageDirBackup);
    });

    describe('simplifyFlakyReport', () => {
        it('should be registered as a grunt task', () => {
            expect(grunt.task.exists('simplifyFlakyReport')).toBeTruthy();
        });

        it('should return an ascii table without errors', done => {

            // Temporarily overwrite the coverage dir to have a different
            // readout file
            grunt.config.set('paths.coverage',
                path.join(grunt.config('paths.tmp'),
                'mocks','simplifyFlakyReport', 'protractorCoverage'));

            simplifyFlakyReport.simplifyFlakyReport((err, table) => {
                expect(err).toBeFalsy();
                expect(typeof table).toBe('string');

                // Fails 3 times then 1 time
                expect(table.match(/should fail anyway[^\d]+3/)).toBeDefined();
                expect(table.match(/should display the right repository URL[^\d]+1/)).toBeDefined();
                console.log('table', table);
                done();
            });
        });
    });

    //xdescribe('loadBundledReportFile', _ => {
    //    it('should parse a json and return it without error', done => {
    //
    //    });
    //});
    //
    //xdescribe('flattenTestCases', _ => {
    //    it('should convert a complex testsuite object to a simple object', done => { });
    //});
    //
    //xdescribe('deduplicateTestCases', _ => {
    //    it('should remove duplicates', done => { });
    //    it('should count the times a test has failed', done => { });
    //});
    //
    //xdescribe('writeTestCasesToFile', _ => {
    //    it('should write the test cases to the file', done => { });
    //});
    //
    //xdescribe('reportTestcasesToTable', _ => {
    //    // I don't want to go too much into detail on what the table exactly
    //    // looks like. As long as it doesn't create any errors I'm happy
    //    it('shouldnt trigger an exception', done => {});
    //});

});
