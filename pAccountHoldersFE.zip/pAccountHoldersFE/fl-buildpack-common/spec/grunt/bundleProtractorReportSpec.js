'use strict';

var grunt = require('grunt');
var path = require('path');
var fs = require('fs');
var async = require('async');
var clone = require('clone');
var mkdirp = require('mkdirp');
var ncp = require('ncp');
var rimraf = require('rimraf');

// Can we make this into a separate NPM module?
var testUtilities = require('../../lib/testUtilities');

require('../../lib/require-all-grunt')(grunt);

describe('BundleProtractorReport', function() {

    // Include the librarySet and initialize it
    var bundleProtractorReport =
        grunt.config('bundleProtractorReport').bundleProtractorReport;

    // Backup the original coverage dir variable in a global variable
    var coverageDirBackup;
    var tmp = grunt.config('paths.tmp');
    // each test has its own mock data
    // when running the test, we change the coverage config flag to use that mock
    // data instead
    // before all tests are run, we copy all mock data to the tmp folder, to
    // assure that we have a fresh start
    beforeAll(function(done){

        // Backup the coverageDir variable to restore it later
        coverageDirBackup = grunt.config('paths.coverage');

        async.series([

            // Create temp, ignore the eror
            done => mkdirp(tmp, done),

            // Delete mocks. Ignore err (when N/A)
            done => rimraf(path.join(tmp, 'mocks'), err => done()),

            // Create a new mocks directory in tmp
            done => mkdirp(path.join(tmp, 'mocks'), done),

            // Copy the mocks to the tmp directory
            done => ncp(
                path.join('.','spec','mocks','reports'),
                path.join(tmp, 'mocks'), done),

            // Copy the mocks to the tmp directory
            done => ncp(
                path.join('.','spec','mocks','bundleProtractorSuccess'),
                path.join(tmp, 'mocks', 'bundleProtractorSuccess'), done)

        ], done);
    });

    afterAll(function(){

        // Put back the original coverageDir variable
        grunt.config('paths.coverage', coverageDirBackup);
    });

    describe('successful bundle execution', function(){
        it('should generate a json file, containing an array ' +
            'with the xml as a JSON object',
            done => {
                grunt.config.set('paths.coverage',
                    path.join(grunt.config('paths.tmp'),
                    'mocks','bundleProtractorSuccess', 'protractorCoverage'));

                bundleProtractorReport(err => {
                    // no error that bundle file does not exist
                    expect(err).toBeFalsy();

                    testUtilities.equalFiles(
                        // Generated
                        path.join(grunt.config('paths.coverage'),
                            'bundledProtractorReport.json'),

                        // Expected
                        path.join(grunt.config('paths.coverage'),
                            'expectedBundledProtractorReport.json'),

                        function(err, reports) {
                            expect(err).toBeFalsy();
                            expect(reports.generated).toEqual(reports.expected);
                            done();
                        }

                    );
                })
            });

        //it('should give an error when it cant parse the json', done => { });
        //it('should give an error when it cant parse the xml', done => { });
    });

});
