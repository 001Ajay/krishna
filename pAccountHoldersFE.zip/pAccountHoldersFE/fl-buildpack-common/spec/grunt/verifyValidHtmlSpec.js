'use strict';

var grunt = require('grunt');
var path = require('path');
var testUtils = require('../support/utilities');

describe('verifyValidHtml', () => {

    var testBase = '.tmp/verifyValidHtml/mocks/verifyValidHtml/';

    beforeAll(done => {
        testUtils.copyMocksToTmp('verifyValidHtml', done);
    });

    it('should report a file to false when having an extra quote mark', doneWithIt => {
        verifyHtml('extraQuote', function(err, htmlReport) {
            expect(err).toBeFalsy();

            expect(htmlReport.fileContents).toEqual({
                'app/extraQuote.html':
                    false
            });
            doneWithIt();
        });
    });

    it('should report one file to true and one file to false', function(doneWithIt){
        verifyHtml('validAndInvalid', function(err, htmlReport) {
            expect(err).toBeFalsy();

            expect(htmlReport.fileContents).toEqual({
                'app/invalid.html':
                    false
            });
            doneWithIt();
        });
    });

    /**
     * Runs the verifyValidHtml task on a directory based in
     * mocks/verifyValidHtml/%dir%. Whereas %dir% will be changed
     * for each spec
     *
     * @param {string} dir The name of the spec where your mock files are defined
     * @param {function} done Callback with err, data
     */
    function verifyHtml(dir, done) {
       var testDir = testBase + dir;

       grunt.util.spawn({
           cmd: './node_modules/.bin/grunt',
           args: [
               'setConfigVariable:config.paths.reports:.tmp/reports/',
               'setConfigVariable:config.paths.src:dummyBower/src/',
               'verifyValidHtml',
               '--cwd=' + testDir,
               '--no-color',
               '--stack',
               '--verbose'
           ]
       }, (err, result) => {
           if (err) {
               return done(err, result.stdout);
           }
           var htmlReportPath = path.join('.tmp','reports','htmlReport.json');
           try {
               done(null, {
                   fileContents: grunt.file.readJSON(htmlReportPath)
               });
           } catch(e) {
               done(e);
           }
       });
   }

});

