'use strict';
var grunt = require('grunt');
var path = require('path');
var fs = require('fs');
var clone = require('clone');
var jasmineHttpServerSpy = require('jasmine-http-server-spy');

require('../../lib/require-all-grunt')(grunt);

describe('LibrarySet', function() {

    // Include the librarySet and initialize it
    var librarySet = grunt.config.get('librarySet');
    var config = grunt.config.get('config');
    var bowerTestConfig;

    console.log('grunt config hosts', grunt.config.get('config.hosts'));

    // Assure the tmp directory exists
    if(fs.existsSync(config.paths.tmp) === false) {
        fs.mkdirSync(config.paths.tmp);
    }

    beforeAll(function(done){

        // Flip the config to the test server
        grunt.config.merge({
            hosts: { kirkAddress: 'http://localhost:8083/kirk' }
        });

        // Fake the HTTP server before all test
        this.httpSpy = jasmineHttpServerSpy.createSpyObj('mockServer', [
            {
                method: 'get',
                url: '/kirk/librarysets',
                handlerName: 'getAllLibrarySets'
            },
            {
                method: 'get',
                url: '/kirk/modules/fooBar/library-sets/stable',
                handlerName: 'resolveLibrarySetNameByStableUnstable'
            },
            {
                method: 'get',
                url: '/kirk/librarysets/foo',
                handlerName: 'getLibrarySet'
            }
        ]);

        this.httpSpy.server.start(8083, function(){
            grunt.log.writeln('webserver created');
            done();
        });
    });

    // TODO remove bower tests
    // @[RK] Whut?? What do you mean, is this a legacy comment? What bower
    // tests?

    // Mock the bower.json file so we don't accidentily modify or destroy the
    // bower config when the test fails
    // And make the config accesible by other functions for comparison
    // testing
    beforeEach(function(done){
        bowerTestConfig = {
            name: 'fooBar',
            version: '0.1.0',
            dependencies: {
                'richard': 4.2
            },
            devDependencies: {
                'erik': 3.0,
                'henk': 3.0
            },
            resolutions: {
                jquery: '1.10.2'
            }
        };

        // Make it into a JSON to write it away
        var fakeBowerFile = JSON.stringify(bowerTestConfig, null, 2);
        var fakeBowerFileName = path.join(config.paths.tmp, 'bower.json')

        // Read from the tmp folder instead of the base, we reset this
        // after all other tests
        grunt.config.set('config.paths.bower', fakeBowerFileName);

        // Write the fake bower to the tmp folder
        fs.writeFile(fakeBowerFileName, fakeBowerFile, done);
    });

    // Close the server afterwards
    afterAll(function(done){
        // Set the base path config back to it's original value
        config.paths.base = config.paths.baseBackup;

        this.httpSpy.server.stop(done);
    });

    // Reset the called-status after each test
    afterEach(function(){
        this.httpSpy.getAllLibrarySets.calls.reset();
    });

    it('should have the required config variables available', function () {
        expect(grunt.config.get('hosts')).toBeDefined();
        expect(grunt.config.get('hosts').kirkAddress).toBeDefined();
    });

    // resolveLibrarySetNameByStableUnstable
    describe('resolveLibrarySetNameByStableUnstable', function () {

        it('Should trigger an error when having an invalid stableUnstable type', function(done) {
            librarySet.resolveLibrarySetNameByStableUnstable('master', function(err){

                // Err should be triggered
                expect(err).toBeTruthy();

                // Validate that the names are the same
                expect(err).toContain('stableUnstable type');
                done();
            });
        });

        it('Should return a librarySetName based on the bower.json configured moduleName and stableUnstable', function(done) {
            // Define what the server _should_ return
            this.httpSpy.resolveLibrarySetNameByStableUnstable.and.returnValue({
                statusCode: 200,
                body: 'foobarImALibrarySet'
            });

            // Make a reference to this closure
            var self = this;

            librarySet.resolveLibrarySetNameByStableUnstable('stable', function(err, librarySetName){

                // Err shouldn't be triggered
                expect(err).toBe(null);

                // Validate that the names are the same
                expect(librarySetName).toBe('foobarImALibrarySet');

                // Assert mock server has been called as expected
                expect(self.httpSpy.resolveLibrarySetNameByStableUnstable).toHaveBeenCalled();
                done();
            });
        });

        it('Should forward the error when getBowerConfig triggers an error', function(done) {
            // Define what the server _should_ return
            this.httpSpy.resolveLibrarySetNameByStableUnstable.and.returnValue({
                statusCode: 200,
                body: 'foobarImALibrarySet'
            });

            // Change the config so it causes a writing error
            var originalBowerPath = grunt.config.get('config').paths.bower;
            grunt.config.set('config.paths.bower',
                             '/does-not-exist-on-purpose/foo'+Math.random());

            // Make sure it gets back to normal afterwards
            afterEach(function(){
                grunt.config.set('config.paths.bower', originalBowerPath);
            });

            librarySet.resolveLibrarySetNameByStableUnstable('stable', function(err){

                // Err should be triggered
                expect(err).toBeTruthy();

                // Validate that the error is about the bower file
                expect(err).toContain('Bower file does not exist');

                done();
            });
        });

        // Should forward the error when server triggers an error
        it('Should forward the error when getBowerConfig triggers an error', function(done) {
            // Define what the server _should_ return
            this.httpSpy.resolveLibrarySetNameByStableUnstable.and.returnValue({
                statusCode: 404,
                body: 'Youve reached beyond the end of the universe.  Congratulations, there is nothing here to find.'
            });

            librarySet.resolveLibrarySetNameByStableUnstable('stable', function(err){

                // Err shouldn't be triggered
                expect(err).toBeTruthy();

                // Validate that the names are the same
                expect(err).toContain('404');

                done();
            });
        });
    });


    // getAllLibrarySetNames
    describe('getAllLibrarySetNames', function() {

        // Regular request should work
        it('Should return an array of all available librarySets names', function(done) {
            // Define what the server _should_ return
            this.httpSpy.getAllLibrarySets.and.returnValue({
                statusCode: 200,
                body: [
                    { name: 'angular1.4', libraries: ['angular1.4', 'jquery'] },
                    { name: 'angular1.5', libraries: ['angular1.5', 'jquery'] },
                ]
            });

            // Make a reference to this closure
            var self = this;

            librarySet.getAllLibrarySetNames(function(err, names){

                // Err shouldn't be triggered
                expect(err).toBe(null);

                // The server should have triggered a valid response
                expect(err).not.toBe('Output from the server is not json');

                // Validate that the names are the same
                expect(names).toEqual(['angular1.4', 'angular1.5']);

                // Assert mock server has been called as expected
                expect(self.httpSpy.getAllLibrarySets).toHaveBeenCalled();
                done();
            });
        });

        // Handle 404
        it('Should handle an HTTP error properly', function(done) {
            // Define what the server _should_ return
            this.httpSpy.getAllLibrarySets.and.returnValue({
                statusCode: 404,
                body: 'Cannot find the droids you are looking for'
            });

            // Make a reference to this closure
            var self = this;

            librarySet.getAllLibrarySetNames(function(err, names){
                expect(err).not.toBe(null);
                expect(err).toMatch(/404/);
                expect(names).not.toBeDefined();

                // Assert mock server has been called as expected
                expect(self.httpSpy.getAllLibrarySets).toHaveBeenCalled();

                // Async done
                done();
            });
        });

        // Handle invalid JSON
        it('Should handle invalid JSON responses', function(done) {
            // Define what the server _should_ return
            this.httpSpy.getAllLibrarySets.and.returnValue({
                statusCode: 200,
                body: 'This isn\'t JSON. And it will never be JSON!!'
            });

            // Make a reference to this closure
            var self = this;

            librarySet.getAllLibrarySetNames(function(err, names){

                expect(err).not.toBe(null);
                expect(err).toMatch(/unexpected token/i);

                expect(names).not.toBeDefined();

                // Assert mock server has been called as expected
                expect(self.httpSpy.getAllLibrarySets).toHaveBeenCalled();

                // Async done
                done();
            });
        });
    });

    // getLibrarySet
    describe('getLibrarySet', function(){

        // Valid response
        it('Should return a let of dependencies in bower formatting',function(done){

            // Make a valid server response
            this.httpSpy.getLibrarySet.and.returnValue({
                statusCode: 200,
                body: {
                    name: 'foo',
                    libraries: [
                        { version: 1.4, name: 'angular', type: 'RUNTIME' },
                        null,
                        { version: 1.4, name: 'angular-mocks', type: 'DEV' }
                    ]
                }
            });

            // Make a reference to self to test whether the server was called
            var self = this;

            librarySet.getLibrarySet('foo', function(err, librarySet) {
                expect(self.httpSpy.getLibrarySet).toHaveBeenCalled();
                expect(err).toBeFalsy();
                expect(librarySet).toBeDefined();
                expect(librarySet).toEqual({
                    dependencies: { 'angular': 1.4 },
                    devDependencies: { 'angular-mocks': 1.4 }
                });
                done();
            });
        });

        // Test the 404
        it('Should catch a 404 error',function(done){

            // Make a 404 server error
            this.httpSpy.getLibrarySet.and.returnValue({
                statusCode: 404,
                body: 'Aaaaand it\'s gone..'
            });

            librarySet.getLibrarySet('foo', function(err, librarySet) {
                expect(librarySet).not.toBeDefined();
                expect(err).not.toBeUndefined();
                expect(err).toMatch(/404/);
                done();
            });
        });

        // Test the invalid json
        it('Should catch an invalid response',function(done){

            // Make an invalid json response
            this.httpSpy.getLibrarySet.and.returnValue({
                statusCode: 200,
                body: 'Im a String. James String.'
            });

            librarySet.getLibrarySet('foo', function(err, librarySet) {

                expect(librarySet).not.toBeDefined();
                expect(err).not.toBeUndefined();
                expect(err).toMatch(/unexpected token/i);

                done();
            });
        });

        // Should resolve librarySet by stableUnstable type and bower configured
        // moduleName
        it('Should resolve librarySet by stableUnstable type', function(done) {
            // Define what the server _should_ return
            this.httpSpy.resolveLibrarySetNameByStableUnstable.and.returnValue({
                statusCode: 200,
                body: 'foo'
            });
            this.httpSpy.getLibrarySet.and.returnValue({
                statusCode: 200,
                body: {
                    name: 'foo',
                    libraries: [
                        { version: 1.4, name: 'angular', type: 'RUNTIME' },
                        null,
                        { version: 1.4, name: 'angular-mocks', type: 'DEV' }
                    ]
                }
            });

            // Make a reference to this closure
            var self = this;

            librarySet.getLibrarySet('stable', function(err, librarySet) {
                // Test HTTP servers to be called
                expect(self.httpSpy.getLibrarySet).toHaveBeenCalled();

                expect(err).toBeFalsy();
                expect(librarySet).toBeDefined();
                expect(librarySet).toEqual({
                    dependencies: { 'angular': 1.4 },
                    devDependencies: { 'angular-mocks': 1.4 }
                });
                done();
            });
        });

        // Should forward the error when resolving librarySet by stableUnstable type
        it('Should forward the error when resolving librarySet by stableUnstable type', function(done) {
            // Define what the server _should_ return
            this.httpSpy.resolveLibrarySetNameByStableUnstable.and.returnValue({
                statusCode: 404,
                body: 'The server spawned an unexpected 404, OHSHIT'
            });
            this.httpSpy.getLibrarySet.and.returnValue({
                statusCode: 200,
                body: {
                    name: 'foo',
                    libraries: [
                        { version: 1.4, name: 'angular', type: 'RUNTIME' },
                        null,
                        { version: 1.4, name: 'angular-mocks', type: 'DEV' }
                    ]
                }
            });

            // Make a reference to this closure
            var self = this;

            librarySet.getLibrarySet('stable', function(err, librarySet) {
                // Test HTTP servers to be called
                expect(self.httpSpy.getLibrarySet).toHaveBeenCalled();

                expect(librarySet).not.toBeDefined();
                expect(err).not.toBeUndefined();
                expect(err).toMatch(/404/);
                done();
            });
        });
    });

    // setLibrarySet
    describe('setLibrarySet', function () {

        it('should be able to set a library set to bower based on its name', function(done) {

            // Configure the server to give a valid response
            this.httpSpy.getLibrarySet.and.returnValue({
                statusCode: 200,
                body: {
                    name: 'foo',
                    libraries: [
                        { version: 1.4, name: 'angular', type: 'RUNTIME' },
                        null,
                        { version: 1.4, name: 'angular-mocks', type: 'DEV' }
                    ]
                }
            });


            // Call the function
            librarySet.setLibrarySet('foo', function(err) {

                expect(err).toBeFalsy();

                // Check the bower file
                fs.readFile(grunt.config.get('config').paths.bower, function(err, file) {

                    // Parse the JSON
                    var parsedJSON;
                    var jsonError = false;
                    try {
                        parsedJSON = JSON.parse(file.toString());
                    }
                    catch(e){
                        jsonError = e;
                    }

                    // Trigger error when written JSON is invalid
                    expect(jsonError).toBe(false);

                    // Configure the bower file
                    var bowerClone = clone(bowerTestConfig);
                    bowerClone.dependencies.angular = 1.4;
                    bowerClone.devDependencies['angular-mocks'] = 1.4;

                    // Validate the file to be the corectly modified
                    expect(parsedJSON).not.toBeUndefined();
                    expect(parsedJSON).toEqual(bowerClone);

                    // The bower repo name shouldn't have been changed
                    expect(parsedJSON.name).toBe('fooBar');

                    // Finished with all tests
                    done();
                });
            });
        });

        // Proper fail when libraryName does not exist
        it('should fail when libraryName does not exist', function(done) {

            // Configure the server to give a valid response
            this.httpSpy.getLibrarySet.and.returnValue({
                statusCode: 404,
                body: 'Oops! The library does not exist'
            });

            // Call the function
            librarySet.setLibrarySet('foo', function(err, success) {
                expect(err).toBeTruthy();
                expect(err).toMatch(/404/);
                expect(success).toBeFalsy();

                // Finished with all tests
                done();
            });
        });

        //// Proper fail when server gives invalid JSON response
        // Proper fail when libraryName does not exist
        it('should fail when libraryName does not exist', function(done) {

            // Configure the server to give a valid response
            this.httpSpy.getLibrarySet.and.returnValue({
                statusCode: 200,
                body: 'And not a single JSON was given during that day..'
            });

            // Call the function
            librarySet.setLibrarySet('foo', function(err, success) {
                expect(err).toBeTruthy();
                expect(err).toMatch(/unexpected token/i);
                expect(success).toBeFalsy();

                // Finished with all the tests
                done();
            });
        });
    });

});
