'use strict';

var grunt = require('grunt');
var path = require('path');
var fs = require('fs');
var clone = require('clone');

require('../../lib/require-all-grunt')(grunt);

describe('Bower', function() {

    // Include the librarySet and initialize it
    var bower = grunt.config('bower');
    var config = grunt.config('config');
    var bowerTestConfig;

    // Assure the tmp directory exists
    if(fs.existsSync(config.paths.tmp) === false) {
        fs.mkdirSync(config.paths.tmp);
    }

    // Mock the bower.json file so we don't accidentily modify or destroy the
    // bower config when the test fails
    // And make the config accesible by other functions for comparison
    // testing
    beforeEach(function(done){
        bowerTestConfig = {
            name: 'fooBar',
            version: '0.1.0',
            dependencies: {
                'richard': 4.2
            },
            devDependencies: {
                'erik': 3.0,
                'henk': 3.0
            },
            resolutions: {
                jquery: '1.10.2'
            }
        };

        // Make it into a JSON to write it away
        var fakeBowerFile = JSON.stringify(bowerTestConfig, null, 2);
        var fakeBowerFileName = path.join(config.paths.tmp, 'bower.json')

        // Read from the tmp folder instead of the base, we reset this
        // after all other tests
        grunt.config.set('config.paths.bower', fakeBowerFileName);

        // Write the fake bower to the tmp folder
        fs.writeFile(fakeBowerFileName, fakeBowerFile, done);
    });

    // Close the server afterwards
    afterAll(function(){
        // Set the base path config back to it's original value
        config.paths.base = config.paths.baseBackup;
    });

    // mergeBowerDependencies
    describe('Merge bower configurations', function () {
        it('Add dependencies (no merging)', function(){
            var original = {
                dependencies: { a : 1.0 }
            };
            var additional = {
                dependencies: { b : 1.0 },
                devDependencies : { c : 4.2 }
            };
            var expected = {
                dependencies: { a: 1.0, b: 1.0 },
                devDependencies: { c: 4.2 }
            };
            expect(
                bower.mergeDependencies(original, additional)
            ).toEqual(expected);
        });

        it('Should overwrite all dependencies, relentles of their versioning number',
            function () {
            var original = {
                dependencies: { a : 1.0 },
                devDependencies: { c : '3000' }
            };
            var additional = {
                dependencies: { a : 0.1, b : 1.0 },
                devDependencies : { c : 4.2 }
            };
            var expected = {
                dependencies: { a: 0.1, b: 1.0 },
                devDependencies: { c: 4.2 }
            };
            expect(
                bower.mergeDependencies(original, additional)
            ).toEqual(expected);
        });
    });

    // convertKirkToBowerFormat
    describe('convert kirk to bower', function () {
        var kirkFormat = {
            name: 'KITT',
            libraries: [ { version: '1.4', name: 'angular', type: 'RUNTIME' },
            null,
            { version: '1.4', name: 'angular-mocks', type: 'DEV' }]
        };
        var bowerFormat = {
            dependencies: { 'angular': '1.4' },
            devDependencies: { 'angular-mocks' : '1.4' }
        };

        it('Should be able to convert the format received from Kirk to bower', function () {
            expect(
                bower.convertKirkToBowerFormat(kirkFormat)
            ).toEqual(bowerFormat);
        });
    });

    // getBowerConfig
    describe('getBowerConfig', function() {

        // Response should be identical to previously defined file
        it('should return the same bower config as specified', function (done) {
            bower.getConfig(function(err, bowerConfig){

                expect(err).toBeFalsy();
                expect(bowerConfig).not.toBeUndefined();
                expect(bowerConfig).toEqual(bowerTestConfig);

                // Should have the moduleName
                expect(bowerConfig.name).not.toBeUndefined();
                expect(bowerConfig.name).toBe('fooBar');

                done();
            });
        });

        // Should trigger an error when the bower.json does not exist
        it('should trigger an error when it cant acces the bower file', function(done){

            // Change the config so it causes a writing error
            var originalBowerPath = grunt.config.get('config').paths.bower;
            grunt.config.set('config.paths.bower',
                             '/does-not-exist-on-purpose/foo' + Math.random());

            // Make sure it gets back to normal afterwards
            afterEach(function(){
                grunt.config.set('config.paths.bower', originalBowerPath);
            });

            grunt.log.writeln('Bower config in testing bower file that does not exist:',
                        grunt.config.get('config').paths.bower);

            bower.getConfig(function(err) {
                expect(err).toBeTruthy();
                expect(err).toMatch(/Bower file does not exist/i);
                done();
            });
        });
    });

    // setConfig
    describe('setConfig', function(){

        it('should write away the file in valid json', function(done) {
            var bowerClone = clone(bowerTestConfig);

            // Make sure the test file is different than the original file so we
            // can verify that it was actually changed
            bowerClone.dependencies.remco = 3.0;

            bower.setConfig(bowerClone, function(err) {
                expect(err).toBeFalsy();

                fs.readFile(grunt.config.get('config').paths.bower, function(err, data) {
                    expect(err).toBeFalsy();

                    var parsedJson = JSON.parse(data.toString());
                    expect(parsedJson).toEqual(bowerClone);
                    done();
                });
            });
        });

        it('should trigger an error when it cant write away the file', function(done){

            // Change the config so it causes a writing error
            var originalBowerPath = grunt.config.get('config').paths.bower;
            grunt.config.set('config.paths.bower',
                             '/does-not-exist-on-purpose/foo'+Math.random());

            // Make sure it gets back to normal afterwards
            afterEach(function(){
                grunt.config.set('config.paths.bower', originalBowerPath);
            });

            bower.setConfig(bowerTestConfig, function(err) {
                expect(err).toBeTruthy();
                expect(err).toMatch(/cannot write away bower file/i);
                done();
            });
        });
    });


});
