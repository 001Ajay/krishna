'use strict';

var grunt = require('grunt');
var fs = require('fs');
var path = require('path');

var jasmineHttpServerSpy = require('jasmine-http-server-spy');

require('../../lib/require-all-grunt')(grunt);

describe('Portal', function () {

    // Include the portal module and initialize it
    var portal = grunt.config.get('portalLibrarySet');
    var librarySet = grunt.config.get('librarySet');
    var config = grunt.config.get('config');
    var bowerTestConfig;

    beforeAll(function(done){

        // Assure the tmp directory exists
        if(fs.existsSync(grunt.config('config').paths.tmp) === false) {
            fs.mkdirSync(grunt.config('config').paths.tmp);
        }

        // Flip the config to the test server
        grunt.config.merge({
            hosts: { kirkAddress: 'http://localhost:8083/kirk' }
        });

        // Fake the HTTP server before all test
        this.httpSpy = jasmineHttpServerSpy.createSpyObj('mockServer', [
            {
                method: 'get',
                url: '/kirk/librarysets',
                handlerName: 'getAllLibrarySets'
            },
            {
                method: 'get',
                url: '/kirk/modules/fooBar/library-sets/stable',
                handlerName: 'resolveLibrarySetNameByStableUnstable'
            },
            {
                method: 'get',
                url: '/kirk/portals/potahl/Development/libraryset',
                handlerName: 'resolveLibrarySetNameByPortal'
            },
            {
                method: 'get',
                url: '/kirk/portals',
                handlerName: 'getAllPortals'
            },
            {
                method: 'get',
                url: '/kirk/librarysets/foo',
                handlerName: 'getLibrarySet'
            }
        ]);
        this.httpSpy.server.start(8083, function(){
            grunt.log.writeln('webserver created');
            done();
        });
    });

    // Mock the bower.json file so we don't accidentily modify or destroy the
    // bower config when the test fails
    // And make the config accesible by other functions for comparison
    // testing
    beforeEach(function(done){
        bowerTestConfig = {
            name: 'fooBar',
            version: '0.1.0',
            dependencies: {
                'richard': 4.2
            },
            devDependencies: {
                'erik': 3.0,
                'henk': 3.0
            },
            resolutions: {
                jquery: '1.10.2'
            }
        };

        // Make it into a JSON to write it away
        var fakeBowerFile = JSON.stringify(bowerTestConfig, null, 2);
        var fakeBowerFileName = path.join(config.paths.tmp, 'bower.json')

        // Read from the tmp folder instead of the base, we reset this
        // after all other tests
        grunt.config.set('config.paths.bower', fakeBowerFileName);

        // Write the fake bower to the tmp folder
        fs.writeFile(fakeBowerFileName, fakeBowerFile, done);
    });

    // Close the server afterwards
    afterAll(function(done){
        // Set the base path config back to it's original value
        // TODO @[RK]: Was paths.base ever changed then?
        //grunt.config('paths.base') = config.paths.baseBackup;

        this.httpSpy.server.stop(done);
    });

    // Reset the called-status after each test
    afterEach(function(){
        this.httpSpy.getAllLibrarySets.calls.reset();
    });

    it('should have the required config variables available', function () {
        expect(grunt.config.get('hosts')).toBeDefined();
        expect(grunt.config.get('hosts').kirkAddress).toBeDefined();
    });

    // resolveLibrarySetNameByPortal
    describe('resolveLibrarySetNameByPortal', function () {

        it('Should trigger an error when having an invalid portal environment', function(done) {
            portal.resolveLibrarySetNameByPortal('potahl', 'InvalidEnv', function(err){

                // Err should be triggered
                expect(err).toBeTruthy();

                // Validate that the names are the same
                expect(err).toContain('environment value');
                expect(err).toContain('Invalidenv');
                done();
            });
        });

        it('should not crash, but still give error when environment variable is only one character', function(done) {
            portal.resolveLibrarySetNameByPortal('open', 'd', function(err) {
                expect(err).toContain('Invalid environment value');
                done();
            });
        });

        it('should not trigger an error by incasesensitive environment value', function(done) {
            portal.resolveLibrarySetNameByPortal('open', 'dEvEloPMENt', function(err) {
                expect(err).not.toContain('Invalid environment value');
                done();
            });
        });

        it('Should return a librarySetName based on the portal and environment', function(done) {
            // Define what the server _should_ return
            this.httpSpy.resolveLibrarySetNameByPortal.and.returnValue({
                statusCode: 200,
                body: 'foobarImALibrarySet'
            });

            // Make a reference to this closure
            var self = this;

            portal.resolveLibrarySetNameByPortal('potahl', 'Development', function(err, librarySetName){

                // Err shouldn't be triggered
                expect(err).toBe(null);

                // Validate that the names are the same
                expect(librarySetName).toBe('foobarImALibrarySet');

                // Assert mock server has been called as expected
                expect(self.httpSpy.resolveLibrarySetNameByPortal).toHaveBeenCalled();
                done();
            });
        });

        // Should forward the error when server triggers an error
        it('Should forward the error when getBowerConfig triggers an error', function(done) {
            // Define what the server _should_ return
            this.httpSpy.resolveLibrarySetNameByPortal.and.returnValue({
                statusCode: 404,
                body: 'Youve reached beyond the end of the universe.  Congratulations, there is nothing here to find.'
            });

            portal.resolveLibrarySetNameByPortal('potahl', 'Development', function(err){

                // Err should be triggered
                expect(err).toBeTruthy();

                // Validate that the names are the same
                expect(err).toContain('404');

                done();
            });
        });
    });

    // getAllPortals
    describe('getAllPortals', function(){
        it('should return an array of all available portal names', function(done){
            var testPortals;

            // Valid server response
            this.httpSpy.getAllPortals.and.returnValue({
                statusCode: 200,
                body: testPortals = [
					{
						'name': 'beleggen',
						'environment': 'Development',
						'ciName': 'gBeleggen',
						'jobName': 'portal-build-beleggen',
						'enabled': true,
						'modules': {
							'spectingular-core': 'UNSTABLE',
							'spectingular-components': 'UNSTABLE'
						},
						'librarySet': 'angular1.2'
					},
					{
						'name': 'ming-next',
						'environment': 'Production',
						'ciName': 'gSpectingularPrdRN',
						'jobName': 'portal-build-ming',
						'enabled': false,
						'modules': {},
						'librarySet': 'angular1.4'
					}
				]
            });

            portal.getAllPortals(function(err, portals){
                expect(err).toBeFalsy();

                // Response validation
                expect(portals.length).toBe(2);
                expect(portals[0].name).toBe('beleggen');
                expect(portals).toEqual(testPortals);
                done();
            });
        });

        // Should catch a 404 error
        it('should catch a 404 server error', function(done) {
            // Valid server response
            this.httpSpy.getAllPortals.and.returnValue({
                statusCode: 404,
                body: 'Kim Yung Il was here. This page never existed'
            });

            portal.getAllPortals(function(err){
                expect(err).toBeTruthy();
                expect(err).toContain('404');
                done();
            });
        });
    });


    // getOrSetLibrarySetByPortal
    describe('getOrSetLibrarySetByPortal', function(){
        it('should trigger an error by getOrSet value', function(done) {
            portal.getOrSetLibrarySetByPortal('invalid', 'open','development', function(err) {
                expect(err).toBeTruthy();
                expect(err).toContain('getOrSet');
                done();
            });
        });

        it('should trigger an error by invalid environment value', function(done) {
            portal.getOrSetLibrarySetByPortal(librarySet.getLibrarySet, 'open','invalidValueBlah', function(err) {
                expect(err).toBeTruthy();
                expect(err).toContain('environment value');
                expect(err).toMatch(/invalidValueBlah/i);
                done();
            });
        });


        it('should forward the error from resolveLibrarySetByPortal', function(done) {
            // Define a 404 error which should be forwarded by the function we
            // called
            this.httpSpy.resolveLibrarySetNameByPortal.and.returnValue({
                statusCode: 404,
                body: 'Youve reached beyond the end of the universe.  Congratulations, there is nothing here to find.'
            });

            portal.getOrSetLibrarySetByPortal(librarySet.getLibrarySet, 'open','invalidValueBlah', function(err) {
                expect(err).toBeTruthy();
                expect(err).toContain('environment value');
                expect(err).toMatch(/invalidValueBlah/i);
                done();
            });
        });

        it('should succeed on a valid server response', function (done) {
            this.httpSpy.resolveLibrarySetNameByPortal.and.returnValue({
                statusCode: 200,
                body: 'foo'
            });
            // getLibrarySet HTTP server
            this.httpSpy.getLibrarySet.and.returnValue({
                statusCode: 200,
                body: {
                    libraries: [
                        { version: 1.4, name: 'angular', type: 'RUNTIME' },
                        null,
                        { version: 1.4, name: 'angular-mocks', type: 'DEV' }
                    ]
                }
            });

            portal.getOrSetLibrarySetByPortal(librarySet.getLibrarySet,
                                                  'potahl','Development',
                                                  function(err, librarySet) {

                expect(err).toBeFalsy();
                expect(librarySet.dependencies).toEqual(jasmine.any(Object));
                expect(librarySet.dependencies.angular).toBe(1.4);
                done();
            });
        });

    });

    // getLibrarySetByPortal
    describe('getLibrarySetByPortal', function(){
        it('should forward the error from getOrSetLibrarySetByPortal', function(done) {
            portal.getLibrarySetByPortal('open','invalidValueBlah', function(err) {
                expect(err).toBeTruthy();
                expect(err).toContain('environment value');
                expect(err).toMatch(/invalidValueBlah/i);
                done();
            });
        });

        it('should forward the error from resolveLibrarySetByPortal', function(done) {
            // Define a 404 error which should be forwarded by the function we
            // called
            this.httpSpy.resolveLibrarySetNameByPortal.and.returnValue({
                statusCode: 404,
                body: 'Youve reached beyond the end of the universe.  Congratulations, there is nothing here to find.'
            });

            portal.getLibrarySetByPortal('open','invalidValueBlah', function(err) {
                expect(err).toBeTruthy();
                expect(err).toContain('environment value');
                expect(err).toMatch(/invalidValueBlah/i);
                done();
            });
        });
    });

    // TODO see if we can unify these two tests (get/set) into one function

    // setLibrarySetByPortal
    describe('setLibrarySetByPortal', function(){
        it('should forward the error from getOrSetLibrarySetByPortal', function(done) {
            portal.setLibrarySetByPortal('open','invalidValueBlah', function(err) {
                expect(err).toBeTruthy();
                expect(err).toContain('environment value');
                expect(err).toMatch(/invalidValueBlah/i);
                done();
            });
        });

        it('should forward the error from resolveLibrarySetByPortal', function(done) {
            // Define a 404 error which should be forwarded by the function we
            // called
            this.httpSpy.resolveLibrarySetNameByPortal.and.returnValue({
                statusCode: 404,
                body: 'Youve reached beyond the end of the universe.  Congratulations, there is nothing here to find.'
            });

            portal.setLibrarySetByPortal('open','invalidValueBlah', function(err) {
                expect(err).toBeTruthy();
                expect(err).toContain('environment value');
                expect(err).toMatch(/invalidValueBlah/i);
                done();
            });
        });
    });

});
