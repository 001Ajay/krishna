'use strict';

var grunt = require('grunt');
var fs = require('fs');
var path = require('path');
var rimraf = require('rimraf');
var mkdirp = require('mkdirp');

require('../../lib/require-all-grunt')(grunt);

describe('a11y', function() {

    var a11y = require('../../lib/a11y')(grunt);
    var config = grunt.config('config');

    var tmpPath = path.join(config.paths.tmp, 'a11y-test');

    // /.tmp/a11y-test/mock1/
    // /.tmp/a11y-test/mock1/file1.html
    // /.tmp/a11y-test/mock1/testsubdir/
    // /.tmp/a11y-test/mock1/testsubdir/file2.html
    var tmpMock1Path = path.join(tmpPath, 'mock1');
    var tmpMock1PathSub = path.join(tmpMock1Path, 'testsubdir');
    var tmpMock1FileHtml1 = path.join(tmpMock1Path, 'file1.html');
    var tmpMock1FileHtml2 = path.join(tmpMock1PathSub, 'file2.html');

    // /.tmp/a11y-test/mock2/
    // /.tmp/a11y-test/mock2/file2.html
    // /.tmp/a11y-test/mock2/testsubdir/
    // /.tmp/a11y-test/mock2/testsubdir/file1.html
    var tmpMock2Path = path.join(tmpPath, 'mock2');
    var tmpMock2PathSub = path.join(tmpMock2Path, 'testsubdir');
    var tmpMock2FileHtml1 = path.join(tmpMock2PathSub, 'file1.html');
    var tmpMock2FileHtml2 = path.join(tmpMock2Path, 'file2.html');


    beforeAll(function(done) {
        mkdirp.sync(tmpMock1PathSub);
        mkdirp.sync(tmpMock2PathSub);

        fs.writeFileSync(tmpMock1FileHtml1, '<html></html>');
        fs.writeFileSync(tmpMock1FileHtml2, '<html></html>');

        fs.writeFileSync(tmpMock2FileHtml1, '<html></html>');
        fs.writeFileSync(tmpMock2FileHtml2, '<html></html>');

        done();
    });

    describe('findHtmlFiles', function() {

        it('should take a path and return an array of html file paths', function(done) {

            var result = a11y.findHtmlFiles(tmpMock1Path);

            expect(result).toEqual(jasmine.arrayContaining([tmpMock1FileHtml1]));

            var result = a11y.findHtmlFiles(tmpMock2Path);

            expect(result).toEqual(jasmine.arrayContaining([tmpMock2FileHtml2]));

            done();

        });

    });

    describe('getUrlPath', function() {

        it('should return a URL path based on target path and webroot path', function(done) {

            expect(a11y.getUrlPath).toEqual(jasmine.anything());

            expect(a11y.getUrlPath('/test1/test2/test3/test4.html', '/test1/test2')).toEqual('/test3/test4.html');

            expect(a11y.getUrlPath('/test5/test6/test7/test8.html', '/test5/test6')).toEqual('/test7/test8.html');

            done();
        })

    });

    describe('getTestServerUrl', function() {

        it('should take a URL path and return a test server URL', function(done) {

            expect(a11y.getTestServerUrl).toEqual(jasmine.anything());

            expect(a11y.getTestServerUrl('/test1.html', 'localhost', '1234')).toEqual('http://localhost:1234/test1.html');

            expect(a11y.getTestServerUrl('/path/test2.html', 'myfqdn', '5678')).toEqual('http://myfqdn:5678/path/test2.html');

            done();
        });

    });

    describe('generateAllTestUrls', function() {

        it('should return an array of test server (html) urls given a path, fqdn and a port', function(done) {

            expect(a11y.generateAllTestUrls).toEqual(jasmine.anything());

            var result = a11y.generateAllTestUrls(tmpMock1Path, 'localhost', '02468');

            expect(result).toEqual(jasmine.arrayContaining(['http://localhost:02468/file1.html']));

            var result = a11y.generateAllTestUrls(tmpMock2Path, 'myfqdn', '98765');

            expect(result).toEqual(jasmine.arrayContaining(['http://myfqdn:98765/file2.html']));

            done();

        });

    });

    afterAll(function(done) {
        rimraf(tmpPath, function(err) {
            if(err) {
                console.warn('Could not remove temporary test files.');
            }
            done();
        });
    });

});
