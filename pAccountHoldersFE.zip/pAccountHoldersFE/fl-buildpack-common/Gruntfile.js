'use strict';

/**
 *
 * @param grunt
 * @param suppressConfig - array of config names that are suppressed to be loaded.
 */
module.exports = function (grunt, options) {
    var options = options || {suppressConfig: [], forceConfig: {}};
    var util = require('util');
    if (options.cwd) {
        grunt.config.set('cwd', options.cwd);
    }

    require('./lib/loadConfig')(grunt,
        options.suppressConfig,
        options.forceConfig);

    grunt.log.debug('Finished with script to load configs');
    require('./lib/loadTasks')(grunt);
    require('time-grunt')(grunt);

    grunt.log.debug('Going to load other tasks now that are defined in the gruntfile');

    grunt.registerTask('a11y', 'Test the application for accessibility issues. ' +
        'Defaults to a11y:local. Use a11y:grid ' +
        '--fqdn $(hostname) to use remote selenium hub.', function (env) {

        grunt.task.run([
            'prepareE2e',
            'safeRun:connect.options.port,hosts.fqdn,config.paths.reports,config.paths.src:axe-webdriver:' + (env || 'local')
        ]);

    });

    grunt.registerTask('serve', 'Start up a server', [
        'force:on',
        'wiredep:app',
        'force:off',
        'fileblocks:app',
        'portPick:server',
        'portPick:livereload',
        'connect:server',
        'watch'
    ]);

    grunt.registerTask('unit', 'Test the application', [
        'clean:test',
        'jshint:scripts',
        'setKarmaFiles',
        'saveKarmaConfig',
        'portPick:karma',
        'karma'
    ]);

    grunt.registerTask('bower', 'Clean the bower installation', [
        'clean:lib',
        'bower-install-simple:install'
    ]);

    grunt.registerTask('prepareE2e', 'Run the preparation tasks for protractor tests', [
        'clean:e2e',
        'instrument',
        'wiredep:app',
        'portPick:e2e',
        'portPick:collector',
        'connect:e2e'
    ]);

    grunt.registerTask('prepareCucumber', 'Run the preparation tasks for cucumber tests', [
        'clean:e2e',
        'wiredep:app',
        'portPick:e2e',
        'portPick:collector',
        'connect:e2e'
    ]);

    grunt.registerTask('runE2e', 'Run the e2e tests', function (env) {
        var targetExists = grunt.config.get('protractor_coverage.' + env);
        if (typeof targetExists === 'undefined') {
            grunt.fail.fatal('missing target, use e2e:local or e2e:grid');
        }
        if (env === 'grid') {
            var fqdn = grunt.config.get('hosts.fqdn');
            if (typeof fqdn !== 'string' || fqdn === '') {
                grunt.fail.fatal('missing --fqdn, it\'s required if you want to use the remote Selenium hub');
            }
        }

        var tasklist = [];
        tasklist.push('protractor_coverage:' + env);
        tasklist.push('makeReport');

        grunt.log.debug('running e2e tasklist:' + util.inspect(tasklist, false, null));

        grunt.task.run(tasklist);
    });

    /**
     * Runs e2e test using the local or remote selenium hub
     *
     * @param {String} env The environment you want to run to, IE: use `local` to
     * run agains the local selenium hub.
     * @param {Boolean} skipPreparations Whether you want to skip tasks such as
     * wiring the dependencies and connecting to the selenium server when
     * already connected. For instance, flakyTest uses this flag.
     *
     * @example
     * use e2e:local to run against the local selenium hub
     * use e2e:grid --fqdn $(hostname) to run against the remote selenium hub
     * use e2e:local:true skips preparation task, such as wiring the
     *      dependencies and setting up the e2e server
     */
    grunt.registerTask('e2e', 'Run E2E tests using the local or remote Selenium hub, ' +
        'use e2e:local to run against the local selenium hub, ' +
        'use e2e:grid --fqdn $(hostname) to run against the remote selenium hub', function (env) {
        grunt.task.run([
            'copy:protractor',
            'prepareE2e',
            'runE2e:' + env
        ]);
    });


    grunt.registerTask('cucumber', '', function (env) {
        grunt.task.run([
            'copy:cucumber',
            'prepareCucumber',
            'protractor:' + env
        ]);
    });

    /**
     * Runs the e2e test N times using the local or remote selenium hub and
     * generates a bundled protractor report
     *
     * @param {String} env The environment you want to run to, IE: use `local` to
     * run agains the local selenium hub. See `e2e` function for a more
     * elaborate explaination.
     * @param {Number} repetitions How many times should the flakyTest run your
     * test.
     */
    grunt.registerTask('flakyTest', 'Run the e2e test N times using the local or remote selenium hub, and generate a test report', function (env, repetitions) {
        var e2eRepetitions = parseInt(repetitions, 10);
        if (!e2eRepetitions || e2eRepetitions === 'NaN') {
            e2eRepetitions = 3;
        }
        var tasklist = [
            'clean:flaky', // Empties the flakyTest report collection from the previous run
            'prepareE2e'
        ];

        // Run n times
        for (var i = 0; i < e2eRepetitions; i++) {
            // The last option defines if it should run the initial preparation tasks or not
            tasklist.push('runE2e:' + env);
            tasklist.push('bundleProtractorReport');
        }

        // Simplify the flaky report in the end
        tasklist.push('simplifyFlakyReport');

        grunt.log.debug('running flakyTest tasklist:' + util.inspect(tasklist, false, null));
        grunt.task.run(tasklist);
    });
};
