# pAccountHoldersFE
pAccountHolders Application for afmelden from en/of rekening houder and aanmelden rekeninghouder.

[Module build status](http://spectingular.europe.intranet/fruitloops.html#/modules/pAccountHolders/builds)

## Grunt tasks

* `grunt serve`
    * fires up an http server and serves the sample application
* `grunt unit`
    * runs all the quality checks, including jshint and karma unit tests
* `grunt cucumber:local`
    * runs the protractor cucumber tests against your local selenium hub
    * **protip** dont forget to run `./node_modules/.bin/webdriver-manager update`

## First time you want to do a module build.  

You need to run grunt serve one time. Wiredep will then change your html to include the depencencies.  
Commit this html, otherwise the module build will fail.  
If you change the bower dependencies, add a new one, you need to commit the updated html file.

## Settings for the build.
https://confluence.europe.intranet/display/FRT/Features+of+the+build

It's possible to set extra settings for the build process in the buildSettings.json
* protractor -> rootElement - Set a specific rootElement for your protractor tests

## Contributing

Any contributions to this project are very welcome and we are happy to get your ideas on this project. If you want to
contribute, you can follow these steps:

1. Clone the ssh://git@gitlab.ing.net:2222/Nirvana/pAccountHoldersFE.git repository
2. Create a new branch for your feature/bugfix
3. Commit all your changes to the new branch
4. Push your branch to the remote repository
5. Make a pull request from your branch to the master branch


## Usefull links
* [Riviera Component](https://confluence.europe.intranet/pages/viewpage.action?pageId=154447939)
