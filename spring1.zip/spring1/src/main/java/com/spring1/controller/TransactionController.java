package com.spring1.controller;

import com.spring1.model.Transaction;
import com.spring1.service.CrudService;
import com.spring1.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/transaction")
public class TransactionController extends CrudController<Transaction>{

    @Autowired
    private TransactionService service;

    @Override
    protected CrudService<Transaction> getService() {
        return service;
    }
}
