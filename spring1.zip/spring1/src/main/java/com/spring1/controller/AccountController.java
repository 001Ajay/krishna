package com.spring1.controller;

import com.spring1.model.Account;
import com.spring1.service.AccountService;
import com.spring1.service.CrudService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/*
{
	"id":"",
	"name":"BankBalance",
	"type":"Asset"
}
*/

@Controller
@RequestMapping("/account")
public class AccountController extends CrudController<Account>{

    @Autowired
    private AccountService service;

    @Override
    protected CrudService<Account> getService() {
        return service;
    }
}
