package com.spring1.controller;

import com.spring1.model.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

public class BaseController {

    @GetMapping("/hello")
    public @ResponseBody String hello(){
        return "Hello World";
    }

    protected static ResponseEntity success(String msg){
        return new ResponseEntity(msg, HttpStatus.OK);
    }

    protected static ResponseEntity fail(String msg){
        return new ResponseEntity(msg, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
