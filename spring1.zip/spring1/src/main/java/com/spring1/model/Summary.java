package com.spring1.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Summary {
    private Long balance;
    private String lastUpdate;
}
