package com.spring1.service;

import com.spring1.model.Transaction;
import org.springframework.stereotype.Service;

import java.nio.file.Path;

@Service
public class TransactionService extends DbFileService<Transaction> implements CrudService<Transaction>{

    @Override
    protected DB_FILE dBFileType() {
        return DB_FILE.TRANSACTION;
    }

    @Override
    protected Class<Transaction> getFileTypeClass() {
        return Transaction.class;
    }

    @Override
    protected String getId() {
        return null;
    }
}
