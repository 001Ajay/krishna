package com.spring1.service.httprequests;

import org.springframework.stereotype.Service;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

@Service
public class HttpRequestResponseService {

    private final String USER_AGENT = "Mozilla/5.0";

    public GetResponse sendGet(String urlString) throws Exception {
        URL urlObject = new URL(urlString);
        HttpURLConnection con = (HttpURLConnection) urlObject.openConnection();
        // optional default is GET
        con.setRequestMethod("GET");
        //add request header
        con.setRequestProperty("User-Agent", USER_AGENT);
        int responseCode = con.getResponseCode();
        System.out.println("\nSending 'GET' request to URL : " + urlString);
        System.out.println("Response Code : " + responseCode);
        BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()));
        String responseMessage = con.getResponseMessage();
        System.out.println();
        return new GetResponse.GetResponseBuilder()
                .url(urlString)
                .responseCode(String.valueOf(responseCode))
                .responseMessage(responseMessage)
                .build();
    }

}
