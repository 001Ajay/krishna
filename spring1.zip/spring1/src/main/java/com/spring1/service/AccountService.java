package com.spring1.service;

import com.spring1.model.Account;
import org.springframework.stereotype.Service;

import java.nio.file.Path;

@Service
public class AccountService extends DbFileService<Account> implements CrudService<Account>{

    @Override
    protected DB_FILE dBFileType() {
        return DB_FILE.ACCOUNT;
    }

    @Override
    protected Class<Account> getFileTypeClass() {
        return Account.class;
    }

    @Override
    protected String getId() {
        return String.valueOf(System.currentTimeMillis());
    }
}