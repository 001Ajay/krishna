package com.spring1.service;

import lombok.experimental.var;

import java.io.*;
import java.util.LinkedList;
import java.util.List;

public class InfoStore {
    private static String storeLoc="C:\\Base\\infoStore\\";

    public InfoStore(){
        getFile(storeLoc+"\\store1.txt");
    }

    private static File getFile(String fileLoc){
        File storeLoc = new File(fileLoc);
        if(!storeLoc.exists()) {
            try {
                storeLoc.createNewFile();
            } catch (IOException e) {
                System.err.println("File location : "+fileLoc);
                e.printStackTrace();
            }
        }
        return storeLoc;
    }

    private List<String> readFile(String fileName){

        List<String> info = new LinkedList<String>();
        String line = null;
        try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader = new FileReader(fileName);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            while((line = bufferedReader.readLine()) != null)
                //System.out.println(line);
                info.add(line);


            // Always close files.
            bufferedReader.close();
        }
        catch(FileNotFoundException ex) {
            System.out.println("Unable to open file '" + fileName + "'");
        }catch(IOException ex) {
            System.out.println("Error reading file '" + fileName + "'");
        }

        return info;
    }

    private static String getObjectInfo(Object obj){
        return obj.toString();
    }

}
