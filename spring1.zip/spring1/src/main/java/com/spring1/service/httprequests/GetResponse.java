package com.spring1.service.httprequests;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class GetResponse {
    private String url;
    private String responseCode;
    private String responseMessage;
    private BigDecimal amount;
}
