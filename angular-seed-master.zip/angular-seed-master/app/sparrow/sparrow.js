(function(){


    angular
        .module('myApp.sparrow')
        .component('calc',{
            bindings: {
                var1: false,
                var2: false,
                result:false
            },
            templateUrl: 'app/sparrow/sparrow.html',
            controller: SparrowController
        });

    function SparrowController($scope){
        var self=this;
        self.add = function(){
            self.result = var1 + var2;
        };
        self.$onInit = function () {
            console.log('Initialised');
            $scope.names = self.names;
        }
    };

}());