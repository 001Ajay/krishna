(function () {
    console.log("account.component.js loaded");
    'use strict';

    angular.module('account',[]);

    angular.module('account')
        .component('account-details',{
            templateUrl: 'components/account/account.html',
            controller: AccountDetailsController
        });

    console.log("I am here");

    function AccountDetailsController($scope){
        // $scope.accounts = [
        //     {name:"Cash", id:"1"},
        //     {name:"ING Bank", id:"2"},
        //     {name:"Axis Bank", id:"3"}
        // ];
    }
}());